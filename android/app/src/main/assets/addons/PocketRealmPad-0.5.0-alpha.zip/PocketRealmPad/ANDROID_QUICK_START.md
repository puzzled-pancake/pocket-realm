# Android quick start — Pocket Realm Pad 0.5

This guide is for the **Retroid Pocket 6 Stick Top** model and a player who has never played WoW.

## Before entering WoW

The Android controls setup must calibrate physical positions. Do not assume the Android key named `A` is the printed A button.

1. Choose **Retroid Pocket 6 — Stick Top**.
2. Press the four face positions when prompted: right **A**, bottom **B**, left **Y**, top **X**.
3. Press R1, L1, L2, R2, M1, M2, L3, R3, Start, Select, and each D-pad direction.
4. Grip the device normally for ten seconds. Choose **M1 target / M2 jump**, **Swap M1/M2**, or **Rear buttons off**. L3/R3 remain complete fallbacks.
5. Move both sticks and pull L2/R2 slowly. Accept the smallest dead zones and trigger thresholds that return cleanly to neutral without drift or repeated presses.
6. Run the stuck-key test. All held movement and modifiers must release on Android focus loss.

## First ten minutes

1. Use touch at login and character creation.
2. Move with the upper-left stick and look with the right stick.
3. Press M2 to jump. R3 is the backup.
4. Press M1 to target the nearest enemy. L3 is the backup.
5. Touch an NPC, object, or corpse so the pointer is over it, then press R2. R2 sends a right-click at the pointer; Vanilla has no automatic Interact-with-target command.
6. Use the four face positions for abilities 1–4.
7. Hold R1 with the same face positions for abilities 5–8. Your left thumb never has to leave movement for the core eight abilities.
8. Use D-pad directions for abilities 9–12 in the world. In menus, the D-pad moves the bright focus ring.
9. Press Start for the Quick Menu and Select for Controller Inventory.
10. Finish with the Android launcher’s **Save & Exit**, not WoW’s desktop Quit button.

## Final control card

| Physical RP6 control | World | Supported menu |
|---|---|---|
| Left stick | Move/strafe | — |
| Right stick | Camera | Pointer mode when selected |
| Right A | Ability 1 | Confirm |
| Bottom B | Ability 2 | Back/cancel |
| Left Y | Ability 3 | More/alternate |
| Top X | Ability 4 | Quick Menu from panel |
| R1 + A/B/Y/X | Abilities 5–8 | No menu chord |
| D-pad U/D/L/R | Abilities 9–12 | Move focus |
| L1 | Ability layer 2 | — |
| L2 | Ability layer 3 | — |
| L1 + L2 | Ability layer 4 | — |
| M1 | Nearest enemy | — |
| M2 | Jump | — |
| L3 / R3 | Target / Jump backups | — |
| R2 | Right-click current pointer | Right-click pointer |
| Start | Quick Menu | Quick Menu |
| Select | Controller Inventory | Controller Inventory |
| Touch | Precise world selection/ground spells | Login, text, drag, scroll, fields, fallback |

## Menu rules

- Right A confirms.
- Bottom B backs out.
- Left Y is More/alternate.
- Top X opens the Quick Menu from supported panels.
- D-pad moves the focus ring.
- No focus ring means use touch.
- Purchases, training, travel, crafting, mail, auctions, trades, and quest completion require Confirm twice.
- Bank item movement, trade items/money, mail composition, auction prices, spell dragging, talent spending, and destructive operations remain touch tasks.

## Bags

Press Select. D-pad selects a cell, right A uses/equips, left Y picks up/places, and bottom B closes. A normal touch selects and inspects; it does not unexpectedly consume or equip.

## Help

Open Start → second page → center **Controls & Help**, or enter `/prp guide`. Use `/prp controls` to print the physical map and `/prp status` to see the selected profile.
