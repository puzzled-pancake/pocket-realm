-- Controller action presentation for the WoW 1.12.1 action model.
-- Vanilla has 12 buttons, 6 ordinary pages (slots 1-72), and bonus/form
-- pages beyond them. This module never assumes retail action APIs.

PRP_ActionBar = {
    initialized = false,
    buttons = {},
    held = {},
    currentLayer = 1,
    currentPage = 1,
    updateElapsed = 0,
}

function PRP_ActionBar:GetModifier(name)
    local internal = PocketRealmPadDB.action[name .. "Held"] == 1
    if PocketRealmPadDB.action.usePhysicalModifiers ~= 1 then
        return internal
    end
    if name == "shift" and IsShiftKeyDown then
        return internal or PRP_Boolean(IsShiftKeyDown())
    elseif name == "control" and IsControlKeyDown then
        return internal or PRP_Boolean(IsControlKeyDown())
    elseif name == "alt" and IsAltKeyDown then
        return internal or PRP_Boolean(IsAltKeyDown())
    end
    return internal
end

function PRP_ActionBar:GetLayer()
    local shift = self:GetModifier("shift")
    local control = self:GetModifier("control")
    if shift and control then
        return 4
    elseif control then
        return 3
    elseif shift then
        return 2
    end
    return 1
end

function PRP_ActionBar:GetPageForLayer(layer)
    local setName = PocketRealmPadDB.action.pageSet or "A"
    if setName == "B" then
        if layer == 1 then
            return 5
        elseif layer == 2 then
            return 6
        elseif layer == 3 then
            return 3
        end
        return 4
    end
    return layer
end

function PRP_ActionBar:GetLayerName(layer, page)
    local setName = PocketRealmPadDB.action.pageSet or "A"
    if self:IsBonusActive(page) then return "Form / stance abilities" end
    if setName == "B" and layer == 1 then return "Extra abilities" end
    if setName == "B" and layer == 2 then return "Extra " .. PRP_ControlLabel("layer1") .. " abilities" end
    if layer == 2 then return PRP_ControlLabel("layer1") .. " abilities" end
    if layer == 3 then return PRP_ControlLabel("layer2") .. " abilities" end
    if layer == 4 then return PRP_ControlLabel("layer1") .. " + " .. PRP_ControlLabel("layer2") .. " abilities" end
    return "Abilities"
end

function PRP_ActionBar:IsBonusActive(page)
    if page ~= 1 then
        return false
    end
    if BonusActionBarFrame and PRP_IsVisible(BonusActionBarFrame) then
        return true
    end
    return false
end

function PRP_ActionBar:GetBonusSlot(index)
    local offset = 0
    local pages = NUM_ACTIONBAR_PAGES or 6
    local buttons = NUM_ACTIONBAR_BUTTONS or 12
    if GetBonusBarOffset then
        offset = GetBonusBarOffset() or 0
    end
    if offset == 0 and BonusActionBarFrame and BonusActionBarFrame.lastBonusBar then
        offset = BonusActionBarFrame.lastBonusBar
    end
    return index + ((pages + offset - 1) * buttons)
end

function PRP_ActionBar:GetSlot(index, page)
    local buttons = NUM_ACTIONBAR_BUTTONS or 12
    if self:IsBonusActive(page) then
        return self:GetBonusSlot(index)
    end
    return index + ((page - 1) * buttons)
end

function PRP_ActionBar:GetDisplaySemantic(index)
    -- The normal eight-button handheld surface always presents actions 1-8.
    -- Input remapping is separate so holding R1 does not duplicate or reshuffle
    -- the visible bar while the player is trying to read it.
    return index
end

function PRP_ActionBar:GetInputSemantic(index)
    -- RP6 stick-top layout: R1 + the four face positions reaches actions 5-8.
    -- The lower-left D-pad is reserved for the less-frequent actions 9-12.
    if PocketRealmPadDB.action.bankHeld == 1 and index <= 4 then
        return index + 4
    end
    return index
end

function PRP_ActionBar:GetSemanticLabel(semantic)
    local faceIndex
    if semantic >= 1 and semantic <= 4 then
        return PRP_ControlArrayLabel("face", semantic)
    elseif semantic >= 5 and semantic <= 8 then
        faceIndex = semantic - 4
        return PRP_ControlLabel("bank") .. "+" .. PRP_ControlArrayLabel("face", faceIndex)
    elseif semantic >= 9 and semantic <= 12 then
        return PRP_ControlArrayLabel("dpad", semantic - 8)
    end
    return tostring(semantic)
end

function PRP_ActionBar:CreateButton(index)
    local button = CreateFrame("CheckButton", "PocketRealmPadAction" .. index, self.frame)
    local icon
    local cooldown
    local count
    local hotkey
    local slotText
    local border

    button.prpIndex = index
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    button:SetCheckedTexture("Interface\\Buttons\\CheckButtonHilight", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    button.icon = icon

    cooldown = CreateFrame("Model", "PocketRealmPadAction" .. index .. "Cooldown", button, "CooldownFrameTemplate")
    cooldown:SetAllPoints(button)
    cooldown:SetFrameLevel(button:GetFrameLevel() + 1)
    button.cooldown = cooldown

    count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    count:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 2)
    button.count = count

    hotkey = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
    hotkey:SetPoint("TOPRIGHT", button, "TOPRIGHT", -2, -2)
    hotkey:SetJustifyH("RIGHT")
    button.hotkey = hotkey

    slotText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    slotText:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 2, 2)
    slotText:SetJustifyH("LEFT")
    button.slotText = slotText

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    border:Hide()
    button.border = border

    button:SetScript("OnEnter", PRP_ActionButton_OnEnter)
    button:SetScript("OnLeave", PRP_ActionButton_OnLeave)
    button:SetScript("OnClick", PRP_ActionButton_OnClick)
    self.buttons[index] = button
    return button
end

function PRP_ActionBar:ApplyMetrics()
    local metrics
    local columns
    local visible
    local size
    local spacing
    local rows
    local width
    local height
    local index
    local column
    local row
    local button
    local normal
    local fontScale
    if not self.initialized or not PRP_Handheld then
        return
    end
    metrics = PRP_Handheld:GetMetrics()
    fontScale = PRP_Handheld:GetFontScale()
    columns = metrics.actionColumns
    visible = metrics.visibleButtons
    size = metrics.actionButton
    spacing = metrics.actionSpacing
    rows = math.floor((visible + columns - 1) / columns)
    width = (columns * size) + ((columns - 1) * spacing) + 22
    height = (rows * size) + ((rows - 1) * spacing) + 46

    PocketRealmPadDB.action.visibleButtons = visible
    PocketRealmPadDB.action.columns = columns
    PocketRealmPadDB.bar.buttonSize = size
    PocketRealmPadDB.bar.spacing = spacing
    PocketRealmPadDB.bar.y = metrics.actionYOffset

    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.frame:SetAlpha(PocketRealmPadDB.bar.alpha or 1)
    PRP_SetFramePosition(self.frame, PocketRealmPadDB.bar)

    for index = 1, 12 do
        button = self.buttons[index]
        button:SetWidth(size)
        button:SetHeight(size)
        button.border:SetWidth(size * 1.70)
        button.border:SetHeight(size * 1.70)
        normal = button:GetNormalTexture()
        PRP_SetFontScale(button.count, fontScale, 10)
        PRP_SetFontScale(button.hotkey, fontScale, 10)
        PRP_SetFontScale(button.slotText, fontScale, 10)
        if normal then
            normal:SetWidth(size * 1.72)
            normal:SetHeight(size * 1.72)
            normal:ClearAllPoints()
            normal:SetPoint("CENTER", button, "CENTER", 0, -1)
        end
        button:ClearAllPoints()
        if index <= visible then
            column = math.mod(index - 1, columns)
            row = math.floor((index - 1) / columns)
            button:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 11 + (column * (size + spacing)), -31 - (row * (size + spacing)))
            button:Show()
        else
            button:Hide()
        end
    end
    PRP_SetFontScale(self.layerText, fontScale, 11)
    PRP_SetFontScale(self.selfText, fontScale, 10)
    self:UpdateAll(true)
end

function PRP_ActionBar:Layout()
    self:ApplyMetrics()
end

function PRP_ActionBar:Initialize()
    local index
    if self.initialized then
        return
    end
    self.frame = PRP_UI:CreatePanel("PocketRealmPadActionBar", 280, 120, "HIGH")
    self.frame:SetMovable(true)
    self.frame:EnableMouse(true)
    self.frame:RegisterForDrag("LeftButton")
    self.frame:SetScript("OnDragStart", PRP_ActionBar_OnDragStart)
    self.frame:SetScript("OnDragStop", PRP_ActionBar_OnDragStop)

    self.layerText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalSmall", "Abilities")
    self.layerText:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 12, -11)
    self.selfText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.selfText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -12, -11)

    for index = 1, 12 do
        self:CreateButton(index)
    end
    self.initialized = true
    self.currentLayer = self:GetLayer()
    self.currentPage = self:GetPageForLayer(self.currentLayer)
    self:ApplyMetrics()
    if PRP:IsEnabled() and PocketRealmPadDB.bar.shown == 1 and PocketRealmPadDB.safeMode ~= 1 then
        self.frame:Show()
    else
        self.frame:Hide()
    end
end

function PRP_ActionBar:UpdateButton(index)
    local button = self.buttons[index]
    local semantic
    local page = self.currentPage
    local slot
    local texture
    local count
    local start
    local duration
    local enable
    local usable
    local notEnoughMana
    local range
    local keyText
    local label
    if not button then
        return
    end

    semantic = self:GetDisplaySemantic(index)
    slot = self:GetSlot(semantic, page)
    button.prpSemantic = semantic
    button.prpSlot = slot
    button.prpBonus = self:IsBonusActive(page)

    texture = GetActionTexture and GetActionTexture(slot) or nil
    if texture then
        button.icon:SetTexture(texture)
        button.icon:Show()
        button:SetAlpha(1)
    else
        button.icon:SetTexture(nil)
        button.icon:Hide()
        button:SetAlpha(0.56)
    end

    count = 0
    if IsConsumableAction and IsConsumableAction(slot) and GetActionCount then
        count = GetActionCount(slot) or 0
    end
    if count and count > 1 then
        button.count:SetText(count)
    else
        button.count:SetText("")
    end

    if GetActionCooldown then
        start, duration, enable = GetActionCooldown(slot)
        if start and duration then
            CooldownFrame_SetTimer(button.cooldown, start, duration, enable)
        else
            button.cooldown:Hide()
        end
    end

    usable = true
    notEnoughMana = false
    if IsUsableAction then
        usable, notEnoughMana = IsUsableAction(slot)
    end
    if usable then
        button.icon:SetVertexColor(1, 1, 1)
    elseif notEnoughMana then
        button.icon:SetVertexColor(0.45, 0.45, 1)
    else
        button.icon:SetVertexColor(0.38, 0.38, 0.38)
    end

    if IsCurrentAction and (IsCurrentAction(slot) or (IsAutoRepeatAction and IsAutoRepeatAction(slot))) then
        button:SetChecked(1)
    elseif not self.held[index] then
        button:SetChecked(0)
    end

    if IsEquippedAction and IsEquippedAction(slot) then
        button.border:SetVertexColor(0, 1, 0, 0.55)
        button.border:Show()
    else
        button.border:Hide()
    end

    keyText = self:GetSemanticLabel(semantic)
    button.hotkey:SetText(keyText)
    button.hotkey:SetTextColor(0.78, 0.78, 0.78)
    if texture and ActionHasRange and ActionHasRange(slot) and IsActionInRange then
        range = IsActionInRange(slot)
        if range == 0 or range == false then
            button.hotkey:SetTextColor(1, 0.15, 0.15)
        end
    end
    if PocketRealmPadDB.action.showSlotNumbers == 1 then
        button.slotText:SetText(tostring(slot))
    else
        button.slotText:SetText("")
    end
end

function PRP_ActionBar:UpdateAll(force)
    local layer
    local page
    local index
    if not self.initialized and not force then
        return
    end
    layer = self:GetLayer()
    page = self:GetPageForLayer(layer)
    self.currentLayer = layer
    self.currentPage = page
    if self.layerText then
        self.layerText:SetText(self:GetLayerName(layer, page))
    end
    if self.selfText then
        if self:GetModifier("alt") and not self:IsBonusActive(page) then
            self.selfText:SetText("|cff79b7ffSelf-cast|r")
        elseif PocketRealmPadDB.action.bankHeld == 1 then
            self.selfText:SetText("|cff79b7ff" .. PRP_ControlLabel("bank") .. ": abilities 5-8|r")
        else
            self.selfText:SetText("")
        end
    end
    for index = 1, 12 do
        self:UpdateButton(index)
    end
end

function PRP_ActionBar:OnKey(index, state)
    local semantic
    local held
    local page
    local slot
    local selfCast
    local bonus
    local button
    if not self.initialized or not PRP:IsEnabled() then
        return
    end
    semantic = self:GetInputSemantic(index)
    if semantic <= (PocketRealmPadDB.action.visibleButtons or 8) then
        button = self.buttons[semantic]
    else
        button = self.buttons[index]
    end
    if state == "down" then
        page = self:GetPageForLayer(self:GetLayer())
        slot = self:GetSlot(semantic, page)
        bonus = self:IsBonusActive(page)
        selfCast = nil
        if self:GetModifier("alt") and not bonus then
            selfCast = 1
        end
        -- Key held state is indexed by the physical binding position. The
        -- resolved semantic, page, slot, self-cast state, and visible feedback
        -- are captured now so releasing R1/L1/L2 before the face button cannot
        -- change the action completed on key-up.
        self.held[index] = { semantic = semantic, slot = slot, selfCast = selfCast, page = page, bonus = bonus, visualIndex = semantic }
        if button then
            button:SetButtonState("PUSHED")
            button:SetChecked(1)
        end
        return
    end

    held = self.held[index]
    self.held[index] = nil
    if held and held.visualIndex then
        button = self.buttons[held.visualIndex] or button
    end
    if button then
        button:SetButtonState("NORMAL")
    end
    if not held then
        return
    end
    if MacroFrame_SaveMacro then
        MacroFrame_SaveMacro()
    end
    if HasAction and HasAction(held.slot) and UseAction then
        UseAction(held.slot, 0, held.selfCast)
    end
    self:UpdateButton(held.visualIndex or index)
end

function PRP_ActionBar:SetModifier(name, state)
    if name ~= "shift" and name ~= "control" and name ~= "alt" and name ~= "bank" then
        return
    end
    PocketRealmPadDB.action[name .. "Held"] = state == "down" and 1 or 0
    self:UpdateAll(true)
end

function PRP_ActionBar:TogglePageSet()
    if PocketRealmPadDB.action.pageSet == "A" then
        PocketRealmPadDB.action.pageSet = "B"
    else
        PocketRealmPadDB.action.pageSet = "A"
    end
    self:ReleaseAll()
    if PRP_UI then
        PRP_UI:ShowToast(PocketRealmPadDB.action.pageSet == "B" and "Extra action bars" or "Main action bars", 1.4)
    end
end

function PRP_ActionBar:ReleaseAll()
    local index
    local button
    self.held = {}
    for index = 1, 12 do
        button = self.buttons[index]
        if button then
            button:SetButtonState("NORMAL")
            button:SetChecked(0)
        end
    end
    PocketRealmPadDB.action.shiftHeld = 0
    PocketRealmPadDB.action.controlHeld = 0
    PocketRealmPadDB.action.altHeld = 0
    PocketRealmPadDB.action.bankHeld = 0
    self:UpdateAll(true)
end

function PRP_ActionBar:OnEvent(eventName, firstArg)
    self:UpdateAll(true)
end

function PRP_ActionBar:OnUpdate(elapsed)
    local layer
    local page
    self.updateElapsed = self.updateElapsed + elapsed
    if self.updateElapsed < 0.10 then
        return
    end
    self.updateElapsed = 0
    layer = self:GetLayer()
    page = self:GetPageForLayer(layer)
    if layer ~= self.currentLayer or page ~= self.currentPage then
        self:UpdateAll(true)
    else
        self:UpdateAll(false)
    end
end

function PRP_ActionButton_OnEnter()
    local button = this
    local slot = button and button.prpSlot
    if not button or not slot or not GameTooltip or not GameTooltip.SetAction then
        return
    end
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:SetAction(slot)
    GameTooltip:Show()
end

function PRP_ActionButton_OnLeave()
    if GameTooltip then
        GameTooltip:Hide()
    end
end

function PRP_ActionButton_OnClick()
    local button = this
    local slot = button and button.prpSlot
    local selfCast
    if not slot or not HasAction or not HasAction(slot) then
        return
    end
    selfCast = nil
    if arg1 == "RightButton" and not button.prpBonus then
        selfCast = 1
    end
    if MacroFrame_SaveMacro then
        MacroFrame_SaveMacro()
    end
    UseAction(slot, 0, selfCast)
    PRP_ActionBar:UpdateButton(button.prpIndex)
end

function PRP_ActionBar_OnDragStart()
    if PocketRealmPadDB.bar.locked == 1 then
        return
    end
    this:StartMoving()
end

function PRP_ActionBar_OnDragStop()
    this:StopMovingOrSizing()
    PRP_SaveFramePosition(this, PocketRealmPadDB.bar)
end

function PRP_ActionModifier(name, state)
    if PRP_ActionBar then
        PRP_ActionBar:SetModifier(name, state)
    end
end

function PRP_TogglePageSet()
    if PRP_ActionBar then
        PRP_ActionBar:TogglePageSet()
    end
end
