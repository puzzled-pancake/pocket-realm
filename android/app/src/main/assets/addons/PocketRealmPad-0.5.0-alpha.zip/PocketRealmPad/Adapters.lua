-- Explicit adapters for known Blizzard 1.12 UI panels.
-- Frames are named individually or through bounded, known template ranges.

PRP_Adapters = {}

function PRP_Adapters:Add(nodes, frameName, fallbackLabel, accept, alternate, confirm)
    local frame = PRP_GetFrame(frameName)
    local count
    if not frame or not PRP_IsVisible(frame) or not PRP_IsEnabled(frame) then
        return
    end
    count = PRP_TableLength(nodes) + 1
    nodes[count] = {
        frame = frame,
        label = PRP_GetFrameLabel(frame, fallbackLabel or frameName),
        accept = accept,
        alternate = alternate,
        confirm = confirm,
    }
end

function PRP_Adapters:AddRange(nodes, prefix, suffix, first, last, labelPrefix, accept, alternate, confirm)
    local index
    local name
    for index = first, last do
        name = prefix .. index .. (suffix or "")
        self:Add(nodes, name, (labelPrefix or "Item") .. " " .. index, accept, alternate, confirm)
    end
end

function PRP_Adapters:BackByName(frameName, mouseButton)
    local frame = PRP_GetFrame(frameName)
    if frame and PRP_IsVisible(frame) then
        return PRP_InvokeFrame(frame, mouseButton or "LeftButton")
    end
    return false
end

function PRP_Adapters:GetPopupAdapter()
    local index
    local frame
    for index = 1, 4 do
        frame = PRP_GetFrame("StaticPopup" .. index)
        if PRP_IsVisible(frame) then
            return {
                id = "static-popup-" .. index,
                title = "Confirmation",
                popupIndex = index,
                Collect = function(adapter, nodes)
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "Button1", "Confirm")
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "Button2", "Cancel")
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "CloseButton", "Close")
                end,
                Back = function(adapter)
                    if PRP_Adapters:BackByName("StaticPopup" .. adapter.popupIndex .. "Button2") then
                        return true
                    end
                    return PRP_Adapters:BackByName("StaticPopup" .. adapter.popupIndex .. "CloseButton")
                end,
            }
        end
    end
    return nil
end

PRP_Adapters.quest = {
    id = "quest",
    title = "Quest",
    scrollBars = {
        "QuestGreetingScrollFrameScrollBar",
        "QuestDetailScrollFrameScrollBar",
        "QuestProgressScrollFrameScrollBar",
        "QuestRewardScrollFrameScrollBar",
    },
}

function PRP_Adapters.quest:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "QuestTitleButton", "", 1, 10, "Quest")
    PRP_Adapters:AddRange(nodes, "QuestRewardItem", "", 1, 10, "Reward")
    PRP_Adapters:Add(nodes, "QuestFrameAcceptButton", "Accept quest")
    PRP_Adapters:Add(nodes, "QuestFrameDeclineButton", "Decline quest")
    PRP_Adapters:Add(nodes, "QuestFrameCompleteButton", "Continue")
    PRP_Adapters:Add(nodes, "QuestFrameCompleteQuestButton", "Complete quest", nil, nil, "Complete this quest with the selected reward")
    PRP_Adapters:Add(nodes, "QuestFrameGoodbyeButton", "Goodbye")
    PRP_Adapters:Add(nodes, "QuestFrameCancelButton", "Cancel")
    PRP_Adapters:Add(nodes, "QuestFrameCloseButton", "Close")
end

function PRP_Adapters.quest:Back()
    if PRP_Adapters:BackByName("QuestFrameGoodbyeButton") then
        return true
    end
    if PRP_Adapters:BackByName("QuestFrameCancelButton") then
        return true
    end
    if PRP_Adapters:BackByName("QuestFrameDeclineButton") then
        return true
    end
    return PRP_Adapters:BackByName("QuestFrameCloseButton")
end

PRP_Adapters.gossip = {
    id = "gossip",
    title = "Gossip",
    scrollBars = { "GossipGreetingScrollFrameScrollBar" },
}

function PRP_Adapters.gossip:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "GossipTitleButton", "", 1, 32, "Gossip option")
    PRP_Adapters:Add(nodes, "GossipFrameCloseButton", "Close")
end

function PRP_Adapters.gossip:Back()
    return PRP_Adapters:BackByName("GossipFrameCloseButton")
end

PRP_Adapters.loot = {
    id = "loot",
    title = "Loot",
}

function PRP_Adapters.loot:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "LootButton", "", 1, 4, "Loot")
    PRP_Adapters:Add(nodes, "LootFrameUpButton", "Previous loot page")
    PRP_Adapters:Add(nodes, "LootFrameDownButton", "Next loot page")
    PRP_Adapters:Add(nodes, "LootCloseButton", "Close loot")
end

function PRP_Adapters.loot:Back()
    return PRP_Adapters:BackByName("LootCloseButton")
end

PRP_Adapters.merchant = {
    id = "merchant",
    title = "Merchant",
}

function PRP_Adapters.merchant:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "MerchantItem", "ItemButton", 1, 12, "Merchant item", nil, nil, "Buy this item")
    PRP_Adapters:Add(nodes, "MerchantBuyBackItemItemButton", "Buy back item", nil, nil, "Buy back this item")
    PRP_Adapters:Add(nodes, "MerchantPrevPageButton", "Previous merchant page")
    PRP_Adapters:Add(nodes, "MerchantNextPageButton", "Next merchant page")
    PRP_Adapters:Add(nodes, "MerchantRepairItemButton", "Repair one item (costs money)", nil, nil, "Pay to repair one item")
    PRP_Adapters:Add(nodes, "MerchantRepairAllButton", "Repair all items (costs money)", nil, nil, "Pay to repair all items")
    PRP_Adapters:Add(nodes, "MerchantFrameCloseButton", "Close merchant")
end

function PRP_Adapters.merchant:Back()
    return PRP_Adapters:BackByName("MerchantFrameCloseButton")
end

PRP_Adapters.gameMenu = {
    id = "game-menu",
    title = "Game menu",
}

function PRP_Adapters.gameMenu:Collect(nodes)
    PRP_Adapters:Add(nodes, "GameMenuButtonOptions", "Video options")
    PRP_Adapters:Add(nodes, "GameMenuButtonSoundOptions", "Sound options")
    PRP_Adapters:Add(nodes, "GameMenuButtonUIOptions", "Interface options")
    PRP_Adapters:Add(nodes, "GameMenuButtonKeybindings", "Key bindings")
    PRP_Adapters:Add(nodes, "GameMenuButtonMacros", "Macros")
    PRP_Adapters:Add(nodes, "GameMenuButtonContinue", "Return to game")
end

function PRP_Adapters.gameMenu:Back()
    return PRP_Adapters:BackByName("GameMenuButtonContinue")
end

PRP_Adapters.spellBook = {
    id = "spellbook",
    title = "Spellbook",
}

function PRP_Adapters.spellBook:Collect(nodes)
    -- Spell icons can cast or begin drag semantics depending on state. For a
    -- new touch-and-controller player, touch is the clear way to inspect and
    -- drag spells to Blizzard's original action bar. Controller focus changes
    -- tabs/pages and closes the book.
    PRP_Adapters:AddRange(nodes, "SpellBookSkillLineTab", "", 1, 8, "Spell tab")
    PRP_Adapters:Add(nodes, "SpellBookPrevPageButton", "Previous spell page")
    PRP_Adapters:Add(nodes, "SpellBookNextPageButton", "Next spell page")
    PRP_Adapters:Add(nodes, "SpellBookCloseButton", "Close spellbook")
end

function PRP_Adapters.spellBook:Back()
    return PRP_Adapters:BackByName("SpellBookCloseButton")
end

PRP_Adapters.character = {
    id = "character",
    title = "Character",
}

function PRP_Adapters.character:Collect(nodes)
    -- Equipment slots support pickup/drag semantics that are easy to trigger by
    -- accident. The controller path changes tabs and closes; touch handles gear.
    PRP_Adapters:AddRange(nodes, "CharacterFrameTab", "", 1, 5, "Character tab")
    PRP_Adapters:Add(nodes, "CharacterFrameCloseButton", "Close character")
end

function PRP_Adapters.character:Back()
    return PRP_Adapters:BackByName("CharacterFrameCloseButton")
end

PRP_Adapters.questLog = {
    id = "quest-log",
    title = "Quest log",
    scrollBars = { "QuestLogListScrollFrameScrollBar", "QuestLogDetailScrollFrameScrollBar" },
}

function PRP_Adapters.ToggleQuestWatch(frame)
    local offset = 0
    local questIndex
    local title
    local level
    local tag
    local isHeader
    local index
    local entry
    local maxWatches = MAX_WATCHABLE_QUESTS or 5

    if not frame or not frame.GetID or not GetQuestLogTitle then
        return false
    end
    if FauxScrollFrame_GetOffset and QuestLogListScrollFrame then
        offset = FauxScrollFrame_GetOffset(QuestLogListScrollFrame) or 0
    end
    questIndex = frame:GetID() + offset
    title, level, tag, isHeader = GetQuestLogTitle(questIndex)
    if not title or isHeader then
        return false
    end
    if SelectQuestLogEntry then
        SelectQuestLogEntry(questIndex)
    end

    if IsQuestWatched and IsQuestWatched(questIndex) then
        if type(QUEST_WATCH_LIST) == "table" then
            for index = table.getn(QUEST_WATCH_LIST), 1, -1 do
                entry = QUEST_WATCH_LIST[index]
                if entry and entry.index == questIndex then
                    table.remove(QUEST_WATCH_LIST, index)
                end
            end
        end
        if RemoveQuestWatch then
            RemoveQuestWatch(questIndex)
        end
    else
        if GetNumQuestLeaderBoards and GetNumQuestLeaderBoards(questIndex) == 0 then
            if UIErrorsFrame and UIErrorsFrame.AddMessage and QUEST_WATCH_NO_OBJECTIVES then
                UIErrorsFrame:AddMessage(QUEST_WATCH_NO_OBJECTIVES, 1.0, 0.1, 0.1, 1.0)
            end
            return false
        end
        if GetNumQuestWatches and GetNumQuestWatches() >= maxWatches then
            if UIErrorsFrame and UIErrorsFrame.AddMessage and QUEST_WATCH_TOO_MANY then
                UIErrorsFrame:AddMessage(string.format(QUEST_WATCH_TOO_MANY, maxWatches), 1.0, 0.1, 0.1, 1.0)
            end
            return false
        end
        if AutoQuestWatch_Insert then
            AutoQuestWatch_Insert(questIndex, QUEST_WATCH_NO_EXPIRE or -1)
        elseif AddQuestWatch then
            AddQuestWatch(questIndex)
        else
            return false
        end
    end
    if QuestWatch_Update then
        QuestWatch_Update()
    end
    if QuestLog_Update then
        QuestLog_Update()
    end
    return true
end

function PRP_Adapters.questLog:Collect(nodes)
    -- Vanilla tracks a quest by shift-clicking a visible QuestLogTitle button.
    -- Action 3 reproduces that semantic with the 1.12 quest-watch APIs.
    PRP_Adapters:AddRange(nodes, "QuestLogTitle", "", 1, 6, "Quest", nil, PRP_Adapters.ToggleQuestWatch)
    PRP_Adapters:Add(nodes, "QuestLogCollapseAllButton", "Expand or collapse quest headers")
    PRP_Adapters:Add(nodes, "QuestFramePushQuestButton", "Share quest")
    PRP_Adapters:Add(nodes, "QuestFrameExitButton", "Exit quest log")
    PRP_Adapters:Add(nodes, "QuestLogFrameCloseButton", "Close quest log")
end

function PRP_Adapters.questLog:Back()
    if PRP_Adapters:BackByName("QuestFrameExitButton") then
        return true
    end
    return PRP_Adapters:BackByName("QuestLogFrameCloseButton")
end

PRP_Adapters.friends = {
    id = "social",
    title = "Social",
    scrollBars = { "FriendsListScrollFrameScrollBar", "WhoListScrollFrameScrollBar", "GuildListScrollFrameScrollBar" },
}

function PRP_Adapters.friends:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "FriendsFrameTab", "", 1, 4, "Social tab")
    PRP_Adapters:AddRange(nodes, "FriendsFrameFriendButton", "", 1, 12, "Friend")
    PRP_Adapters:AddRange(nodes, "WhoFrameButton", "", 1, 17, "Who result")
    PRP_Adapters:Add(nodes, "FriendsFrameAddFriendButton", "Add friend")
    PRP_Adapters:Add(nodes, "FriendsFrameSendMessageButton", "Send message")
    PRP_Adapters:Add(nodes, "FriendsFrameCloseButton", "Close social")
end

function PRP_Adapters.friends:Back()
    return PRP_Adapters:BackByName("FriendsFrameCloseButton")
end

PRP_Adapters.worldMap = {
    id = "world-map",
    title = "World map",
}

function PRP_Adapters.worldMap:Collect(nodes)
    PRP_Adapters:Add(nodes, "WorldMapZoomOutButton", "Zoom out")
    PRP_Adapters:Add(nodes, "WorldMapFrameCloseButton", "Close map")
end

function PRP_Adapters.worldMap:Back()
    if PRP_Adapters:BackByName("WorldMapFrameCloseButton") then
        return true
    end
    if ToggleWorldMap then
        ToggleWorldMap()
        return true
    end
    return false
end


PRP_Adapters.bank = { id = "bank", title = "Bank" }
function PRP_Adapters.bank:Collect(nodes)
    -- Bank slots are drag-and-drop inventory controls and do not expose useful
    -- item names through this bounded focus adapter. Touch handles moving bank
    -- items; the controller always has a predictable Close action.
    PRP_Adapters:Add(nodes, "BankCloseButton", "Close bank")
end
function PRP_Adapters.bank:Back() return PRP_Adapters:BackByName("BankCloseButton") end

PRP_Adapters.trainer = {
    id = "trainer", title = "Trainer",
    scrollBars = { "ClassTrainerListScrollFrameScrollBar", "ClassTrainerDetailScrollFrameScrollBar" },
}
function PRP_Adapters.trainer:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "ClassTrainerSkill", "", 1, 11, "Trainer skill")
    PRP_Adapters:Add(nodes, "ClassTrainerTrainButton", "Train", nil, nil, "Pay to learn this skill")
    PRP_Adapters:Add(nodes, "ClassTrainerCancelButton", "Exit trainer")
    PRP_Adapters:Add(nodes, "ClassTrainerFrameCloseButton", "Close trainer")
end
function PRP_Adapters.trainer:Back()
    if PRP_Adapters:BackByName("ClassTrainerCancelButton") then return true end
    return PRP_Adapters:BackByName("ClassTrainerFrameCloseButton")
end

PRP_Adapters.craft = {
    id = "craft", title = "Craft",
    scrollBars = { "CraftListScrollFrameScrollBar", "CraftDetailScrollFrameScrollBar" },
}
function PRP_Adapters.craft:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "Craft", "", 1, 8, "Craft recipe")
    PRP_Adapters:Add(nodes, "CraftCreateButton", "Create", nil, nil, "Use materials to create this item")
    PRP_Adapters:Add(nodes, "CraftCancelButton", "Exit craft")
    PRP_Adapters:Add(nodes, "CraftFrameCloseButton", "Close craft")
end
function PRP_Adapters.craft:Back()
    if PRP_Adapters:BackByName("CraftCancelButton") then return true end
    return PRP_Adapters:BackByName("CraftFrameCloseButton")
end

PRP_Adapters.tradeSkill = {
    id = "trade-skill", title = "Trade skill",
    scrollBars = { "TradeSkillListScrollFrameScrollBar", "TradeSkillDetailScrollFrameScrollBar" },
}
function PRP_Adapters.tradeSkill:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "TradeSkillSkill", "", 1, 8, "Recipe")
    PRP_Adapters:Add(nodes, "TradeSkillCreateButton", "Create", nil, nil, "Use materials to create this item")
    PRP_Adapters:Add(nodes, "TradeSkillCreateAllButton", "Create all", nil, nil, "Use materials to create all selected items")
    PRP_Adapters:Add(nodes, "TradeSkillDecrementButton", "Decrease count")
    PRP_Adapters:Add(nodes, "TradeSkillIncrementButton", "Increase count")
    PRP_Adapters:Add(nodes, "TradeSkillCancelButton", "Exit trade skill")
    PRP_Adapters:Add(nodes, "TradeSkillFrameCloseButton", "Close trade skill")
end
function PRP_Adapters.tradeSkill:Back()
    if PRP_Adapters:BackByName("TradeSkillCancelButton") then return true end
    return PRP_Adapters:BackByName("TradeSkillFrameCloseButton")
end

PRP_Adapters.trade = { id = "trade", title = "Player trade" }
function PRP_Adapters.trade:Collect(nodes)
    -- Trade item slots and money fields use drag/edit semantics. Touch handles
    -- the offer; controller focus is limited to the explicit commit/cancel flow.
    PRP_Adapters:Add(nodes, "TradeFrameTradeButton", "Accept trade", nil, nil, "Accept this trade")
    PRP_Adapters:Add(nodes, "TradeFrameCancelButton", "Cancel trade")
    PRP_Adapters:Add(nodes, "TradeFrameCloseButton", "Close trade")
end
function PRP_Adapters.trade:Back() return PRP_Adapters:BackByName("TradeFrameCancelButton") end

PRP_Adapters.mailInbox = {
    id = "mail-inbox", title = "Mail inbox",
    scrollBars = { "InboxFrameScrollFrameScrollBar" },
}
function PRP_Adapters.mailInbox:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "MailItem", "", 1, 7, "Mail message")
    PRP_Adapters:Add(nodes, "InboxPrevPageButton", "Previous inbox page")
    PRP_Adapters:Add(nodes, "InboxNextPageButton", "Next inbox page")
    PRP_Adapters:AddRange(nodes, "MailFrameTab", "", 1, 2, "Mail tab")
    PRP_Adapters:Add(nodes, "MailFrameCloseButton", "Close mail")
end
function PRP_Adapters.mailInbox:Back() return PRP_Adapters:BackByName("MailFrameCloseButton") end

PRP_Adapters.sendMail = { id = "send-mail", title = "Send mail" }
function PRP_Adapters.sendMail:Collect(nodes)
    -- Vanilla 1.12 exposes one package slot, not the later multi-attachment grid.
    -- Recipient, subject, body, money, and package attachment use touch/IME.
    PRP_Adapters:Add(nodes, "SendMailMailButton", "Send mail", nil, nil, "Send this mail")
    PRP_Adapters:Add(nodes, "SendMailCancelButton", "Cancel mail")
    PRP_Adapters:AddRange(nodes, "MailFrameTab", "", 1, 2, "Mail tab")
    PRP_Adapters:Add(nodes, "MailFrameCloseButton", "Close mail")
end
function PRP_Adapters.sendMail:Back()
    if PRP_Adapters:BackByName("SendMailCancelButton") then return true end
    return PRP_Adapters:BackByName("MailFrameCloseButton")
end

PRP_Adapters.openMail = { id = "open-mail", title = "Open mail" }
function PRP_Adapters.openMail:Collect(nodes)
    -- Vanilla open mail has separate letter, one package, and money controls.
    PRP_Adapters:Add(nodes, "OpenMailLetterButton", "Read letter")
    PRP_Adapters:Add(nodes, "OpenMailPackageButton", "Take package")
    PRP_Adapters:Add(nodes, "OpenMailMoneyButton", "Take money")
    PRP_Adapters:Add(nodes, "OpenMailReplyButton", "Reply")
    PRP_Adapters:Add(nodes, "OpenMailCancelButton", "Return to inbox")
    PRP_Adapters:Add(nodes, "OpenMailFrameCloseButton", "Close mail")
end
function PRP_Adapters.openMail:Back()
    if PRP_Adapters:BackByName("OpenMailCancelButton") then return true end
    return PRP_Adapters:BackByName("OpenMailFrameCloseButton")
end

PRP_Adapters.auctionBrowse = {
    id = "auction-browse", title = "Auction browse",
    scrollBars = { "BrowseScrollFrameScrollBar" },
}
function PRP_Adapters.auctionBrowse:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "BrowseButton", "", 1, 8, "Auction result")
    PRP_Adapters:AddRange(nodes, "AuctionFilterButton", "", 1, 15, "Auction category")
    PRP_Adapters:Add(nodes, "BrowseSearchButton", "Search auctions")
    PRP_Adapters:Add(nodes, "BrowsePrevPageButton", "Previous result page")
    PRP_Adapters:Add(nodes, "BrowseNextPageButton", "Next result page")
    PRP_Adapters:Add(nodes, "BrowseBidButton", "Bid", nil, nil, "Place this bid")
    PRP_Adapters:Add(nodes, "BrowseBuyoutButton", "Buyout", nil, nil, "Buy this auction now")
    PRP_Adapters:AddRange(nodes, "AuctionFrameTab", "", 1, 3, "Auction tab")
    PRP_Adapters:Add(nodes, "AuctionFrameCloseButton", "Close auction house")
end
function PRP_Adapters.auctionBrowse:Back() return PRP_Adapters:BackByName("AuctionFrameCloseButton") end

PRP_Adapters.auctionBids = {
    id = "auction-bids", title = "Auction bids",
    scrollBars = { "BidScrollFrameScrollBar" },
}
function PRP_Adapters.auctionBids:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "BidButton", "", 1, 9, "Bid auction")
    PRP_Adapters:Add(nodes, "BidBidButton", "Raise bid", nil, nil, "Raise this bid")
    PRP_Adapters:Add(nodes, "BidBuyoutButton", "Buyout", nil, nil, "Buy this auction now")
    PRP_Adapters:AddRange(nodes, "AuctionFrameTab", "", 1, 3, "Auction tab")
    PRP_Adapters:Add(nodes, "AuctionFrameCloseButton", "Close auction house")
end
function PRP_Adapters.auctionBids:Back() return PRP_Adapters:BackByName("AuctionFrameCloseButton") end

PRP_Adapters.auctionOwned = {
    id = "auction-owned", title = "Your auctions",
    scrollBars = { "AuctionsScrollFrameScrollBar" },
}
function PRP_Adapters.auctionOwned:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "AuctionsButton", "", 1, 9, "Your auction")
    PRP_Adapters:Add(nodes, "AuctionsCreateAuctionButton", "Create auction", nil, nil, "Post this auction and pay its deposit")
    PRP_Adapters:AddRange(nodes, "AuctionFrameTab", "", 1, 3, "Auction tab")
    PRP_Adapters:Add(nodes, "AuctionFrameCloseButton", "Close auction house")
end
function PRP_Adapters.auctionOwned:Back() return PRP_Adapters:BackByName("AuctionFrameCloseButton") end

PRP_Adapters.taxi = { id = "taxi", title = "Flight paths" }
function PRP_Adapters.taxi:Collect(nodes)
    local count = 0
    if NumTaxiNodes then
        count = tonumber(NumTaxiNodes()) or 0
    end
    if NUM_TAXI_BUTTONS and NUM_TAXI_BUTTONS > count then
        count = NUM_TAXI_BUTTONS
    end
    count = PRP_Clamp(count, 0, 64)
    PRP_Adapters:AddRange(nodes, "TaxiButton", "", 1, count, "Flight destination", nil, nil, "Pay for this flight")
    PRP_Adapters:Add(nodes, "TaxiCloseButton", "Close flight map")
end
function PRP_Adapters.taxi:Back() return PRP_Adapters:BackByName("TaxiCloseButton") end

PRP_Adapters.talents = { id = "talents", title = "Talents" }
function PRP_Adapters.talents:Collect(nodes)
    -- Spending a talent point is permanent in Vanilla until the player pays a
    -- trainer to reset it. Controller focus changes tabs; touch allocates points.
    PRP_Adapters:AddRange(nodes, "TalentFrameTab", "", 1, 3, "Talent tab")
    PRP_Adapters:Add(nodes, "TalentFrameCloseButton", "Close talents")
end
function PRP_Adapters.talents:Back() return PRP_Adapters:BackByName("TalentFrameCloseButton") end

function PRP_Adapters:GetActive()
    local popup = self:GetPopupAdapter()
    if popup then return popup end
    if PRP_IsVisible(PRP_GetFrame("QuestFrame")) then return self.quest end
    if PRP_IsVisible(PRP_GetFrame("GossipFrame")) then return self.gossip end
    if PRP_IsVisible(PRP_GetFrame("LootFrame")) then return self.loot end
    if PRP_IsVisible(PRP_GetFrame("MerchantFrame")) then return self.merchant end
    if PRP_IsVisible(PRP_GetFrame("BankFrame")) then return self.bank end
    if PRP_IsVisible(PRP_GetFrame("ClassTrainerFrame")) then return self.trainer end
    if PRP_IsVisible(PRP_GetFrame("CraftFrame")) then return self.craft end
    if PRP_IsVisible(PRP_GetFrame("TradeSkillFrame")) then return self.tradeSkill end
    if PRP_IsVisible(PRP_GetFrame("TradeFrame")) then return self.trade end
    if PRP_IsVisible(PRP_GetFrame("OpenMailFrame")) then return self.openMail end
    if PRP_IsVisible(PRP_GetFrame("SendMailFrame")) then return self.sendMail end
    if PRP_IsVisible(PRP_GetFrame("InboxFrame")) then return self.mailInbox end
    if PRP_IsVisible(PRP_GetFrame("AuctionFrame")) then
        if PRP_IsVisible(PRP_GetFrame("BidFrame")) then return self.auctionBids end
        if PRP_IsVisible(PRP_GetFrame("AuctionsFrame")) then return self.auctionOwned end
        return self.auctionBrowse
    end
    if PRP_IsVisible(PRP_GetFrame("TaxiFrame")) then return self.taxi end
    if PRP_IsVisible(PRP_GetFrame("TalentFrame")) then return self.talents end
    if PRP_IsVisible(PRP_GetFrame("GameMenuFrame")) then return self.gameMenu end
    if PRP_IsVisible(PRP_GetFrame("SpellBookFrame")) then return self.spellBook end
    if PRP_IsVisible(PRP_GetFrame("CharacterFrame")) then return self.character end
    if PRP_IsVisible(PRP_GetFrame("QuestLogFrame")) then return self.questLog end
    if PRP_IsVisible(PRP_GetFrame("FriendsFrame")) then return self.friends end
    if PRP_IsVisible(PRP_GetFrame("WorldMapFrame")) then return self.worldMap end
    return nil
end
