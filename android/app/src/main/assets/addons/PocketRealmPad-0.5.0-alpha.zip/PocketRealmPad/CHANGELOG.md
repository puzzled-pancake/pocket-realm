# Changelog

## 0.5.0-alpha — Retroid Pocket 6 Stick Top ergonomics pass

- Added a source-backed RP6 Stick Top control study and physical qualification plan.
- Changed the default map so the left thumb stays on the upper movement stick: face buttons are abilities 1–4, R1+face is 5–8, and the lower D-pad is 9–12.
- Mapped by physical face position and printed RP6 labels: right A Confirm, bottom B Back, left Y More, top X panel menu.
- Made M1 nearest-enemy targeting and M2 Jump, with L3/R3 complete fallbacks for players who disable or bump rear paddles.
- Reserved rear buttons for safe, reversible taps; they are never modifiers, consumables, purchases, or destructive operations.
- Added launcher calibration requirements for Nintendo/Xbox Android label swaps, M1/M2 grip testing, duplicate fallback mapping, and key-collision detection.
- Kept the visible eight-button bar stable while R1 is held; action semantics are captured on key-down.
- Updated all beginner, Winlator, integration, audit, research, and qualification documentation.
- Expanded host runtime coverage to 276 assertions.

## 0.4.0-alpha — novice Android UX and safety pass

- Made the product explicitly Android-only and controller-plus-touch rather than controller-only or PC-oriented.
- Added a five-page first-run guide with delayed, non-interrupting presentation.
- Standardized the novice map at that release: L3 nearest enemy, R2 pointer right-click, R3 stock Jump, Start Quick Menu, Select Inventory.
- Moved Target Self to Advanced/unbound.
- Removed Quick Menu tap/hold/latch timing; Start is a simple toggle.
- Reorganized Quick Menu into everyday and occasional pages; centered Inventory and Controls & Help.
- Added 14-binding Essentials preflight and kept 85 optional commands under Advanced.
- Hid raw action-slot and bag-slot numbers by default.
- Changed normal inventory touch to selection-only; use/equip remains controller A or secondary click.
- Added friendly Backpack/Bag names.
- Added two-step confirmation for quest completion, purchases, repair, training, crafting, trade accept, mail send, auctions, and taxi travel.
- Made Back, movement, timeout, frame closure, and forced focus refresh cancel pending confirmation.
- Removed risky controller focus from bank items, trade offers, mail fields/packages, spell icons, equipment drag, talent spending, quest abandonment, mail deletion, auction cancellation, reagents, bank-slot purchase, and Game Menu Quit/Logout.
- Suppressed custom surfaces, target commands, page commands, pet/form actions, raid markers, and helper commands while chat is active.
- Added `LEGACY_600` and completed ten Android display profiles from 540p through 1440p, tablet, and Android large display.
- Added explicit 5.5-inch 1080p Retroid Pocket 6 sizing and 720p-to-native physical-size parity guidance.
- Expanded host runtime coverage to 264 assertions.

## 0.3.0-alpha — Vanilla feature and resolution expansion

- Corrected the action model to six ordinary pages / 72 slots.
- Added pet, form, targeting, raid marker, helper, panel, inventory, quick-menu, and responsive-profile coverage.
- Added 99 project bindings and complete 228-stock-binding audit.
- Added host static and mocked runtime verification.
