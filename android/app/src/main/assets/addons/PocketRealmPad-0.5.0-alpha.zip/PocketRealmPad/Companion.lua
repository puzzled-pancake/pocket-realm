-- Dedicated pet-action and stance/form surface for the Vanilla 1.12 APIs.
-- The first ten cells are pet actions; the second ten are shapeshift forms.

PRP_Companion = {
    initialized = false,
    buttons = {},
    entries = {},
    selected = 1,
    elapsed = 0,
}

function PRP_Companion:CreateButton(index)
    local button = CreateFrame("CheckButton", "PocketRealmPadCompanionCell" .. index, self.frame)
    local icon
    local label
    local count
    local cooldown
    local border
    button.prpIndex = index
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    button:SetCheckedTexture("Interface\\Buttons\\CheckButtonHilight", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    button.icon = icon

    cooldown = CreateFrame("Model", "PocketRealmPadCompanionCell" .. index .. "Cooldown", button, "CooldownFrameTemplate")
    cooldown:SetAllPoints(button)
    cooldown:SetFrameLevel(button:GetFrameLevel() + 1)
    button.cooldown = cooldown

    label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    label:SetPoint("BOTTOM", button, "BOTTOM", 0, 3)
    label:SetWidth(60)
    label:SetJustifyH("CENTER")
    button.label = label

    count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
    count:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    button.count = count

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    border:Hide()
    button.border = border

    button:SetScript("OnEnter", PRP_CompanionCell_OnEnter)
    button:SetScript("OnLeave", PRP_CompanionCell_OnLeave)
    button:SetScript("OnClick", PRP_CompanionCell_OnClick)
    self.buttons[index] = button
end

function PRP_Companion:Initialize()
    local index
    if self.initialized then
        return
    end
    self.frame = PRP_UI:CreatePanel("PocketRealmPadCompanion", 340, 270, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:Hide()
    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Pet & forms")
    self.title:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -12)
    self.pageText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "Pet commands (top)  |  Forms (bottom)")
    self.pageText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -14, -17)
    self.details = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.details:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 14, 13)
    self.details:SetJustifyH("LEFT")
    self.emptyText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlight", "No pet or form controls are available for this character.")
    self.emptyText:SetPoint("CENTER", self.frame, "CENTER", 0, -4)
    self.emptyText:SetJustifyH("CENTER")
    self.emptyText:Hide()
    for index = 1, 20 do
        self:CreateButton(index)
    end
    self.initialized = true
    self:ApplyMetrics()
    self:Rebuild()
end

function PRP_Companion:ApplyMetrics()
    local metrics
    local columns
    local rows
    local size
    local spacing
    local width
    local height
    local index
    local column
    local row
    local button
    local fontScale
    if not self.initialized or not PRP_Handheld then
        return
    end
    metrics = PRP_Handheld:GetMetrics()
    fontScale = PRP_Handheld:GetFontScale()
    columns = 5
    rows = 4
    size = metrics.companionButton
    spacing = metrics.companionSpacing
    width = 28 + (columns * size) + ((columns - 1) * spacing)
    height = 84 + (rows * size) + ((rows - 1) * spacing)
    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.details:SetWidth(width - 28)
    self.emptyText:SetWidth(width - 56)
    for index = 1, 20 do
        button = self.buttons[index]
        column = math.mod(index - 1, columns)
        row = math.floor((index - 1) / columns)
        button:SetWidth(size)
        button:SetHeight(size)
        PRP_SetFontScale(button.label, fontScale, 10)
        PRP_SetFontScale(button.count, fontScale, 10)
        button.border:SetWidth(size * 1.70)
        button.border:SetHeight(size * 1.70)
        button.label:SetWidth(size - 6)
        button:ClearAllPoints()
        button:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14 + (column * (size + spacing)), -45 - (row * (size + spacing)))
    end
    PRP_SetFontScale(self.title, fontScale, 14)
    PRP_SetFontScale(self.pageText, fontScale, 10)
    PRP_SetFontScale(self.details, fontScale, 10)
    PRP_SetFontScale(self.emptyText, fontScale, 12)
end

function PRP_Companion:IsShown()
    return self.initialized and PRP_IsVisible(self.frame)
end

function PRP_Companion:BuildPetEntry(index)
    local name
    local subtext
    local texture
    local isToken
    local isActive
    local autoCastAllowed
    local autoCastEnabled
    if not GetPetActionInfo then
        return { kind = "PET", index = index, available = false }
    end
    name, subtext, texture, isToken, isActive, autoCastAllowed, autoCastEnabled = GetPetActionInfo(index)
    if isToken and name then
        name = getglobal(name) or name
    end
    return {
        kind = "PET",
        index = index,
        name = name,
        subtext = subtext,
        texture = texture,
        active = PRP_Boolean(isActive),
        autoAllowed = PRP_Boolean(autoCastAllowed),
        autoEnabled = PRP_Boolean(autoCastEnabled),
        available = name ~= nil or texture ~= nil,
    }
end

function PRP_Companion:BuildFormEntry(index)
    local texture
    local name
    local isActive
    local isCastable
    local count = GetNumShapeshiftForms and GetNumShapeshiftForms() or 0
    if index > count or not GetShapeshiftFormInfo then
        return { kind = "FORM", index = index, available = false }
    end
    texture, name, isActive, isCastable = GetShapeshiftFormInfo(index)
    return {
        kind = "FORM",
        index = index,
        name = name,
        texture = texture,
        active = PRP_Boolean(isActive),
        castable = PRP_Boolean(isCastable),
        available = name ~= nil or texture ~= nil,
    }
end

function PRP_Companion:Rebuild()
    local index
    local available = 0
    if not self.initialized then
        return
    end
    for index = 1, 10 do
        self.entries[index] = self:BuildPetEntry(index)
        self.entries[index + 10] = self:BuildFormEntry(index)
        if self.entries[index].available then available = available + 1 end
        if self.entries[index + 10].available then available = available + 1 end
    end
    self.availableCount = available
    if not self.entries[self.selected] or not self.entries[self.selected].available then
        self.selected = self:FindAvailable(1, 1) or 1
    end
    for index = 1, 20 do
        self:UpdateButton(index)
    end
    self:UpdateVisual()
end

function PRP_Companion:UpdateButton(index)
    local entry = self.entries[index]
    local button = self.buttons[index]
    local start
    local duration
    local enable
    local shortLabel
    if not entry or not button then
        return
    end
    button.prpEntry = entry
    if entry.available then
        button:Show()
        if entry.texture then
            button.icon:SetTexture(entry.texture)
            button.icon:Show()
        else
            button.icon:SetTexture("Interface\\Buttons\\UI-EmptySlot")
            button.icon:Show()
        end
        button:SetAlpha(1)
    else
        button.icon:SetTexture(nil)
        button.icon:Hide()
        button:Hide()
    end
    if entry.kind == "PET" then
        shortLabel = "P" .. tostring(entry.index)
        if GetPetActionCooldown then
            start, duration, enable = GetPetActionCooldown(entry.index)
        end
        if entry.autoEnabled then
            button.border:SetVertexColor(0.20, 0.80, 1.00, 0.75)
            button.border:Show()
        else
            button.border:Hide()
        end
    else
        shortLabel = "F" .. tostring(entry.index)
        if GetShapeshiftFormCooldown then
            start, duration, enable = GetShapeshiftFormCooldown(entry.index)
        end
        if entry.active then
            button.border:SetVertexColor(0.20, 1.00, 0.20, 0.75)
            button.border:Show()
        else
            button.border:Hide()
        end
    end
    if start and duration then
        CooldownFrame_SetTimer(button.cooldown, start, duration, enable)
    else
        button.cooldown:Hide()
    end
    if PocketRealmPadDB.debug == 1 then
        button.label:SetText(shortLabel)
    else
        button.label:SetText("")
    end
    button.count:SetText("")
    if entry.active then
        button:SetChecked(1)
    elseif not button.prpPressed then
        button:SetChecked(0)
    end
end

function PRP_Companion:FindAvailable(startIndex, step)
    local index = startIndex
    local tries = 0
    while tries < 20 do
        if index < 1 then index = 20 end
        if index > 20 then index = 1 end
        if self.entries[index] and self.entries[index].available then
            return index
        end
        index = index + step
        tries = tries + 1
    end
    return nil
end

function PRP_Companion:SetSelected(index)
    if index < 1 then index = 1 end
    if index > 20 then index = 20 end
    if self.entries[index] and self.entries[index].available then
        self.selected = index
        self:UpdateVisual()
    end
end

function PRP_Companion:Navigate(direction)
    local columns = 5
    local delta = 0
    local index
    local tries = 0
    if direction == "UP" then delta = -columns
    elseif direction == "DOWN" then delta = columns
    elseif direction == "LEFT" then delta = -1
    elseif direction == "RIGHT" then delta = 1
    end
    if delta == 0 then return false end
    index = self.selected
    while tries < 20 do
        index = index + delta
        if index < 1 then index = index + 20 end
        if index > 20 then index = index - 20 end
        if self.entries[index] and self.entries[index].available then
            self.selected = index
            self:UpdateVisual()
            if PlaySound then PlaySound("igMainMenuOptionCheckBoxOn") end
            return true
        end
        tries = tries + 1
    end
    return false
end

function PRP_Companion:UpdateVisual()
    local entry = self.entries[self.selected]
    local button = self.buttons[self.selected]
    local text
    if not self:IsShown() then return end
    if not self.availableCount or self.availableCount < 1 or not entry or not entry.available or not button then
        self.details:Hide()
        self.emptyText:SetText("No pet or form controls are available yet.\n\n" .. PRP_ControlHint("Close", "back"))
        self.emptyText:Show()
        PRP_UI:ClearFocus()
        return
    end
    self.emptyText:Hide()
    self.details:Show()
    text = entry.name or ((entry.kind == "PET" and "Pet action ") or "Form ") .. tostring(entry.index)
    if entry.kind == "PET" and entry.autoAllowed then
        self.details:SetText(text .. "   " .. PRP_ControlHint("Use", "confirm") .. "   " .. PRP_ControlHint("Autocast", "alternate") .. "   " .. PRP_ControlHint("Close", "back"))
    else
        self.details:SetText(text .. "   " .. PRP_ControlHint("Use", "confirm") .. "   " .. PRP_ControlHint("Close", "back"))
    end
    PRP_UI:SetFocus(button, text, false)
end

function PRP_Companion:Accept()
    local entry = self.entries[self.selected]
    if not entry or not entry.available then
        return false
    end
    if entry.kind == "PET" and CastPetAction then
        CastPetAction(entry.index)
    elseif entry.kind == "FORM" then
        PRP_VanillaActions:Form(entry.index)
    end
    self:Rebuild()
    return true
end

function PRP_Companion:Alternate()
    local entry = self.entries[self.selected]
    if not entry or not entry.available then
        return false
    end
    if entry.kind == "PET" and entry.autoAllowed and TogglePetAutocast then
        TogglePetAutocast(entry.index)
        self:Rebuild()
        return true
    end
    return false
end

function PRP_Companion:Back()
    self:Hide()
    return true
end

function PRP_Companion:Show()
    if PocketRealmPadDB.safeMode == 1 then
        return
    end
    if PRP_Inventory then PRP_Inventory:Hide() end
    if PRP_QuickMenu then PRP_QuickMenu:Hide() end
    if PRP_Guide then PRP_Guide:Hide(false) end
    self:Rebuild()
    self.frame:Show()
    PRP:SetMode("COMPANION")
    self:UpdateVisual()
end

function PRP_Companion:Hide()
    if not self.initialized then return end
    self.frame:Hide()
    if PRP_UI then
        PRP_UI:ClearFocus()
        PRP_UI:SetPrompt("")
    end
    if PRP_Focus then PRP_Focus:Detect(true) end
end

function PRP_Companion:Toggle()
    if self:IsShown() then self:Hide() else self:Show() end
end

function PRP_Companion:SetPetPressed(index, pressed)
    local button = self.buttons[index]
    if button then
        button.prpPressed = pressed and true or false
        if pressed then
            button:SetButtonState("PUSHED")
            button:SetChecked(1)
        else
            button:SetButtonState("NORMAL")
            self:UpdateButton(index)
        end
    end
end

function PRP_Companion:OnEvent(eventName, firstArg)
    if eventName == "PET_BAR_UPDATE"
        or eventName == "PET_BAR_UPDATE_COOLDOWN"
        or eventName == "PET_BAR_SHOWGRID"
        or eventName == "PET_BAR_HIDEGRID"
        or eventName == "UPDATE_SHAPESHIFT_FORMS"
        or eventName == "SPELL_UPDATE_COOLDOWN"
        or eventName == "SPELL_UPDATE_USABLE"
        or eventName == "PLAYER_AURAS_CHANGED"
        or eventName == "UNIT_PET" then
        self:Rebuild()
    end
end

function PRP_Companion:OnUpdate(elapsed)
    if not self:IsShown() then return end
    self.elapsed = self.elapsed + elapsed
    if self.elapsed >= 0.20 then
        self.elapsed = 0
        self:Rebuild()
    end
end

function PRP_CompanionCell_OnEnter()
    local entry = this and this.prpEntry
    if not entry or not entry.available or not GameTooltip then return end
    GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
    if entry.kind == "PET" and GameTooltip.SetPetAction then
        GameTooltip:SetPetAction(entry.index)
    else
        GameTooltip:SetText(entry.name or ("Form " .. tostring(entry.index)), 1, 1, 1)
    end
    GameTooltip:Show()
end

function PRP_CompanionCell_OnLeave()
    if GameTooltip then GameTooltip:Hide() end
end

function PRP_CompanionCell_OnClick()
    if not this then return end
    PRP_Companion.selected = this.prpIndex
    if arg1 == "RightButton" then
        PRP_Companion:Alternate()
    else
        PRP_Companion:Accept()
    end
end

function PRP_CompanionKey()
    if PRP_Router then
        PRP_Router:CompanionKey()
    end
end
