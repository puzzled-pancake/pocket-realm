-- Pocket Realm Pad core lifecycle for WoW 1.12.1 / Interface 11200.
-- Winlator owns the physical controller and keyboard/mouse synthesis. This
-- addon owns only the in-client semantic and presentation layer.

PRP = PRP or {}
PRP.name = "PocketRealmPad"
PRP.version = "0.5.0-alpha"
PRP.initialized = false
PRP.mode = "LOADING"

function PRP:Print(message)
    local text = "|cff79b7ffPocket Realm Pad:|r " .. tostring(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    end
end

function PRP:Debug(message)
    if not PocketRealmPadDB or PocketRealmPadDB.debug ~= 1 then
        return
    end
    self:Print("DEBUG " .. tostring(message))
end

function PRP:SetMode(mode)
    self.mode = mode
    if PRP_UI and PRP_UI.SetMode then
        PRP_UI:SetMode(mode)
    end
end

function PRP:IsEnabled()
    return PocketRealmPadDB and PocketRealmPadDB.enabled == 1
end

function PRP:IsSafeMode()
    if not PocketRealmPadDB then
        return true
    end
    return PocketRealmPadDB.safeMode == 1
end

function PRP:GetEssentialBindingStatus()
    local bound = 0
    local total = PRP_TableLength(PRP_ESSENTIAL_BINDINGS or {})
    local index
    local key1
    local key2
    if not GetBindingKey then return 0, total end
    for index = 1, total do
        key1, key2 = GetBindingKey(PRP_ESSENTIAL_BINDINGS[index])
        if key1 or key2 then bound = bound + 1 end
    end
    return bound, total
end

function PRP:ReportBindingStatus(warnOnly)
    local bound
    local total
    bound, total = self:GetEssentialBindingStatus()
    if total < 1 then return end
    if bound < total then
        self:Print("controller setup: " .. tostring(bound) .. "/" .. tostring(total)
            .. " essential commands are bound. Use the Android Controls setup or WoW Key Bindings > Pocket Realm Pad — Essentials.")
    elseif not warnOnly then
        self:Print("controller setup: all " .. tostring(total) .. " essential commands are bound")
    end
end

function PRP:InitializeSavedVariables()
    local oldSchema
    if type(PocketRealmPadDB) ~= "table" then PocketRealmPadDB = {} end
    oldSchema = tonumber(PocketRealmPadDB.schema) or 0
    PocketRealmPadDB = PRP_MergeDefaults(PocketRealmPadDB, PRP_DEFAULTS)
    -- v0.3 stored an undocumented hold-timing value. v0.4 uses a simple
    -- press-to-toggle Quick Menu, so remove the legacy field on every load.
    if PocketRealmPadDB.quickMenu then
        PocketRealmPadDB.quickMenu.holdThreshold = nil
    end
    if oldSchema < 4 then
        PocketRealmPadDB.action.showSlotNumbers = 0
        PocketRealmPadDB.inventory.sellConfirmSeconds = 5.0
        PocketRealmPadDB.onboarding.completed = 0
        if PocketRealmPadDB.display.profile == "DESKTOP" then
            PocketRealmPadDB.display.profile = "ANDROID_LARGE"
        end
        if PocketRealmPadDB.display.deviceHint == "DESKTOP" then
            PocketRealmPadDB.display.deviceHint = "ANDROID_LARGE"
        end
    end
    if oldSchema < 5 then
        -- v0.5 is a physical-layout migration for the RP6 stick-top model.
        -- Reset only project-owned controller labels and the mapping profile;
        -- action contents, frame positions, display choices, and user scale stay.
        PocketRealmPadDB.controls = PRP_CopyTable(PRP_DEFAULTS.controls)
        PocketRealmPadDB.mappingProfile = PRP_PROFILE_ID
        PocketRealmPadDB.display.deviceHint = "RETROID_POCKET_6"
        PocketRealmPadDB.action.dpadWorldMode = "ACTIONS"
        PocketRealmPadDB.onboarding.completed = 0
    end
    PocketRealmPadDB.schema = 5
end

function PRP:Initialize()
    if self.initialized then
        return
    end
    self:InitializeSavedVariables()

    if PRP_UI and PRP_UI.Initialize then
        PRP_UI:Initialize()
    end
    if PRP_Handheld and PRP_Handheld.Initialize then
        PRP_Handheld:Initialize()
    end
    if PRP_ActionBar and PRP_ActionBar.Initialize then
        PRP_ActionBar:Initialize()
    end
    if PRP_Targeting and PRP_Targeting.Initialize then
        PRP_Targeting:Initialize()
    end
    if PRP_Inventory and PRP_Inventory.Initialize then
        PRP_Inventory:Initialize()
    end
    if PRP_QuickMenu and PRP_QuickMenu.Initialize then
        PRP_QuickMenu:Initialize()
    end
    if PRP_Companion and PRP_Companion.Initialize then
        PRP_Companion:Initialize()
    end
    if PRP_Guide and PRP_Guide.Initialize then
        PRP_Guide:Initialize()
    end
    if PRP_Focus and PRP_Focus.Initialize then
        PRP_Focus:Initialize()
    end
    if PRP_Router and PRP_Router.Initialize then
        PRP_Router:Initialize()
    end
    if PRP_Slash and PRP_Slash.Initialize then
        PRP_Slash:Initialize()
    end

    self.initialized = true
    if self:IsEnabled() then
        self:SetMode("WORLD")
    else
        self:SetMode("DISABLED")
    end
    self:RefreshAll()
    self:Print("loaded v" .. self.version .. "; " .. PRP_Handheld:StatusText() .. ". Open Controls & Help from the Quick Menu.")
    self:ReportBindingStatus(true)
end

function PRP:CloseTransientSurfaces()
    if PRP_QuickMenu then
        PRP_QuickMenu:Hide()
    end
    if PRP_Inventory then
        PRP_Inventory:Hide()
    end
    if PRP_Companion then
        PRP_Companion:Hide()
    end
    if PRP_Guide then
        PRP_Guide:Hide(false)
    end
end

function PRP:ReleaseAllInputs()
    if PRP_Router and PRP_Router.ReleaseAll then
        PRP_Router:ReleaseAll()
    elseif PRP_ActionBar and PRP_ActionBar.ReleaseAll then
        PRP_ActionBar:ReleaseAll()
    end
end

function PRP:RefreshAll()
    if PRP_Handheld and PRP_Handheld.Apply then
        PRP_Handheld:Apply(false)
    end
    if PRP_ActionBar and PRP_ActionBar.UpdateAll then
        PRP_ActionBar:UpdateAll(true)
    end
    if PRP_Targeting and PRP_Targeting.Update then
        PRP_Targeting:Update(true)
    end
    if PRP_Inventory and PRP_Inventory.IsShown and PRP_Inventory:IsShown() then
        PRP_Inventory:Rebuild(true)
    end
    if PRP_QuickMenu and PRP_QuickMenu.IsShown and PRP_QuickMenu:IsShown() then
        PRP_QuickMenu:UpdateButtons()
    end
    if PRP_Companion and PRP_Companion.Rebuild then
        PRP_Companion:Rebuild()
    end
    if PRP_Guide and PRP_Guide.IsShown and PRP_Guide:IsShown() then
        PRP_Guide:Refresh()
    end
    if PRP_Focus and PRP_Focus.Detect then
        PRP_Focus:Detect(true)
    end
end

function PRP:IsActionEvent(eventName)
    return eventName == "UPDATE_BINDINGS"
        or eventName == "ACTIONBAR_SLOT_CHANGED"
        or eventName == "ACTIONBAR_UPDATE_USABLE"
        or eventName == "ACTIONBAR_UPDATE_COOLDOWN"
        or eventName == "ACTIONBAR_UPDATE_STATE"
        or eventName == "ACTIONBAR_PAGE_CHANGED"
        or eventName == "UPDATE_BONUS_ACTIONBAR"
        or eventName == "PLAYER_AURAS_CHANGED"
        or eventName == "PLAYER_TARGET_CHANGED"
        or eventName == "SPELL_UPDATE_COOLDOWN"
        or eventName == "SPELL_UPDATE_USABLE"
end

function PRP:OnEvent(eventName, firstArg)
    if eventName == "ADDON_LOADED" then
        if firstArg == self.name then
            self:Initialize()
        end
        return
    end

    if not self.initialized then
        return
    end

    if eventName == "PLAYER_ENTERING_WORLD" then
        self:ReleaseAllInputs()
        self:RefreshAll()
        if PocketRealmPadDB.onboarding and PocketRealmPadDB.onboarding.showOnLogin == 1
            and PocketRealmPadDB.onboarding.completed ~= 1 and PocketRealmPadDB.safeMode ~= 1 then
            self.pendingGuideAt = (GetTime and GetTime() or 0) + 1.0
        end
    elseif eventName == "PLAYER_LEAVING_WORLD" then
        self:ReleaseAllInputs()
        self:CloseTransientSurfaces()
    end

    if self:IsActionEvent(eventName) and PRP_ActionBar then
        PRP_ActionBar:OnEvent(eventName, firstArg)
    end
    if PRP_Targeting then
        PRP_Targeting:OnEvent(eventName, firstArg)
    end
    if PRP_Inventory then
        PRP_Inventory:OnEvent(eventName, firstArg)
    end
    if PRP_Companion then
        PRP_Companion:OnEvent(eventName, firstArg)
    end
    if PRP_Focus then
        PRP_Focus:OnEvent(eventName, firstArg)
    end
end

function PRP:OnUpdate(elapsed)
    if not self.initialized then
        return
    end
    if PRP_Handheld and PRP_Handheld.OnUpdate then
        PRP_Handheld:OnUpdate(elapsed)
    end
    if PRP_UI and PRP_UI.OnUpdate then
        PRP_UI:OnUpdate(elapsed)
    end
    if PRP_ActionBar and PRP_ActionBar.OnUpdate then
        PRP_ActionBar:OnUpdate(elapsed)
    end
    if PRP_Targeting and PRP_Targeting.OnUpdate then
        PRP_Targeting:OnUpdate(elapsed)
    end
    if PRP_Inventory and PRP_Inventory.OnUpdate then
        PRP_Inventory:OnUpdate(elapsed)
    end
    if PRP_QuickMenu and PRP_QuickMenu.OnUpdate then
        PRP_QuickMenu:OnUpdate(elapsed)
    end
    if PRP_Companion and PRP_Companion.OnUpdate then
        PRP_Companion:OnUpdate(elapsed)
    end
    if PRP_Focus and PRP_Focus.OnUpdate then
        PRP_Focus:OnUpdate(elapsed)
    end
    if self.pendingGuideAt and (GetTime and GetTime() or 0) >= self.pendingGuideAt then
        local context = PRP_Router and PRP_Router.GetContext and PRP_Router:GetContext() or "WORLD"
        if PRP_Guide and not PRP_ChatEditActive()
            and not (PRP_Focus and PRP_Focus:HasModal()) and context == "WORLD" then
            self.pendingGuideAt = nil
            PRP_Guide:Show()
        else
            -- Do not interrupt chat, confirmations, or a menu the player opened.
            -- Retry shortly after the blocking context has gone away.
            self.pendingGuideAt = (GetTime and GetTime() or 0) + 0.50
        end
    end
end

function PRP_OnEvent()
    PRP:OnEvent(event, arg1)
end

function PRP_OnUpdate()
    PRP:OnUpdate(arg1 or 0)
end

PRP_EventFrame = CreateFrame("Frame", "PocketRealmPadEventFrame", UIParent)
PRP_EventFrame:RegisterEvent("ADDON_LOADED")
PRP_EventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
PRP_EventFrame:RegisterEvent("PLAYER_LEAVING_WORLD")
PRP_EventFrame:RegisterEvent("UPDATE_BINDINGS")
PRP_EventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_USABLE")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_STATE")
PRP_EventFrame:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
PRP_EventFrame:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
PRP_EventFrame:RegisterEvent("PLAYER_AURAS_CHANGED")
PRP_EventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
PRP_EventFrame:RegisterEvent("UNIT_HEALTH")
PRP_EventFrame:RegisterEvent("UNIT_MAXHEALTH")
PRP_EventFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
PRP_EventFrame:RegisterEvent("RAID_ROSTER_UPDATE")
PRP_EventFrame:RegisterEvent("BAG_UPDATE")
PRP_EventFrame:RegisterEvent("MERCHANT_SHOW")
PRP_EventFrame:RegisterEvent("MERCHANT_CLOSED")
PRP_EventFrame:RegisterEvent("BANKFRAME_OPENED")
PRP_EventFrame:RegisterEvent("BANKFRAME_CLOSED")
PRP_EventFrame:RegisterEvent("TRAINER_SHOW")
PRP_EventFrame:RegisterEvent("TRAINER_CLOSED")
PRP_EventFrame:RegisterEvent("CRAFT_SHOW")
PRP_EventFrame:RegisterEvent("CRAFT_CLOSE")
PRP_EventFrame:RegisterEvent("TRADE_SKILL_SHOW")
PRP_EventFrame:RegisterEvent("TRADE_SKILL_CLOSE")
PRP_EventFrame:RegisterEvent("TRADE_SHOW")
PRP_EventFrame:RegisterEvent("TRADE_CLOSED")
PRP_EventFrame:RegisterEvent("MAIL_SHOW")
PRP_EventFrame:RegisterEvent("MAIL_CLOSED")
PRP_EventFrame:RegisterEvent("AUCTION_HOUSE_SHOW")
PRP_EventFrame:RegisterEvent("AUCTION_HOUSE_CLOSED")
PRP_EventFrame:RegisterEvent("TAXIMAP_OPENED")
PRP_EventFrame:RegisterEvent("TAXIMAP_CLOSED")
PRP_EventFrame:RegisterEvent("GOSSIP_SHOW")
PRP_EventFrame:RegisterEvent("GOSSIP_CLOSED")
PRP_EventFrame:RegisterEvent("QUEST_GREETING")
PRP_EventFrame:RegisterEvent("QUEST_DETAIL")
PRP_EventFrame:RegisterEvent("QUEST_PROGRESS")
PRP_EventFrame:RegisterEvent("QUEST_COMPLETE")
PRP_EventFrame:RegisterEvent("QUEST_FINISHED")
PRP_EventFrame:RegisterEvent("LOOT_OPENED")
PRP_EventFrame:RegisterEvent("LOOT_CLOSED")
PRP_EventFrame:RegisterEvent("PET_BAR_UPDATE")
PRP_EventFrame:RegisterEvent("PET_BAR_UPDATE_COOLDOWN")
PRP_EventFrame:RegisterEvent("PET_BAR_SHOWGRID")
PRP_EventFrame:RegisterEvent("PET_BAR_HIDEGRID")
PRP_EventFrame:RegisterEvent("UPDATE_SHAPESHIFT_FORMS")
PRP_EventFrame:RegisterEvent("SPELL_UPDATE_COOLDOWN")
PRP_EventFrame:RegisterEvent("SPELL_UPDATE_USABLE")
PRP_EventFrame:RegisterEvent("UNIT_PET")
PRP_EventFrame:SetScript("OnEvent", PRP_OnEvent)
PRP_EventFrame:SetScript("OnUpdate", PRP_OnUpdate)
