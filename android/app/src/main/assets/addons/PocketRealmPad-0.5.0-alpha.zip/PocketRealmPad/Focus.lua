-- Explicit directional focus graph for known Vanilla UI frames.
-- This deliberately avoids generic protected-frame scanning.

PRP_Focus = {
    initialized = false,
    adapter = nil,
    nodes = {},
    index = 0,
    elapsed = 0,
    pendingConfirmFrame = nil,
    pendingConfirmUntil = 0,
    pendingConfirmText = nil,
}

function PRP_Focus:Initialize()
    self.initialized = true
    self:Detect(true)
end

function PRP_Focus:GetNow()
    if GetTime then return GetTime() or 0 end
    return 0
end

function PRP_Focus:IsConfirmationPending(node)
    if not node or not node.frame then return false end
    return self.pendingConfirmFrame == node.frame and self:GetNow() <= (self.pendingConfirmUntil or 0)
end

function PRP_Focus:ClearPendingConfirm(refreshVisual)
    local hadPending = self.pendingConfirmFrame ~= nil
    self.pendingConfirmFrame = nil
    self.pendingConfirmUntil = 0
    self.pendingConfirmText = nil
    if hadPending and refreshVisual ~= false then
        self:UpdateVisual()
    end
    return hadPending
end

function PRP_Focus:GetModalAdapter()
    if PRP_Adapters and PRP_Adapters.GetPopupAdapter then
        return PRP_Adapters:GetPopupAdapter()
    end
    return nil
end

function PRP_Focus:HasModal()
    return self:GetModalAdapter() ~= nil
end

function PRP_Focus:CustomSurfaceActive()
    if PRP_Inventory and PRP_Inventory.IsShown and PRP_Inventory:IsShown() then
        return true
    end
    if PRP_QuickMenu and PRP_QuickMenu.IsShown and PRP_QuickMenu:IsShown() then
        return true
    end
    if PRP_Companion and PRP_Companion.IsShown and PRP_Companion:IsShown() then
        return true
    end
    if PRP_Guide and PRP_Guide.IsShown and PRP_Guide:IsShown() then
        return true
    end
    return false
end

function PRP_Focus:IsActive()
    if not self.initialized or not PocketRealmPadDB then
        return false
    end
    if PocketRealmPadDB.safeMode == 1 or PocketRealmPadDB.focus.enabled ~= 1 then
        return false
    end
    if PRP_ChatEditActive() then return false end
    if self:CustomSurfaceActive() and not self:HasModal() then return false end
    return self.adapter ~= nil and PRP_TableLength(self.nodes) > 0
end

function PRP_Focus:FindFrameIndex(frame)
    local index
    for index = 1, PRP_TableLength(self.nodes) do
        if self.nodes[index].frame == frame then
            return index
        end
    end
    return 0
end

function PRP_Focus:BuildNodes(adapter, preserveFrame)
    local nodes = {}
    local index
    local node
    local filtered = {}
    local count = 0

    if adapter and adapter.Collect then
        adapter:Collect(nodes)
    end

    for index = 1, PRP_TableLength(nodes) do
        node = nodes[index]
        if node and node.frame and PRP_IsVisible(node.frame) and PRP_IsEnabled(node.frame) then
            count = count + 1
            filtered[count] = node
        end
    end

    self.nodes = filtered
    self.index = 0
    if preserveFrame then
        self.index = self:FindFrameIndex(preserveFrame)
    end
    if self.index == 0 and PRP_TableLength(self.nodes) > 0 then
        self.index = 1
    end
    if self.pendingConfirmFrame and self:FindFrameIndex(self.pendingConfirmFrame) == 0 then
        self:ClearPendingConfirm(false)
    end
    self:UpdateVisual()
end

function PRP_Focus:Detect(force)
    local adapter
    local oldFrame
    local oldId
    local newId

    if not self.initialized or not PRP_Adapters or not PRP_Adapters.GetActive then
        return
    end
    -- A forced refresh means the underlying UI may have changed because of
    -- touch, a panel event, or a rebuilt list. Never leave a destructive
    -- confirmation armed across that change.
    if force then
        self:ClearPendingConfirm(false)
    end
    if PocketRealmPadDB.safeMode == 1 or PocketRealmPadDB.focus.enabled ~= 1 then
        self:Clear()
        return
    end
    if PRP_ChatEditActive() then
        self:Clear()
        return
    end

    adapter = self:GetModalAdapter()
    if not adapter and self:CustomSurfaceActive() then
        self:Clear()
        return
    end

    oldId = self.adapter and self.adapter.id or nil
    oldFrame = self.nodes[self.index] and self.nodes[self.index].frame or nil
    if not adapter then adapter = PRP_Adapters:GetActive() end
    newId = adapter and adapter.id or nil

    if force or oldId ~= newId then
        if oldId ~= newId then self:ClearPendingConfirm(false) end
        self.adapter = adapter
        self:BuildNodes(adapter, oldId == newId and oldFrame or nil)
    elseif adapter then
        self:BuildNodes(adapter, oldFrame)
    end

    if self:IsActive() then
        PRP:SetMode("UI: " .. tostring(self.adapter.title or self.adapter.id))
    elseif not self:CustomSurfaceActive() and not PRP_ChatEditActive() then
        PRP:SetMode("WORLD")
        PRP_UI:ClearFocus()
        PRP_UI:SetPrompt("")
    end
end

function PRP_Focus:Clear()
    self:ClearPendingConfirm(false)
    self.adapter = nil
    self.nodes = {}
    self.index = 0
    if PRP_UI then
        PRP_UI:ClearFocus()
        PRP_UI:SetPrompt("")
    end
end

function PRP_Focus:UpdateVisual()
    local node = self.nodes[self.index]
    local label
    local confirmControl
    if not node then
        PRP_UI:ClearFocus()
        return
    end
    label = node.label or PRP_GetFrameLabel(node.frame, "Control")
    if node.confirm then
        confirmControl = PRP_ControlLabel("confirm")
        if self:IsConfirmationPending(node) then
            label = label .. " — press [" .. confirmControl .. "] again"
        else
            label = label .. " — press [" .. confirmControl .. "] twice"
        end
    end
    PRP_UI:SetFocus(node.frame, label)
end

function PRP_Focus:SetIndex(index)
    local count = PRP_TableLength(self.nodes)
    if count == 0 then
        self.index = 0
        self:UpdateVisual()
        return
    end
    if index < 1 then
        index = 1
    elseif index > count then
        index = count
    end
    if index ~= self.index then
        self:ClearPendingConfirm(false)
    end
    self.index = index
    self:UpdateVisual()
end

function PRP_Focus:GetDirectionalCandidate(dx, dy)
    local current = self.nodes[self.index]
    local currentX
    local currentY
    local candidate
    local candidateX
    local candidateY
    local vx
    local vy
    local forward
    local perpendicular
    local distance
    local score
    local bestScore
    local bestIndex
    local index

    if not current then
        return nil
    end
    currentX, currentY = PRP_FrameCenter(current.frame)
    if not currentX or not currentY then
        return nil
    end

    for index = 1, PRP_TableLength(self.nodes) do
        if index ~= self.index then
            candidate = self.nodes[index]
            candidateX, candidateY = PRP_FrameCenter(candidate.frame)
            if candidateX and candidateY then
                vx = candidateX - currentX
                vy = candidateY - currentY
                forward = (vx * dx) + (vy * dy)
                if forward > 1 then
                    perpendicular = math.abs((vx * dy) - (vy * dx))
                    distance = math.sqrt((vx * vx) + (vy * vy))
                    score = forward + (perpendicular * 2.8) + (distance * 0.05)
                    if not bestScore or score < bestScore then
                        bestScore = score
                        bestIndex = index
                    end
                end
            end
        end
    end
    return bestIndex
end

function PRP_Focus:GetWrapCandidate(dx, dy)
    local current = self.nodes[self.index]
    local currentX
    local currentY
    local candidateX
    local candidateY
    local primary
    local secondary
    local bestPrimary
    local bestSecondary
    local bestIndex
    local index
    if not current then
        return nil
    end
    currentX, currentY = PRP_FrameCenter(current.frame)
    if not currentX or not currentY then
        return nil
    end
    for index = 1, PRP_TableLength(self.nodes) do
        candidateX, candidateY = PRP_FrameCenter(self.nodes[index].frame)
        if candidateX and candidateY then
            if dx > 0 then
                primary = candidateX
                secondary = math.abs(candidateY - currentY)
                if not bestPrimary or primary < bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
                    bestPrimary = primary
                    bestSecondary = secondary
                    bestIndex = index
                end
            elseif dx < 0 then
                primary = candidateX
                secondary = math.abs(candidateY - currentY)
                if not bestPrimary or primary > bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
                    bestPrimary = primary
                    bestSecondary = secondary
                    bestIndex = index
                end
            elseif dy > 0 then
                primary = candidateY
                secondary = math.abs(candidateX - currentX)
                if not bestPrimary or primary < bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
                    bestPrimary = primary
                    bestSecondary = secondary
                    bestIndex = index
                end
            else
                primary = candidateY
                secondary = math.abs(candidateX - currentX)
                if not bestPrimary or primary > bestPrimary or (primary == bestPrimary and secondary < bestSecondary) then
                    bestPrimary = primary
                    bestSecondary = secondary
                    bestIndex = index
                end
            end
        end
    end
    return bestIndex
end

function PRP_Focus:ScrollForDirection(dy)
    local bars
    local index
    local bar
    local delta
    if not self.adapter or not self.adapter.scrollBars or dy == 0 then
        return false
    end
    bars = self.adapter.scrollBars
    delta = PocketRealmPadDB.focus.scrollStep or 40
    if dy > 0 then
        delta = -delta
    end
    for index = 1, PRP_TableLength(bars) do
        bar = PRP_GetFrame(bars[index])
        if PRP_IsVisible(bar) and PRP_ScrollBarStep(bar, delta) then
            return true
        end
    end
    return false
end

function PRP_Focus:Move(dx, dy)
    local candidate
    local preserve
    if not self:IsActive() then
        return false
    end
    candidate = self:GetDirectionalCandidate(dx, dy)
    if not candidate and self:ScrollForDirection(dy) then
        preserve = self.nodes[self.index] and self.nodes[self.index].frame or nil
        self:BuildNodes(self.adapter, preserve)
        candidate = self:GetDirectionalCandidate(dx, dy)
    end
    if not candidate and PocketRealmPadDB.focus.wrap == 1 then
        candidate = self:GetWrapCandidate(dx, dy)
    end
    if candidate then
        self:SetIndex(candidate)
        if PlaySound then
            PlaySound("igMainMenuOptionCheckBoxOn")
        end
        return true
    end
    return false
end

function PRP_Focus:Accept()
    local node
    local ok
    local seconds
    local confirmControl
    if not self:IsActive() then
        return false
    end
    node = self.nodes[self.index]
    if not node then
        return false
    end
    if node.confirm then
        if not self:IsConfirmationPending(node) then
            seconds = PocketRealmPadDB.focus.confirmSeconds or 4.0
            self.pendingConfirmFrame = node.frame
            self.pendingConfirmUntil = self:GetNow() + seconds
            self.pendingConfirmText = node.confirm
            confirmControl = PRP_ControlLabel("confirm")
            PRP_UI:ShowToast("Press [" .. confirmControl .. "] again: " .. tostring(node.confirm), seconds)
            self:UpdateVisual()
            return true
        end
        self:ClearPendingConfirm(false)
    end
    if node.accept then
        ok = node.accept(node.frame, node)
    else
        ok = PRP_InvokeFrame(node.frame, "LeftButton")
    end
    self:Detect(true)
    return ok and true or false
end

function PRP_Focus:Alternate()
    local node
    local ok
    if not self:IsActive() then
        return false
    end
    node = self.nodes[self.index]
    if not node then
        return false
    end
    self:ClearPendingConfirm(false)
    if node.alternate then
        ok = node.alternate(node.frame, node)
    else
        ok = PRP_InvokeFrame(node.frame, "RightButton")
    end
    self:Detect(true)
    return ok and true or false
end

function PRP_Focus:Back()
    local ok
    if not self:IsActive() then
        return false
    end
    if self:ClearPendingConfirm(true) then
        PRP_UI:ShowToast("Action cancelled", 1.5)
        return true
    end
    if self.adapter and self.adapter.Back then
        ok = self.adapter:Back()
    end
    self:Detect(true)
    return ok and true or false
end

function PRP_Focus:OnEvent(eventName, firstArg)
    if eventName == "GOSSIP_SHOW"
        or eventName == "GOSSIP_CLOSED"
        or eventName == "QUEST_GREETING"
        or eventName == "QUEST_DETAIL"
        or eventName == "QUEST_PROGRESS"
        or eventName == "QUEST_COMPLETE"
        or eventName == "QUEST_FINISHED"
        or eventName == "LOOT_OPENED"
        or eventName == "LOOT_CLOSED"
        or eventName == "MERCHANT_SHOW"
        or eventName == "MERCHANT_CLOSED"
        or eventName == "BANKFRAME_OPENED"
        or eventName == "BANKFRAME_CLOSED"
        or eventName == "TRAINER_SHOW"
        or eventName == "TRAINER_CLOSED"
        or eventName == "CRAFT_SHOW"
        or eventName == "CRAFT_CLOSE"
        or eventName == "TRADE_SKILL_SHOW"
        or eventName == "TRADE_SKILL_CLOSE"
        or eventName == "TRADE_SHOW"
        or eventName == "TRADE_CLOSED"
        or eventName == "MAIL_SHOW"
        or eventName == "MAIL_CLOSED"
        or eventName == "AUCTION_HOUSE_SHOW"
        or eventName == "AUCTION_HOUSE_CLOSED"
        or eventName == "TAXIMAP_OPENED"
        or eventName == "TAXIMAP_CLOSED" then
        self:Detect(true)
    end
end

function PRP_Focus:OnUpdate(elapsed)
    if self.pendingConfirmFrame and self:GetNow() > (self.pendingConfirmUntil or 0) then
        self:ClearPendingConfirm(true)
    end
    self.elapsed = self.elapsed + elapsed
    if self.elapsed >= (PocketRealmPadDB.focus.scanInterval or 0.12) then
        self.elapsed = 0
        self:Detect(false)
    end
end
