-- First-run controller and touch guide for players who are new to WoW.
-- It uses only stock 1.12 frames/fonts and can be reopened from the quick menu
-- or with /prp guide.

PRP_Guide = {
    initialized = false,
    page = 1,
    pageCount = 5,
}

function PRP_Guide:Initialize()
    if self.initialized then return end
    self.frame = PRP_UI:CreatePanel("PocketRealmPadGuide", 650, 470, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:Hide()

    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Welcome to Pocket Realm Pad")
    self.title:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 18, -16)
    self.title:SetJustifyH("LEFT")

    self.pageText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "1 / 5")
    self.pageText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -18, -20)
    self.pageText:SetJustifyH("RIGHT")

    self.heading = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormal", "Getting around")
    self.heading:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 20, -52)
    self.heading:SetJustifyH("LEFT")

    self.body = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlight", "")
    self.body:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 20, -82)
    self.body:SetJustifyH("LEFT")
    self.body:SetJustifyV("TOP")

    self.footer = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.footer:SetPoint("BOTTOM", self.frame, "BOTTOM", 0, 18)
    self.footer:SetJustifyH("CENTER")

    self.initialized = true
    self:ApplyMetrics()
    self:Refresh()
end

function PRP_Guide:IsShown()
    return self.frame and PRP_IsVisible(self.frame)
end

function PRP_Guide:GetPageContent(page)
    local target = PRP_ControlLabel("target")
    local targetFallback = PRP_ControlLabel("targetFallback")
    local interact = PRP_ControlLabel("interact")
    local jump = PRP_ControlLabel("jump")
    local jumpFallback = PRP_ControlLabel("jumpFallback")
    local menu = PRP_ControlLabel("menu")
    local inventory = PRP_ControlLabel("inventory")
    local layer1 = PRP_ControlLabel("layer1")
    local layer2 = PRP_ControlLabel("layer2")
    local bank = PRP_ControlLabel("bank")
    local confirm = PRP_ControlLabel("confirm")
    local back = PRP_ControlLabel("back")
    local alternate = PRP_ControlLabel("alternate")
    if page == 1 then
        return "Move, look, and choose a target",
            "Left stick: move. Keep your left thumb there during combat.\n\nRight stick: move the camera.\n\n[" .. jump .. "]: jump. [" .. jumpFallback .. "] is the stick-click backup.\n\n[" .. target .. "]: select the nearest enemy. [" .. targetFallback .. "] is the backup.\n\nThe rear buttons do only these safe tap actions; they are never purchases, items, or ability modifiers."
    elseif page == 2 then
        return "Touch, point, and interact",
            "WoW 1.12 has no automatic Interact button.\n\nTouch an NPC, object, or corpse—or place the pointer over it—then press [" .. interact .. "]. That sends a right-click at the pointer.\n\nUse touch for login, character creation, dragging, scroll bars, ground-target spells, and text or money fields."
    elseif page == 3 then
        return "Use abilities without a crowded screen",
            "The four face positions are abilities 1-4: right " .. PRP_ControlArrayLabel("face", 1) .. ", bottom " .. PRP_ControlArrayLabel("face", 2) .. ", left " .. PRP_ControlArrayLabel("face", 3) .. ", top " .. PRP_ControlArrayLabel("face", 4) .. ".\n\nHold [" .. bank .. "] with the same face positions for abilities 5-8. This keeps your left thumb on the upper movement stick.\n\nThe lower D-pad uses abilities 9-12 in the world and navigation in menus.\n\nHold [" .. layer1 .. "] or [" .. layer2 .. "] for more ability layers; hold both for a fourth."
    elseif page == 4 then
        return "Menus and bags",
            "[" .. menu .. "]: Quick Menu. [" .. inventory .. "]: controller inventory.\n\nRight [" .. confirm .. "] chooses, bottom [" .. back .. "] goes back, left [" .. alternate .. "] is More, and top [" .. PRP_ControlLabel("panelMenu") .. "] opens the Quick Menu from supported panels.\n\nThe D-pad moves the bright ring. Purchases, training, travel, crafting, mail, auctions, trades, and quest turn-ins ask for [" .. confirm .. "] twice.\n\nUse touch whenever no focus ring appears."
    end
    return "A simple first adventure",
        "1. Touch an NPC with a yellow !, then press [" .. interact .. "].\n\n2. Accept the quest and read its objective.\n\n3. Select an enemy with [" .. target .. "] and use an ability.\n\n4. Touch the defeated enemy, then press [" .. interact .. "] to loot.\n\n5. Equip useful gear and return when the NPC has a yellow ?.\n\nWhen finished, use the Android app's Save & Exit action."
end

function PRP_Guide:Refresh()
    local heading
    local body
    if not self.initialized then return end
    heading, body = self:GetPageContent(self.page)
    self.heading:SetText(heading)
    self.body:SetText(body)
    self.pageText:SetText(tostring(self.page) .. " / " .. tostring(self.pageCount))
    if self.page < self.pageCount then
        self.footer:SetText(PRP_ControlHint("Next", "confirm") .. "   " .. PRP_ControlHint("Close", "back") .. "   " .. PRP_ControlHint("Previous", "alternate"))
    else
        self.footer:SetText(PRP_ControlHint("Start playing", "confirm") .. "   " .. PRP_ControlHint("Close", "back") .. "   " .. PRP_ControlHint("Previous", "alternate"))
    end
end

function PRP_Guide:ApplyMetrics()
    local metrics
    local scale
    local width
    local height
    if not self.initialized or not PRP_Handheld then return end
    metrics = PRP_Handheld:GetMetrics()
    scale = PRP_Handheld:GetFontScale()
    width = metrics.guideWidth or 650
    height = metrics.guideHeight or 470
    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.title:SetWidth(width - 120)
    self.heading:SetWidth(width - 40)
    self.body:SetWidth(width - 40)
    self.body:SetHeight(height - 145)
    self.footer:SetWidth(width - 40)
    PRP_SetFontScale(self.title, scale, 14)
    PRP_SetFontScale(self.pageText, scale, 10)
    PRP_SetFontScale(self.heading, scale, 12)
    PRP_SetFontScale(self.body, scale, 11)
    PRP_SetFontScale(self.footer, scale, 10)
end

function PRP_Guide:Show()
    if not self.initialized or PocketRealmPadDB.safeMode == 1 then return false end
    if PRP_QuickMenu then PRP_QuickMenu:Hide() end
    if PRP_Inventory then PRP_Inventory:Hide() end
    if PRP_Companion then PRP_Companion:Hide() end
    self.page = 1
    self:Refresh()
    self.frame:Show()
    PRP_UI:ClearFocus()
    PRP_UI:SetPrompt("")
    PRP:SetMode("CONTROLS & HELP")
    return true
end

function PRP_Guide:Hide(markCompleted)
    if not self.frame then return end
    self.frame:Hide()
    if markCompleted ~= false and PocketRealmPadDB and PocketRealmPadDB.onboarding then
        PocketRealmPadDB.onboarding.completed = 1
    end
    if PRP_Focus then PRP_Focus:Detect(true) else PRP:SetMode("WORLD") end
end

function PRP_Guide:SetPage(page)
    if page < 1 then page = 1 end
    if page > self.pageCount then page = self.pageCount end
    self.page = page
    self:Refresh()
    return true
end

function PRP_Guide:Next()
    if self.page >= self.pageCount then
        self:Hide(true)
        return true
    end
    return self:SetPage(self.page + 1)
end

function PRP_Guide:Previous()
    if self.page <= 1 then return false end
    return self:SetPage(self.page - 1)
end

function PRP_Guide:Accept()
    return self:Next()
end

function PRP_Guide:Alternate()
    return self:Previous()
end

function PRP_Guide:Back()
    self:Hide(true)
    return true
end

function PRP_Guide:Navigate(direction)
    if direction == "RIGHT" or direction == "DOWN" then return self:Next() end
    if direction == "LEFT" or direction == "UP" then return self:Previous() end
    return false
end
