# Android handheld resolution and UI layout design — Pocket Realm Pad 0.5

## Design target

This is not a desktop UI scaled down. It is an Android handheld layout for a 5–6-inch landscape display, a physical controller, and a touchscreen. The controller handles repeatable actions; touch handles precision, text, and drag operations.

## Visual hierarchy

- Target card: top center, compact, always readable.
- World view: clear center, no permanent menu cluster.
- Ability bar: bottom center, two rows of four on handhelds.
- Focus prompt: bounded and temporary.
- Custom modal surfaces: centered and mutually exclusive.
- Stock Blizzard panels: retain their original location; a thick focus ring adds selection without reskinning the whole client.

## Profiles implemented in source

| Profile | Resolver class | Actions | Action UI units | Inventory | Focus line | Purpose |
|---|---|---|---|---|---|---|
| COMPACT_540 | ≤560 short side | 8 | 42 | 4×3 / 44 | 3 | Thermal/compatibility fallback |
| LEGACY_600 | ≤640 | 8 | 46 | 4×3 / 48 | 3 | 800×600 current safe-client proof |
| HANDHELD_720 | ≤760 | 8 | 54 | 4×3 / 54 | 4 | Balanced handheld default |
| HANDHELD_800 | ≤860 | 8 | 60 | 4×3 / 60 | 4 | 16:10 handheld |
| HANDHELD_900 | ≤1010 | 8 | 68 | 4×3 / 68 + detail | 4 | Higher-density handheld |
| RP6_1080 | handheld hint, ~1080 short side | 8 | 82 | 4×3 / 82 + detail | 6 | Native 1080p 5.5-inch handheld |
| HANDHELD_1200 | handheld hint, 1151–1320 | 8 | 90 | 4×3 / 90 + detail | 7 | 16:10 high-density handheld |
| HANDHELD_1440 | handheld hint, ≥1321 | 8 | 108 | 4×3 / 108 + detail | 8 | QHD handheld |
| TABLET | explicit hint or non-handheld aspect | 12 | 58 | 5×4 / 58 + detail | 4 | Android tablet |
| ANDROID_LARGE | explicit TV/large hint | 12 | 54 | 5×4 / 54 + detail | 4 | Android TV/external display |

Profile selection uses the short side so temporary orientation reporting does not select an unrelated size. A launcher device hint distinguishes a high-density handheld from a tablet or Android TV with a similar pixel count.

## Logical UI versus render resolution

WoW reports render dimensions through `GetScreenWidth/Height`, but frames are positioned in the logical `UIParent` desktop. Blizzard `uiScale` can make them different. Pocket Realm Pad resolves layout from `UIParent` and reports both values. The launcher owns:

- virtual desktop resolution;
- aspect-fit/letterbox geometry;
- Android surface resolution;
- `useUiScale` and `uiScale` defaults;
- touch coordinate conversion;
- safe insets and gesture-navigation calibration.

A 1920×1080 Android panel does not imply WoW must render at 1920×1080.

## Retroid Pocket 6 example

Official hardware specifies a 5.5-inch 1920×1080 AMOLED display. At 16:9 that is about 400.5 ppi, 4.79 inches wide, and 2.70 inches high.

| Render path | Addon profile | Ability size | Surface scale | Approx. panel pixels | Approx. physical size |
|---|---|---:|---:|---:|---:|
| 1280×720 → 1920×1080 | `HANDHELD_720` | 54 UI units | 1.5× | 81 px | 5.1 mm |
| Native 1920×1080 | `RP6_1080` | 82 UI units | 1.0× | 82 px | 5.2 mm |

This is intentional physical-size parity. The 720p profile is the beginner-balanced default because it reduces translated rendering load while remaining legible. Native 1080p is a measured quality profile.

Android recommends approximately 48×48 dp as a minimum touch target. WoW UI units are not Android dp, so the addon does not claim numeric equivalence; it applies the same principle—large, separated, labeled interactive cells—and validates physical size on the actual panel.

## RP6 Stick Top ergonomic layout

The RP6 Stick Top model puts the continuous movement stick above the D-pad. Community polls favored that arrangement for modern 3D games, while hands-on reviews describe the face buttons and wraparound shoulders as easy to reach, the D-pad as accurate but slightly small, occasional right-stick/face-thumb contact, and mixed opinions about the M1/M2 rear paddles.

The UI therefore mirrors the physical reach zones:

- visible cells 1–4: right A, bottom B, left Y, top X;
- visible cells 5–8: R1 plus those same four face positions;
- hidden/less-frequent cells 9–12: D-pad U/D/L/R;
- M1 target and M2 Jump by default, with Swap/Off options and L3/R3 fallbacks;
- no rear paddle is a modifier, item use, purchase, or destructive action.

The four face labels are position-calibrated by Android because raw A/B/X/Y reporting can differ from the printed RP6 labels.

## RP6 physical input calibration

The physical screen profile and controller profile are separate. The launcher calibrates the printed right-A/bottom-B/left-Y/top-X positions, offers Default/Swap/Off rear-button modes, and records measured stick dead zones. Because L2/R2 are analogue, it converts them to one clean digital down/up pair using separate on/off thresholds; initial hypotheses are 30/20% for L2 and 40/25% for R2. The addon never reads the axes itself.

## Ability-bar layout

Handhelds show eight permanent cells in a 4×2 rectangle. The top labels are physical controls. R1 maps the four face-button inputs to 5–8 without reshuffling the visible bar. L1/L2 update the entire layer label. Slot numbers are hidden.

Twelve permanent cells are used only on tablet/large-display profiles. This preserves world view and touch access on 5.5-inch hardware.

## Inventory layout

Handheld inventory is 4×3. The selected item name remains outside the grid. 900p and above add a detail pane rather than increasing cell count. Tablet/large profiles use 5×4.

Normal touch selects. Controller right A uses/equips, left Y picks up/places, bottom B closes. This prevents a stray touch from consuming or equipping an item.

## Quick Menu layout

The menu is a 3×3 grid with no analog radial requirement and no timed gesture.

**Page 1**

| Character | Quest Log | Spellbook |
|---|---|---|
| Social | Inventory | World Map |
| Pet & Forms | Chat | Game Menu |

**Page 2**

| Skills | Talents | Reputation |
|---|---|---|
| Pet Book | Controls & Help | Extra Bars |
| Friends | Guild | Keyring |

The center cell is optimized for return-to-center navigation and repeated use.

## Focus appearance

The outer focus ring is bright and 3–8 UI units thick by profile, with a dark inner separation edge. It remains recognizable without relying on color alone. Disabled/hidden controls are excluded. The prompt describes the selected control and confirmation state in plain language.

## Landscape and interruption policy

Gameplay should be landscape-locked. On activity pause, focus loss, overlay restart, IME open, profile switch, controller disconnect, or client exit, Android/Winlator must release all logically held keys/buttons. The addon also clears its captured action state when it receives world transitions, but cannot substitute for release at the Wine input bridge.

## Actual-client evidence still required

- 800×600, 960×540, 1280×720, 1280×800, 1600×900, 1920×1080, and tablet checks;
- physical readability at normal viewing distance;
- touch-coordinate alignment through letterboxing;
- no overlap with locale-specific quest text and stock panels;
- thermal/frame-time comparison at 720p versus native 1080p;
- novice task completion without developer coaching.
