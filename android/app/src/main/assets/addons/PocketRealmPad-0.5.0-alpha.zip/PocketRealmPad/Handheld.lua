-- Responsive metrics for Android handhelds, tablets, and large Android
-- displays. Render pixels and WoW's logical UI desktop are recorded separately.
-- The launcher owns resolution, letterboxing, useUiScale, and uiScale.

PRP_Handheld = {
    initialized = false,
    elapsed = 0,
    width = 0,
    height = 0,
    renderWidth = 0,
    renderHeight = 0,
    resolved = nil,
}

PRP_DISPLAY_PROFILES = {
    COMPACT_540 = {
        id="COMPACT_540", label="Compact Android 540p", visibleButtons=8,
        actionColumns=4, actionButton=42, actionSpacing=4, actionYOffset=56,
        inventoryColumns=4, inventoryRows=3, inventoryCell=44, inventorySpacing=4,
        quickButton=48, quickSpacing=5, companionButton=42, companionSpacing=4,
        targetWidth=430, targetHeight=66, targetYOffset=-34, targetHealthHeight=9, targetHealthYOffset=-31,
        promptWidth=500, promptHeight=30, toastWidth=390, toastHeight=48, toastYOffset=92,
        modeWidth=160, modeHeight=24, focusThickness=3, focusPad=4, fontScale=0.92,
        details=0, detailsWidth=0, guideWidth=500, guideHeight=360, edgePadding=8,
    },
    LEGACY_600 = {
        id="LEGACY_600", label="Android 800x600 / 600p", visibleButtons=8,
        actionColumns=4, actionButton=46, actionSpacing=4, actionYOffset=62,
        inventoryColumns=4, inventoryRows=3, inventoryCell=48, inventorySpacing=5,
        quickButton=52, quickSpacing=6, companionButton=46, companionSpacing=4,
        targetWidth=500, targetHeight=70, targetYOffset=-36, targetHealthHeight=9, targetHealthYOffset=-32,
        promptWidth=560, promptHeight=30, toastWidth=420, toastHeight=50, toastYOffset=100,
        modeWidth=170, modeHeight=24, focusThickness=3, focusPad=4, fontScale=0.96,
        details=0, detailsWidth=0, guideWidth=570, guideHeight=410, edgePadding=9,
    },
    HANDHELD_720 = {
        id="HANDHELD_720", label="Android handheld 720p", visibleButtons=8,
        actionColumns=4, actionButton=54, actionSpacing=5, actionYOffset=76,
        inventoryColumns=4, inventoryRows=3, inventoryCell=54, inventorySpacing=6,
        quickButton=60, quickSpacing=8, companionButton=52, companionSpacing=5,
        targetWidth=560, targetHeight=78, targetYOffset=-42, targetHealthHeight=10, targetHealthYOffset=-36,
        promptWidth=660, promptHeight=32, toastWidth=470, toastHeight=54, toastYOffset=128,
        modeWidth=196, modeHeight=26, focusThickness=4, focusPad=5, fontScale=1.00,
        details=0, detailsWidth=0, guideWidth=650, guideHeight=470, edgePadding=12,
    },
    HANDHELD_800 = {
        id="HANDHELD_800", label="Android handheld 800p / 16:10", visibleButtons=8,
        actionColumns=4, actionButton=60, actionSpacing=6, actionYOffset=88,
        inventoryColumns=4, inventoryRows=3, inventoryCell=60, inventorySpacing=7,
        quickButton=66, quickSpacing=9, companionButton=58, companionSpacing=6,
        targetWidth=620, targetHeight=88, targetYOffset=-48, targetHealthHeight=11, targetHealthYOffset=-39,
        promptWidth=710, promptHeight=34, toastWidth=500, toastHeight=58, toastYOffset=138,
        modeWidth=208, modeHeight=27, focusThickness=4, focusPad=5, fontScale=1.10,
        details=0, detailsWidth=0, guideWidth=720, guideHeight=520, edgePadding=13,
    },
    HANDHELD_900 = {
        id="HANDHELD_900", label="Android handheld 900p", visibleButtons=8,
        actionColumns=4, actionButton=68, actionSpacing=7, actionYOffset=104,
        inventoryColumns=4, inventoryRows=3, inventoryCell=68, inventorySpacing=8,
        quickButton=75, quickSpacing=10, companionButton=65, companionSpacing=7,
        targetWidth=700, targetHeight=98, targetYOffset=-54, targetHealthHeight=13, targetHealthYOffset=-43,
        promptWidth=760, promptHeight=36, toastWidth=520, toastHeight=62, toastYOffset=146,
        modeWidth=220, modeHeight=28, focusThickness=4, focusPad=6, fontScale=1.25,
        details=1, detailsWidth=220, guideWidth=800, guideHeight=580, edgePadding=14,
    },
    RP6_1080 = {
        id="RP6_1080", label="5.5-inch Android 1080p handheld", visibleButtons=8,
        actionColumns=4, actionButton=82, actionSpacing=8, actionYOffset=126,
        inventoryColumns=4, inventoryRows=3, inventoryCell=82, inventorySpacing=9,
        quickButton=88, quickSpacing=12, companionButton=78, companionSpacing=8,
        targetWidth=840, targetHeight=112, targetYOffset=-66, targetHealthHeight=16, targetHealthYOffset=-50,
        promptWidth=920, promptHeight=42, toastWidth=620, toastHeight=70, toastYOffset=168,
        modeWidth=240, modeHeight=32, focusThickness=6, focusPad=8, fontScale=1.50,
        details=1, detailsWidth=270, guideWidth=980, guideHeight=690, edgePadding=18,
    },
    HANDHELD_1200 = {
        id="HANDHELD_1200", label="Android handheld 1200p / 16:10", visibleButtons=8,
        actionColumns=4, actionButton=90, actionSpacing=9, actionYOffset=140,
        inventoryColumns=4, inventoryRows=3, inventoryCell=90, inventorySpacing=10,
        quickButton=98, quickSpacing=13, companionButton=87, companionSpacing=9,
        targetWidth=930, targetHeight=126, targetYOffset=-74, targetHealthHeight=18, targetHealthYOffset=-55,
        promptWidth=1020, promptHeight=46, toastWidth=690, toastHeight=78, toastYOffset=188,
        modeWidth=260, modeHeight=34, focusThickness=7, focusPad=9, fontScale=1.67,
        details=1, detailsWidth=300, guideWidth=1080, guideHeight=760, edgePadding=20,
    },
    HANDHELD_1440 = {
        id="HANDHELD_1440", label="Android handheld 1440p", visibleButtons=8,
        actionColumns=4, actionButton=108, actionSpacing=11, actionYOffset=168,
        inventoryColumns=4, inventoryRows=3, inventoryCell=108, inventorySpacing=12,
        quickButton=118, quickSpacing=16, companionButton=104, companionSpacing=11,
        targetWidth=1120, targetHeight=150, targetYOffset=-88, targetHealthHeight=22, targetHealthYOffset=-66,
        promptWidth=1200, promptHeight=56, toastWidth=820, toastHeight=92, toastYOffset=224,
        modeWidth=300, modeHeight=40, focusThickness=8, focusPad=10, fontScale=2.00,
        details=1, detailsWidth=360, guideWidth=1260, guideHeight=880, edgePadding=24,
    },
    TABLET = {
        id="TABLET", label="Android tablet", visibleButtons=12,
        actionColumns=6, actionButton=58, actionSpacing=6, actionYOffset=88,
        inventoryColumns=5, inventoryRows=4, inventoryCell=58, inventorySpacing=6,
        quickButton=66, quickSpacing=9, companionButton=58, companionSpacing=6,
        targetWidth=690, targetHeight=88, targetYOffset=-54, targetHealthHeight=13, targetHealthYOffset=-43,
        promptWidth=820, promptHeight=36, toastWidth=540, toastHeight=62, toastYOffset=146,
        modeWidth=220, modeHeight=28, focusThickness=4, focusPad=6, fontScale=1.25,
        details=1, detailsWidth=220, guideWidth=820, guideHeight=590, edgePadding=16,
    },
    ANDROID_LARGE = {
        id="ANDROID_LARGE", label="Android TV / large display", visibleButtons=12,
        actionColumns=6, actionButton=54, actionSpacing=6, actionYOffset=82,
        inventoryColumns=5, inventoryRows=4, inventoryCell=54, inventorySpacing=6,
        quickButton=64, quickSpacing=8, companionButton=56, companionSpacing=6,
        targetWidth=690, targetHeight=84, targetYOffset=-46, targetHealthHeight=11, targetHealthYOffset=-38,
        promptWidth=800, promptHeight=34, toastWidth=520, toastHeight=58, toastYOffset=136,
        modeWidth=210, modeHeight=28, focusThickness=4, focusPad=6, fontScale=1.15,
        details=1, detailsWidth=220, guideWidth=800, guideHeight=570, edgePadding=16,
    },
}

function PRP_Handheld:GetRenderSize()
    local width
    local height
    if GetScreenWidth then width = GetScreenWidth() end
    if GetScreenHeight then height = GetScreenHeight() end
    if not width or width <= 0 then width = 1280 end
    if not height or height <= 0 then height = 720 end
    return PRP_Round(width), PRP_Round(height)
end

function PRP_Handheld:GetLogicalSize()
    local width
    local height
    if UIParent and UIParent.GetWidth then width = UIParent:GetWidth() end
    if UIParent and UIParent.GetHeight then height = UIParent:GetHeight() end
    if not width or width <= 0 or not height or height <= 0 then
        width, height = self:GetRenderSize()
    end
    return PRP_Round(width), PRP_Round(height)
end

function PRP_Handheld:GetScreenSize()
    return self:GetLogicalSize()
end

function PRP_Handheld:NormalizeProfileName(value)
    local name = string.upper(tostring(value or "AUTO"))
    if name == "540" or name == "COMPACT" then return "COMPACT_540"
    elseif name == "600" or name == "SVGA" or name == "800X600" then return "LEGACY_600"
    elseif name == "720" or name == "HANDHELD" then return "HANDHELD_720"
    elseif name == "800" or name == "WXGA" or name == "16:10-800" then return "HANDHELD_800"
    elseif name == "900" then return "HANDHELD_900"
    elseif name == "1080" or name == "FHD" or name == "RP6" or name == "RETROID" then return "RP6_1080"
    elseif name == "1200" or name == "WUXGA" or name == "FHD+" or name == "16:10-1200" then return "HANDHELD_1200"
    elseif name == "1440" or name == "QHD" or name == "2K" then return "HANDHELD_1440"
    elseif name == "TABLET" then return "TABLET"
    elseif name == "ANDROID_LARGE" or name == "LARGE" or name == "TV" or name == "DESKTOP" then return "ANDROID_LARGE" end
    if PRP_DISPLAY_PROFILES[name] then return name end
    return "AUTO"
end

function PRP_Handheld:IsHandheldHint(hint)
    return hint == "HANDHELD" or hint == "ANDROID_HANDHELD" or hint == "HANDHELD_5_5"
        or hint == "RP6" or hint == "RETROID_POCKET_6"
end

function PRP_Handheld:Resolve(width, height)
    local requested = self:NormalizeProfileName(PocketRealmPadDB.display.profile)
    local hint = string.upper(tostring(PocketRealmPadDB.display.deviceHint or ""))
    local shortSide = math.min(width, height)
    local longSide = math.max(width, height)
    local aspect = longSide / shortSide
    if requested ~= "AUTO" then return requested end
    if hint == "TABLET" or hint == "ANDROID_TABLET" then return "TABLET" end
    if hint == "ANDROID_LARGE" or hint == "TV" or hint == "LARGE_DISPLAY" or hint == "DESKTOP" then return "ANDROID_LARGE" end
    if shortSide <= 560 then return "COMPACT_540" end
    if shortSide <= 640 then return "LEGACY_600" end
    if shortSide <= 760 then return "HANDHELD_720" end
    if shortSide <= 860 then return "HANDHELD_800" end
    if shortSide <= 1010 then return "HANDHELD_900" end
    if self:IsHandheldHint(hint) then
        if shortSide >= 1321 then return "HANDHELD_1440" end
        if shortSide >= 1151 then return "HANDHELD_1200" end
        return "RP6_1080"
    end
    if aspect < 1.55 then return "TABLET" end
    return "ANDROID_LARGE"
end

function PRP_Handheld:GetMetrics()
    local name = self.resolved or "HANDHELD_720"
    return PRP_DISPLAY_PROFILES[name] or PRP_DISPLAY_PROFILES.HANDHELD_720
end

function PRP_Handheld:GetFontScale()
    local metrics = self:GetMetrics()
    return (metrics.fontScale or 1) * (PocketRealmPadDB.textScale or 1)
end

function PRP_Handheld:Apply(force)
    local width, height = self:GetLogicalSize()
    local renderWidth, renderHeight = self:GetRenderSize()
    local resolved = self:Resolve(width, height)
    local changed = force or width ~= self.width or height ~= self.height
        or renderWidth ~= self.renderWidth or renderHeight ~= self.renderHeight
        or resolved ~= self.resolved
    if not changed then return false end
    self.width = width
    self.height = height
    self.renderWidth = renderWidth
    self.renderHeight = renderHeight
    self.resolved = resolved
    PocketRealmPadDB.display.lastResolved = resolved
    if PRP_UI and PRP_UI.ApplyMetrics then PRP_UI:ApplyMetrics() end
    if PRP_ActionBar and PRP_ActionBar.ApplyMetrics then PRP_ActionBar:ApplyMetrics() end
    if PRP_Targeting and PRP_Targeting.ApplyMetrics then PRP_Targeting:ApplyMetrics() end
    if PRP_Inventory and PRP_Inventory.ApplyMetrics then PRP_Inventory:ApplyMetrics() end
    if PRP_QuickMenu and PRP_QuickMenu.ApplyMetrics then PRP_QuickMenu:ApplyMetrics() end
    if PRP_Companion and PRP_Companion.ApplyMetrics then PRP_Companion:ApplyMetrics() end
    if PRP_Guide and PRP_Guide.ApplyMetrics then PRP_Guide:ApplyMetrics() end
    if PRP and PRP.Debug then
        PRP:Debug("render " .. tostring(renderWidth) .. "x" .. tostring(renderHeight)
            .. "; UI " .. tostring(width) .. "x" .. tostring(height) .. " -> " .. tostring(resolved))
    end
    return true
end

function PRP_Handheld:SetProfile(value)
    local name = self:NormalizeProfileName(value)
    PocketRealmPadDB.display.profile = name
    self:Apply(true)
    return name
end

function PRP_Handheld:StatusText()
    local metrics = self:GetMetrics()
    return "render=" .. tostring(self.renderWidth) .. "x" .. tostring(self.renderHeight)
        .. "; UI=" .. tostring(self.width) .. "x" .. tostring(self.height)
        .. "; profile=" .. tostring(self.resolved)
        .. "; actions=" .. tostring(metrics.visibleButtons)
        .. "; actionSize=" .. tostring(metrics.actionButton)
end

function PRP_Handheld:Initialize()
    self.initialized = true
    self:Apply(true)
end

function PRP_Handheld:OnUpdate(elapsed)
    if not self.initialized then return end
    self.elapsed = self.elapsed + elapsed
    if self.elapsed < (PocketRealmPadDB.display.autoRefreshSeconds or 0.75) then return end
    self.elapsed = 0
    self:Apply(false)
end
