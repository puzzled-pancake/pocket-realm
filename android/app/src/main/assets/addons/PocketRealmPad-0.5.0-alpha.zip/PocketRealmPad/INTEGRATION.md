# Android / Winlator / addon integration contract — Pocket Realm Pad 0.5

## Product boundary

The RP6 controller never talks directly to Lua. Android/Winlator converts physical controller and touchscreen input into reliable keyboard and mouse events. Pocket Realm Pad uses only WoW 1.12.1 bindings and FrameXML-compatible APIs.

## RP6 Stick Top contract

The launcher stores `mappingProfile=retroid-pocket-6-stick-top-v5` and calibrates face controls by physical position:

| Physical input | Semantic output |
|---|---|
| Right A / bottom B / left Y / top X | PRP actions 1/2/3/4 |
| R1 | PRP bank modifier; face positions become actions 5–8 |
| D-pad U/D/L/R | PRP navigation; actions 9–12 in world |
| L1 / L2 | PRP layers 2/3; both = layer 4 |
| M1 and L3 fallback | PRP nearest enemy |
| M2 and R3 fallback | stock `JUMP` |
| R2 | right mouse button at current pointer |
| Start / Select | Quick Menu / Controller Inventory |

The launcher offers Default, Swap M1/M2, and Rear buttons off for users who bump or prefer the rear controls differently. L3/R3 always produce the same target/jump fallbacks. The launcher synchronizes the selected printed labels into the managed addon profile before launch.

## Why this ordering

The upper-left stick is continuous movement. The lower D-pad must not hold the core combat set because that would force the left thumb off movement. The face cluster plus easy-to-chord R1 gives eight common abilities to the right hand; the lower D-pad carries four less-frequent abilities and menu navigation.

## Touch is first-class

Touch handles login, character creation, exact NPC/object/corpse selection, dragging, scroll bars, text/money fields, ground-target spells, and unsupported/ambiguous controls. R2 supplies right-click after touch or pointer placement.

## Context and release safety

Routing priority:

```text
CHAT > MODAL POPUP > CONTROLS & HELP > QUICK MENU > INVENTORY
     > PET & FORMS > SUPPORTED BLIZZARD WINDOW > WORLD
```

Context and action meaning are captured on key-down. Android must still release all physical/synthetic states on focus loss, IME, disconnect, or client exit.

## Display profile

For the 5.5-inch RP6:

- balanced default: 1280×720 virtual desktop, `HANDHELD_720`, 30 FPS initial cap;
- native quality: 1920×1080 virtual desktop, `RP6_1080`, measured 30/45/60 FPS;
- never infer touch coordinates from panel resolution alone; use the actual letterbox matrix.

## Setup acceptance

The launcher does not mark controls complete until it verifies:

1. four face physical positions with printed A-confirm/B-back semantics;
2. R1 + each face position;
3. D-pad directions;
4. M1/M2 and L3/R3 duplicates;
5. R2 pointer right-click;
6. movement and camera dead zones with clean neutral return;
7. L2/R2 digital thresholds and hysteresis produce one down/up pair;
8. focus-loss release-all;
9. no synthetic-key collision;
10. rear-paddle accidental-press grip test plus Default/Swap/Off choice;
11. on-screen labels match the printed hardware.
