-- Controller-first inventory browser for backpack and bags 1-4.
-- It uses only the Vanilla container API and keeps pointer mode as the fallback
-- for drag trajectories, split stacks, and unsupported third-party panels.

PRP_Inventory = {
    initialized = false,
    entries = {},
    cells = {},
    selected = 1,
    page = 1,
    pageSize = 12,
    maxCells = 20,
    rebuildPending = false,
    elapsed = 0,
    pendingSaleKey = nil,
    pendingSaleUntil = 0,
}

function PRP_Inventory:CreateCell(index)
    local button = CreateFrame("Button", "PocketRealmPadInventoryCell" .. index, self.frame)
    local icon
    local count
    local bagText
    local border
    button.prpCellIndex = index
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    button.icon = icon

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    button.border = border

    count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    count:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 2)
    button.count = count

    bagText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    bagText:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    bagText:SetJustifyH("LEFT")
    button.bagText = bagText

    button:SetScript("OnEnter", PRP_InventoryCell_OnEnter)
    button:SetScript("OnLeave", PRP_InventoryCell_OnLeave)
    button:SetScript("OnClick", PRP_InventoryCell_OnClick)
    self.cells[index] = button
end

function PRP_Inventory:Initialize()
    local index
    if self.initialized then return end
    self.frame = PRP_UI:CreatePanel("PocketRealmPadInventory", 310, 270, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:Hide()
    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Controller inventory")
    self.title:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -12)
    self.pageText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "Page 1 / 1")
    self.pageText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -14, -17)
    self.selectedName = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormal", "Empty slot")
    self.selectedName:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -38)
    self.selectedName:SetJustifyH("LEFT")
    self.hint = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.hint:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 14, 12)
    self.hint:SetJustifyH("LEFT")
    self.detailTitle = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormal", "Selected item")
    self.detailText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.detailText:SetJustifyH("LEFT")
    self.detailText:SetJustifyV("TOP")
    for index = 1, self.maxCells do
        self:CreateCell(index)
    end
    self.initialized = true
    self:ApplyMetrics()
    self:Rebuild(true)
end

function PRP_Inventory:ApplyMetrics()
    local metrics
    local columns
    local rows
    local size
    local spacing
    local gridWidth
    local detailsWidth
    local width
    local height
    local index
    local column
    local row
    local cell
    local fontScale
    if not self.initialized or not PRP_Handheld then return end
    metrics = PRP_Handheld:GetMetrics()
    fontScale = PRP_Handheld:GetFontScale()
    columns = metrics.inventoryColumns
    rows = metrics.inventoryRows
    size = metrics.inventoryCell
    spacing = metrics.inventorySpacing
    self.pageSize = columns * rows
    detailsWidth = metrics.details == 1 and (metrics.detailsWidth or 220) or 0
    gridWidth = (columns * size) + ((columns - 1) * spacing)
    width = 28 + gridWidth + (detailsWidth > 0 and (detailsWidth + 16) or 0)
    height = 106 + (rows * size) + ((rows - 1) * spacing)

    PocketRealmPadDB.inventory.columns = columns
    PocketRealmPadDB.inventory.rows = rows
    PocketRealmPadDB.inventory.cellSize = size
    PocketRealmPadDB.inventory.spacing = spacing
    PocketRealmPadDB.inventory.showDetails = metrics.details

    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.hint:SetWidth(width - 28)
    self.selectedName:SetWidth(width - 28)

    for index = 1, self.maxCells do
        cell = self.cells[index]
        cell:SetWidth(size)
        cell:SetHeight(size)
        PRP_SetFontScale(cell.count, fontScale, 10)
        PRP_SetFontScale(cell.bagText, fontScale, 10)
        cell.border:SetWidth(size * 1.72)
        cell.border:SetHeight(size * 1.72)
        cell:ClearAllPoints()
        if index <= self.pageSize then
            column = math.mod(index - 1, columns)
            row = math.floor((index - 1) / columns)
            cell:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14 + (column * (size + spacing)), -66 - (row * (size + spacing)))
            cell:Show()
        else
            cell:Hide()
        end
    end

    if detailsWidth > 0 then
        self.detailTitle:ClearAllPoints()
        self.detailTitle:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14 + gridWidth + 16, -70)
        self.detailTitle:Show()
        self.detailText:ClearAllPoints()
        self.detailText:SetPoint("TOPLEFT", self.detailTitle, "BOTTOMLEFT", 0, -10)
        self.detailText:SetWidth(detailsWidth)
        self.detailText:SetHeight(height - 134)
        self.detailText:Show()
    else
        self.detailTitle:Hide()
        self.detailText:Hide()
    end
    PRP_SetFontScale(self.title, fontScale, 14)
    PRP_SetFontScale(self.pageText, fontScale, 10)
    PRP_SetFontScale(self.selectedName, fontScale, 12)
    PRP_SetFontScale(self.hint, fontScale, 10)
    PRP_SetFontScale(self.detailTitle, fontScale, 12)
    PRP_SetFontScale(self.detailText, fontScale, 10)
    self:NormalizeSelection()
    self:UpdateVisual()
end

function PRP_Inventory:IsShown()
    return self.initialized and PRP_IsVisible(self.frame)
end

function PRP_Inventory:BuildEntries()
    local entries = {}
    local count = 0
    local bag
    local slot
    local slots
    for bag = 0, 4 do
        slots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            count = count + 1
            entries[count] = { bag = bag, slot = slot }
        end
    end
    self.entries = entries
end

function PRP_Inventory:GetPageCount()
    local total = PRP_TableLength(self.entries)
    if total < 1 then return 1 end
    return math.floor((total + self.pageSize - 1) / self.pageSize)
end

function PRP_Inventory:NormalizeSelection()
    local total = PRP_TableLength(self.entries)
    if total < 1 then
        self.selected = 1
        self.page = 1
        return
    end
    if self.selected < 1 then self.selected = 1 end
    if self.selected > total then self.selected = total end
    self.page = math.floor((self.selected - 1) / self.pageSize) + 1
end

function PRP_Inventory:GetCellGlobalIndex(cellIndex)
    return ((self.page - 1) * self.pageSize) + cellIndex
end

function PRP_Inventory:GetSelectedEntry()
    return self.entries[self.selected]
end

function PRP_Inventory:GetEntryKey(entry)
    if not entry then return nil end
    return tostring(entry.bag) .. ":" .. tostring(entry.slot)
end

function PRP_Inventory:CancelSale()
    self.pendingSaleKey = nil
    self.pendingSaleUntil = 0
end

function PRP_Inventory:UpdateCell(cellIndex)
    local cell = self.cells[cellIndex]
    local globalIndex = self:GetCellGlobalIndex(cellIndex)
    local entry = self.entries[globalIndex]
    local texture
    local itemCount
    local locked
    local quality
    local r
    local g
    local b
    if not cell then return end
    cell.prpGlobalIndex = globalIndex
    cell.prpEntry = entry
    if not entry then
        cell.icon:SetTexture(nil)
        cell.icon:Hide()
        cell.count:SetText("")
        cell.bagText:SetText("")
        cell.border:SetVertexColor(0.25, 0.25, 0.25, 0.35)
        cell:SetAlpha(0.25)
        return
    end
    texture, itemCount, locked, quality = GetContainerItemInfo(entry.bag, entry.slot)
    if texture then
        cell.icon:SetTexture(texture)
        cell.icon:Show()
        cell:SetAlpha(locked and 0.45 or 1)
    else
        cell.icon:SetTexture("Interface\\Buttons\\UI-EmptySlot")
        cell.icon:Show()
        cell:SetAlpha(0.54)
    end
    if itemCount and itemCount > 1 then cell.count:SetText(itemCount) else cell.count:SetText("") end
    if PocketRealmPadDB.debug == 1 then
        cell.bagText:SetText(tostring(entry.bag) .. ":" .. tostring(entry.slot))
    else
        cell.bagText:SetText("")
    end
    if globalIndex == self.selected then
        cell.border:SetVertexColor(1, 0.82, 0, 1)
    elseif texture then
        r, g, b = PRP_ColorFromQuality(quality)
        cell.border:SetVertexColor(r, g, b, 0.65)
    else
        cell.border:SetVertexColor(0.25, 0.25, 0.25, 0.35)
    end
    cell.border:Show()
end


function PRP_Inventory:GetEntryName(entry)
    local texture
    local link
    local name
    if not entry then return "No bag slots available" end
    texture = GetContainerItemInfo and GetContainerItemInfo(entry.bag, entry.slot) or nil
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil
    name = PRP_GetItemNameFromLink(link)
    if name then return name end
    if texture then return "Item" end
    return "Empty slot"
end

function PRP_Inventory:GetBagLabel(bag)
    if bag == 0 then return "Backpack" end
    return "Bag " .. tostring(bag)
end

function PRP_Inventory:UpdateDetails()
    local entry = self:GetSelectedEntry()
    local texture
    local count
    local locked
    local quality
    local link
    local name
    local text
    if not entry then
        self.selectedName:SetText("No bag slots available")
        self.detailText:SetText("No bag slots available.")
        return
    end
    texture, count, locked, quality = GetContainerItemInfo(entry.bag, entry.slot)
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil
    name = self:GetEntryName(entry)
    self.selectedName:SetText(name)
    text = name .. "\n\n" .. self:GetBagLabel(entry.bag)
        .. "\nCount: " .. tostring(count or 0)
    if PocketRealmPadDB.debug == 1 then
        text = text .. "\nSlot: " .. tostring(entry.slot)
    end
    if locked then text = text .. "\n|cffff6060Locked|r" end
    if self.pendingSaleKey == self:GetEntryKey(entry) then
        text = text .. "\n\n|cffffd100Sale ready. Confirm or cancel.|r"
    elseif PRP_IsVisible(MerchantFrame) and link then
        text = text .. "\n\nConfirm before selling"
    elseif link then
        text = text .. "\n\nUse or equip"
    else
        text = text .. "\n\nPick up or place"
    end
    self.detailText:SetText(text)
end

function PRP_Inventory:UpdateHint()
    local entry = self:GetSelectedEntry()
    local link
    if not entry then
        self.hint:SetText(PRP_ControlHint("Close", "back"))
        return
    end
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil
    if self.pendingSaleKey == self:GetEntryKey(entry) then
        self.hint:SetText(PRP_ControlHint("Confirm sale", "confirm") .. "   " .. PRP_ControlHint("Cancel", "back"))
    elseif PRP_IsVisible(MerchantFrame) and link then
        self.hint:SetText(PRP_ControlHint("Prepare sale", "confirm") .. "   " .. PRP_ControlHint("Pick up", "alternate") .. "   " .. PRP_ControlHint("Close", "back"))
    elseif link then
        self.hint:SetText(PRP_ControlHint("Use / equip", "confirm") .. "   " .. PRP_ControlHint("Pick up", "alternate") .. "   " .. PRP_ControlHint("Close", "back"))
    elseif CursorHasItem and CursorHasItem() then
        self.hint:SetText(PRP_ControlHint("Place here", "confirm") .. "   " .. PRP_ControlHint("Close", "back"))
    else
        self.hint:SetText(PRP_ControlHint("Pick up / place", "alternate") .. "   " .. PRP_ControlHint("Close", "back"))
    end
end

function PRP_Inventory:UpdateVisual()
    local index
    local pages = self:GetPageCount()
    for index = 1, self.pageSize do self:UpdateCell(index) end
    self.pageText:SetText("Page " .. tostring(self.page) .. " / " .. tostring(pages))
    self:UpdateHint()
    self:UpdateDetails()
    if self:IsShown() then
        local cellIndex = self.selected - ((self.page - 1) * self.pageSize)
        PRP:SetMode("INVENTORY")
        if self.cells[cellIndex] then
            PRP_UI:SetFocus(self.cells[cellIndex], self:GetEntryName(self:GetSelectedEntry()), false)
        end
    end
end

function PRP_Inventory:Rebuild(force)
    if not self.initialized then return end
    self:BuildEntries()
    self:NormalizeSelection()
    self:UpdateVisual()
    self.rebuildPending = false
end

function PRP_Inventory:Show()
    if not self.initialized or PocketRealmPadDB.safeMode == 1 then return false end
    if PRP_QuickMenu then PRP_QuickMenu:Hide() end
    if PRP_Companion then PRP_Companion:Hide() end
    if PRP_Guide then PRP_Guide:Hide(false) end
    self:CancelSale()
    self.frame:Show()
    self:Rebuild(true)
    PRP:SetMode("INVENTORY")
    return true
end

function PRP_Inventory:Hide()
    if not self.frame then return end
    self:CancelSale()
    self.frame:Hide()
    if GameTooltip then GameTooltip:Hide() end
    PRP_UI:SetPrompt("")
    PRP_UI:ClearFocus()
    if PRP_Focus then PRP_Focus:Detect(true) else PRP:SetMode("WORLD") end
end

function PRP_Inventory:Toggle()
    if self:IsShown() then self:Hide() else self:Show() end
end

function PRP_Inventory:SetSelected(index)
    local total = PRP_TableLength(self.entries)
    if total < 1 then
        self.selected = 1
        self.page = 1
        self:UpdateVisual()
        return false
    end
    while index < 1 do index = index + total end
    while index > total do index = index - total end
    if index ~= self.selected then self:CancelSale() end
    self.selected = index
    self:NormalizeSelection()
    self:UpdateVisual()
    if PlaySound then PlaySound("igMainMenuOptionCheckBoxOn") end
    return true
end

function PRP_Inventory:Navigate(direction)
    local columns = PocketRealmPadDB.inventory.columns or 4
    local nextIndex = self.selected
    if direction == "LEFT" then nextIndex = nextIndex - 1
    elseif direction == "RIGHT" then nextIndex = nextIndex + 1
    elseif direction == "UP" then nextIndex = nextIndex - columns
    elseif direction == "DOWN" then nextIndex = nextIndex + columns
    else return false end
    return self:SetSelected(nextIndex)
end

function PRP_Inventory:Accept()
    local entry = self:GetSelectedEntry()
    local link
    local key
    local now
    local confirmSeconds
    if not entry then return false end
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil
    if not link then
        if CursorHasItem and CursorHasItem() and PickupContainerItem then
            PickupContainerItem(entry.bag, entry.slot)
            self.rebuildPending = true
            return true
        end
        PRP_UI:ShowToast("Empty bag slot")
        return false
    end
    if PRP_IsVisible(MerchantFrame) then
        key = self:GetEntryKey(entry)
        now = GetTime and GetTime() or 0
        confirmSeconds = PocketRealmPadDB.inventory.sellConfirmSeconds or 5.0
        if self.pendingSaleKey == key and now <= self.pendingSaleUntil then
            self:CancelSale()
            UseContainerItem(entry.bag, entry.slot)
            PRP_UI:ShowToast("Sale requested: " .. self:GetEntryName(entry))
            self.rebuildPending = true
            return true
        end
        self.pendingSaleKey = key
        self.pendingSaleUntil = now + confirmSeconds
        PRP_UI:ShowToast("Confirm sale of " .. self:GetEntryName(entry) .. " with [" .. PRP_ControlLabel("confirm") .. "]")
        self:UpdateVisual()
        return true
    end
    self:CancelSale()
    if UseContainerItem then
        UseContainerItem(entry.bag, entry.slot)
        self.rebuildPending = true
        return true
    end
    return false
end

function PRP_Inventory:Alternate()
    local entry = self:GetSelectedEntry()
    if not entry or not PickupContainerItem then return false end
    self:CancelSale()
    PickupContainerItem(entry.bag, entry.slot)
    self.rebuildPending = true
    return true
end

function PRP_Inventory:Back()
    if self.pendingSaleKey then
        self:CancelSale()
        self:UpdateVisual()
        PRP_UI:ShowToast("Sale cancelled")
        return true
    end
    self:Hide()
    return true
end

function PRP_Inventory:OnEvent(eventName, firstArg)
    if eventName == "BAG_UPDATE" then
        self:CancelSale()
        self.rebuildPending = true
    elseif eventName == "MERCHANT_SHOW" or eventName == "MERCHANT_CLOSED" then
        self:CancelSale()
        if self:IsShown() then self:UpdateVisual() end
    end
end

function PRP_Inventory:OnUpdate(elapsed)
    local now
    self.elapsed = self.elapsed + elapsed
    if self.pendingSaleKey then
        now = GetTime and GetTime() or 0
        if now > self.pendingSaleUntil or not PRP_IsVisible(MerchantFrame) then
            self:CancelSale()
            if self:IsShown() then self:UpdateVisual() end
        end
    end
    if self.rebuildPending and self.elapsed >= 0.08 then
        self.elapsed = 0
        self:Rebuild(false)
    elseif self.elapsed >= 0.25 then
        self.elapsed = 0
    end
end

function PRP_InventoryCell_OnEnter()
    local cell = this
    local entry = cell and cell.prpEntry
    if not entry or not GameTooltip or not GameTooltip.SetBagItem then return end
    GameTooltip:SetOwner(cell, "ANCHOR_RIGHT")
    GameTooltip:SetBagItem(entry.bag, entry.slot)
    GameTooltip:Show()
end

function PRP_InventoryCell_OnLeave()
    if GameTooltip then GameTooltip:Hide() end
end

function PRP_InventoryCell_OnClick()
    local cell = this
    local index = cell and cell.prpGlobalIndex
    if not index then return end
    -- A normal touch/click only selects. This prevents an accidental tap on a
    -- small handheld screen from consuming or equipping an item. A secondary
    -- click keeps Vanilla's familiar use/equip meaning; controller [A] and [X]
    -- remain the primary use and pickup controls.
    PRP_Inventory:SetSelected(index)
    if arg1 == "RightButton" then PRP_Inventory:Accept() end
end
