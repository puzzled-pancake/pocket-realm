# Novice Android UX sanity audit — Pocket Realm Pad 0.5

## Verdict

The v0.5 design is coherent for a controller-plus-touch Android player who has never played WoW, provided the Android launcher performs binding setup and explains that touch is a first-class input. The design should not be shipped as “controller-only.” It is intentionally **controller for repeatable gameplay + touch for precision and text**.

## Audit method

The review traced the player journey from login through first quest, combat, looting, bags, spell placement, menus, chat, purchase/travel/trade/mail/auction flows, focus loss, and shutdown. Every custom command was checked against the Vanilla 1.12 action model and every supported panel was checked for whether controller activation is reversible, costly, destructive, text-heavy, or drag-heavy.

## Findings fixed through v0.5

| Finding | Why it was confusing or unsafe | v0.5 resolution |
|---|---|---|
| Stick-click Jump was workable but rear paddles were unused | The RP6 rear controls can preserve both thumbs on the sticks, but some users dislike or bump them. | M2 is primary Jump with R3 as a complete fallback; the launcher offers Default, Swap M1/M2, and Off modes. |
| Targeting originally consumed a stick click | Frequent targeting should not require pressing the movement stick. | M1 is primary nearest-enemy targeting, L3 is fallback, the rear pair can be swapped, and Target Self remains Advanced/unbound. |
| R2 wording implied target-based interaction | Vanilla has no Interact-with-target binding. | Every guide now says R2 right-clicks at the **current pointer**. |
| Quick Menu used hidden tap/hold/latch timing | Timing modes are hard to discover and fragile under Wine input timing. | Start is a simple press-to-toggle command. |
| Inventory touchscreen click could use an item | A normal touch could cause an unwanted consumable/equip action. | Normal touch selects; right A or secondary click uses/equips. |
| Risky panel actions were single-press | Purchases and commitments are easy to trigger while learning focus navigation. | Right A twice within four seconds; bottom B, movement, timeout, panel close, or forced refresh cancels. |
| Game Menu exposed desktop Quit/Logout | The correct appliance shutdown is Android Save & Exit. | Controller focus includes settings/continue only. |
| Technical labels leaked into player UI | Raw action slots and bag slot numbers add noise. | Hidden by default; friendly bag names and control labels are used. |
| Beginner bindings were mixed with 85 advanced entries | A new player could not tell what was actually required. | 14 Essentials appear first and contiguously; the rest are Advanced. |
| No setup completeness signal | Missing one semantic binding looked like a broken addon. | `/prp status` and launcher integration report `bound/14`. |
| Tutorial could interrupt the player | Opening over chat or a panel creates immediate distrust. | Five-page guide retries until the world context is clear. |
| Empty pet/form panel looked broken | Not every class has pet or form controls. | Explicit class-appropriate empty-state text. |
| Quick Menu center was not optimized | Center is the easiest place to return to and select. | Inventory is page-1 center; Controls & Help is page-2 center. |
| Chat could trigger shortcuts | Typed keys or controller events could open surfaces or fire helpers. | Router and direct helpers suppress commands while chat is active. |
| Confirmation could survive a UI rebuild | A changed panel could retain stale intent. | Forced focus refresh clears pending confirmation. |

## Control-scheme sanity check

| Control | World meaning | Menu/touch meaning |
|---|---|---|
| Left stick | Move forward/back and strafe | Winlator sends stock movement key down/up events. |
| Right stick | Camera look | Winlator sends relative mouse movement while camera-look is active. |
| Right A / Bottom B / Left Y / Top X | Abilities 1 / 2 / 3 / 4 | In supported panels: Confirm / Back / More / Quick Menu. |
| D-pad | Abilities 9 / 10 / 11 / 12 | In menus and addon grids: move selection. |
| R1 + A/B/Y/X | Abilities 5 / 6 / 7 / 8 | R1 is a compact ability bank, not a general menu modifier. |
| L1 | Ability layer 2 | Maps to ordinary action page 2; page 6 in Extra Bars mode. |
| L2 | Ability layer 3 | Maps to ordinary action page 3. |
| L1 + L2 | Ability layer 4 | Maps to ordinary action page 4. |
| M1 / L3 fallback | Target nearest enemy | Repeating it cycles using the original Vanilla target command. |
| R2 | Right-click at the current pointer | Touch or point at an NPC, object, or corpse first. Vanilla has no Interact-with-target action. |
| M2 / R3 fallback | Jump | Winlator binds directly to stock `JUMP`; it is not an addon command. |
| Start | Open/close Quick Menu | Simple press toggle; no hidden tap/hold timing. |
| Select | Open/close Controller Inventory | Right A uses/equips; Left Y picks up/places; touch selects safely. |
| Touchscreen | Precise pointer and text tasks | Login, character creation, NPC/object selection, drag, scroll, IME, money/text fields, ground-target spells, and unsupported controls. |

### Why this works

- The four face buttons are the most reachable combat inputs and remain abilities in the world.
- The D-pad provides less-frequent abilities 9–12 without shrinking icons; the same D-pad becomes navigation when a menu is visible.
- R1 adds the second face-button bank for abilities 5–8. It does not create a hidden menu mode.
- L1/L2 layer the entire ability set, matching Vanilla’s page model while retaining muscle memory.
- M1 is the high-frequency targeting action; L3 is the no-paddle fallback.
- M2 is the primary Jump action; R3 is the no-paddle fallback.
- R2 is reserved for pointer right-click, the only honest way to cover NPCs, objects, and corpses without a modern interact API.
- Start and Select use platform conventions for menu and inventory.

### Physical calibration requirements

The comfort decision is incomplete until the launcher calibrates physical face positions, detects Nintendo/Xbox letter swaps, visualizes both stick axes, and applies trigger hysteresis. Starting hypotheses are 12–18% left-stick dead zone, 10–16% right-stick dead zone, L2 at 30% on/20% off, and R2 at 40% on/25% off. These values must be replaced by the smallest stable per-unit settings observed on hardware. M1/M2 must be tested with a normal grip and offered as Default, Swapped, or Off.

### What is intentionally not on the default map

Target self, previous target, friend/group cycles, raid markers, direct pet/form positions, explicit action page controls, screenshot, nameplates, auto-run, and other stock helpers remain Advanced. Auto-run can be an optional launcher binding for long travel, but it is not a novice default because it creates an invisible movement state and increases stuck-input risk.

## Spatial “feng shui” review

The screen has three stable zones:

1. **Awareness zone — top center.** Target identity and health only. It does not compete with quest text or the stock player frame.
2. **World zone — center.** No permanent menu cluster, tutorial strip, or giant controller overlay. Touch selection and camera motion remain visually unobstructed.
3. **Action zone — bottom center.** Two rows of four large icons. The shape is easy to scan and maps to face and R1+face groups.

Custom modal surfaces use the center only while explicitly open. They are mutually exclusive. The focus ring is thick, high contrast, and geometry-based. Prompts are short and disappear. This provides a calm visual rhythm rather than showing every possible command at once.

## Quick Menu information architecture

**Everyday page**

| Character | Quest Log | Spellbook |
|---|---|---|
| Social | Inventory | World Map |
| Pet & Forms | Chat | Game Menu |

**Occasional/learning page**

| Skills | Talents | Reputation |
|---|---|---|
| Pet Book | Controls & Help | Extra Bars |
| Friends | Guild | Keyring |

The first page answers the common out-of-combat questions: “what am I wearing?”, “what is my quest?”, “where is my spell?”, “who is online?”, “where am I?”, “what is in my bag?”, and “how do I chat?” The second page holds progression and infrequent systems.

## Panel safety review

| Workflow | Controller behavior | Touch role |
|---|---|---|
| Quest completion | Right A twice within 4 seconds | Select reward precisely when needed. |
| Merchant buy/buyback/repair | Right A twice within 4 seconds | Item inspection, stack counts, and unusual purchases. |
| Trainer purchase | Right A twice within 4 seconds | Review cost/details before confirming. |
| Craft/Create All | Right A twice within 4 seconds | Set quantity and inspect reagents. |
| Player trade accept | Right A twice within 4 seconds | Touch adds items and money; controller only commits/cancels. |
| Send mail | Right A twice within 4 seconds | Touch/IME enters recipient, subject, body, money, and package. |
| Auction bid/buyout/create | Right A twice within 4 seconds | Touch handles search fields, prices, stacks, and canceling auctions. |
| Taxi flight | Right A twice within 4 seconds | Touch remains available for map precision. |
| Static popup | One right-A press on Blizzard popup | The popup itself is the second explicit confirmation. |

The following remain touch-first because controller activation would be ambiguous or irreversible: bank item movement, equipment dragging, player-trade item/money entry, mail recipient/body/money/package, spell dragging, talent spending, quest abandonment, mail deletion, auction cancellation, reagent manipulation, and bank slot purchase.

## Beginner language review

Player-facing text uses control labels and outcomes, not implementation terms. “Ability layer,” “Inventory,” “Controls & Help,” “Confirm,” and “right-click at the pointer” are used. “Secure state,” “bonus offset,” “FrameXML,” “slot 61,” and raw coordinates are confined to technical documentation or debug output.

## Remaining evidence gaps

Host tests cannot prove physical readability, actual FrameXML names in every locale, Wine key-up behavior, Android IME composition, controller reconnect, touch coordinate accuracy, or whether a first-time player completes the flow without coaching. Before stable release, run moderated novice tests on at least one 720p handheld and one native-1080p 5.5-inch handheld, record task completion/time/errors, and revise labels or mapping only from observed evidence.
