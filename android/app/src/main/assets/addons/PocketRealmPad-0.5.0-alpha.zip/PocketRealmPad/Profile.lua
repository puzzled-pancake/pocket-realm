-- Product-owned defaults for the managed WoW 1.12.1 Android client copy.
-- The launcher may preseed display and controller-label settings while WoW is
-- stopped. The addon never changes Blizzard's global UI scale or resolution.

PRP_PROFILE_ID = "retroid-pocket-6-stick-top-v5"

PRP_ESSENTIAL_BINDINGS = {
    "PRP_ACTION1", "PRP_ACTION2", "PRP_ACTION3", "PRP_ACTION4",
    "PRP_MOD_SHIFT", "PRP_MOD_CTRL", "PRP_MOD_BANK",
    "PRP_NAV_UP", "PRP_NAV_DOWN", "PRP_NAV_LEFT", "PRP_NAV_RIGHT",
    "PRP_QUICK_MENU", "PRP_INVENTORY", "PRP_TARGET_NEXT_ENEMY",
}

PRP_DEFAULTS = {
    schema = 5,
    enabled = 1,
    safeMode = 0,
    debug = 0,
    scale = 1.00,
    textScale = 1.00,
    mappingProfile = PRP_PROFILE_ID,

    onboarding = {
        completed = 0,
        showOnLogin = 1,
    },

    display = {
        profile = "AUTO",
        deviceHint = "RETROID_POCKET_6",
        lastResolved = "HANDHELD_720",
        autoRefreshSeconds = 0.75,
    },

    -- Labels describe the printed RP6 controls in the stick-on-top model.
    -- The launcher maps physical positions rather than assuming Xbox letters:
    -- right A = primary/confirm, bottom B = back, left Y = more, top X = fourth.
    controls = {
        confirm = "A",
        back = "B",
        alternate = "Y",
        panelMenu = "X",
        menu = "START",
        inventory = "SELECT",
        bank = "R1",
        layer1 = "L1",
        layer2 = "L2",
        target = "M1",
        targetFallback = "L3",
        interact = "R2",
        jump = "M2",
        jumpFallback = "R3",
        self = "UNBOUND",
        face = { "A", "B", "Y", "X" },
        facePosition = { "RIGHT", "BOTTOM", "LEFT", "TOP" },
        dpad = { "D-UP", "D-DOWN", "D-LEFT", "D-RIGHT" },
    },

    action = {
        visibleButtons = 8,
        columns = 4,
        pageSet = "A",
        usePhysicalModifiers = 1,
        shiftHeld = 0,
        controlHeld = 0,
        altHeld = 0,
        bankHeld = 0,
        -- Stick-top RP6: common actions 1-8 stay on the right hand.
        -- The lower-left D-pad carries less-frequent actions 9-12 in the world.
        dpadWorldMode = "ACTIONS",
        showSlotNumbers = 0,
    },

    bar = {
        shown = 1,
        locked = 1,
        point = "BOTTOM",
        relativePoint = "BOTTOM",
        x = 0,
        y = 76,
        alpha = 0.96,
        buttonSize = 54,
        spacing = 5,
    },

    target = {
        shown = 1,
        point = "TOP",
        relativePoint = "TOP",
        x = 0,
        y = -42,
    },

    ui = {
        showModeBadge = 0,
        edgePadding = 12,
    },

    focus = {
        enabled = 1,
        scanInterval = 0.12,
        wrap = 1,
        scrollStep = 48,
        ringThickness = 4,
        ringPad = 5,
        confirmSeconds = 4.0,
    },

    inventory = {
        columns = 4,
        rows = 3,
        cellSize = 54,
        spacing = 6,
        sellConfirmSeconds = 5.0,
        showDetails = 1,
    },

    quickMenu = {
        columns = 3,
        rows = 3,
        buttonSize = 60,
        spacing = 8,
    },

    companion = {
        columns = 5,
        rows = 4,
        buttonSize = 52,
        spacing = 5,
    },
}
