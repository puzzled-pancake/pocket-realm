-- Two-page, 3x3 digital quick menu. It avoids analog-stick APIs and keeps
-- every operation within the stock 1.12 interface/helper set.

PRP_QuickMenu = {
    initialized = false,
    buttons = {},
    pages = {},
    page = 1,
    selected = 5,
}

PRP_QuickMenu.pages = {
    {
        -- The center cell is Inventory: the most common out-of-combat task.
        { label = "Character", icon = "Interface\\Icons\\INV_Shirt_05", kind = "HELPER", action = "CHARACTER" },
        { label = "Quest Log", icon = "Interface\\Icons\\INV_Misc_Note_02", kind = "HELPER", action = "QUESTS" },
        { label = "Spellbook", icon = "Interface\\Icons\\INV_Misc_Book_09", kind = "HELPER", action = "SPELLBOOK" },
        { label = "Social", icon = "Interface\\Icons\\INV_Letter_15", kind = "HELPER", action = "SOCIAL" },
        { label = "Inventory", icon = "Interface\\Icons\\INV_Misc_Bag_08", kind = "INVENTORY" },
        { label = "World Map", icon = "Interface\\Icons\\INV_Misc_Map_01", kind = "HELPER", action = "MAP" },
        { label = "Pet & Forms", icon = "Interface\\Icons\\Ability_Hunter_BeastCall", kind = "COMPANION" },
        { label = "Chat", icon = "Interface\\Icons\\INV_Letter_18", kind = "CHAT" },
        { label = "Game Menu", icon = "Interface\\Icons\\INV_Misc_Gear_01", kind = "HELPER", action = "GAMEMENU" },
    },
    {
        -- Page two centers the help guide rather than an advanced toggle.
        { label = "Skills", icon = "Interface\\Icons\\INV_Misc_Book_10", kind = "CHARACTER", action = "SkillFrame" },
        { label = "Talents", icon = "Interface\\Icons\\Spell_Nature_EnchantArmor", kind = "HELPER", action = "TALENTS" },
        { label = "Reputation", icon = "Interface\\Icons\\INV_BannerPVP_02", kind = "CHARACTER", action = "ReputationFrame" },
        { label = "Pet Book", icon = "Interface\\Icons\\Ability_Hunter_BeastTaming", kind = "HELPER", action = "PETBOOK" },
        { label = "Controls & Help", icon = "Interface\\Icons\\INV_Misc_Book_11", kind = "GUIDE" },
        { label = "Extra Bars", icon = "Interface\\Icons\\INV_Misc_Gear_02", kind = "PAGE_SET" },
        { label = "Friends", icon = "Interface\\Icons\\INV_Misc_GroupLooking", kind = "HELPER", action = "FRIENDS" },
        { label = "Guild", icon = "Interface\\Icons\\INV_Shirt_GuildTabard_01", kind = "HELPER", action = "GUILD" },
        { label = "Keyring", icon = "Interface\\Icons\\INV_Misc_Key_03", kind = "HELPER", action = "KEYRING" },
    },
}

function PRP_QuickMenu:CreateButton(index)
    local button = CreateFrame("Button", "PocketRealmPadQuickMenuButton" .. index, self.frame)
    local icon
    local label
    local number
    button.prpIndex = index
    button:RegisterForClicks("LeftButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 4, -4)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -4, 15)
    button.icon = icon
    label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("BOTTOM", button, "BOTTOM", 0, 4)
    label:SetJustifyH("CENTER")
    button.label = label
    number = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    number:SetPoint("TOPLEFT", button, "TOPLEFT", 4, -4)
    number:SetText("")
    button.number = number
    button:SetScript("OnEnter", PRP_QuickMenuButton_OnEnter)
    button:SetScript("OnClick", PRP_QuickMenuButton_OnClick)
    self.buttons[index] = button
end

function PRP_QuickMenu:Initialize()
    local index
    if self.initialized then return end
    self.frame = PRP_UI:CreatePanel("PocketRealmPadQuickMenu", 270, 270, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:Hide()
    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Quick menu")
    self.title:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -12)
    self.pageText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "Page 1 / 2")
    self.pageText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -14, -17)
    self.hint = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "")
    self.hint:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 14, 12)
    for index = 1, 9 do self:CreateButton(index) end
    self.initialized = true
    self:ApplyMetrics()
    self:UpdateButtons()
end

function PRP_QuickMenu:ApplyMetrics()
    local metrics
    local size
    local spacing
    local width
    local height
    local index
    local column
    local row
    local button
    local fontScale
    if not self.initialized or not PRP_Handheld then return end
    metrics = PRP_Handheld:GetMetrics()
    fontScale = PRP_Handheld:GetFontScale()
    size = metrics.quickButton
    spacing = metrics.quickSpacing
    width = 28 + (3 * size) + (2 * spacing)
    height = 82 + (3 * size) + (2 * spacing)
    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.hint:SetWidth(width - 28)
    for index = 1, 9 do
        button = self.buttons[index]
        column = math.mod(index - 1, 3)
        row = math.floor((index - 1) / 3)
        button:SetWidth(size)
        button:SetHeight(size)
        PRP_SetFontScale(button.label, fontScale, 10)
        PRP_SetFontScale(button.number, fontScale, 10)
        button.label:SetWidth(size - 8)
        button:ClearAllPoints()
        button:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14 + (column * (size + spacing)), -45 - (row * (size + spacing)))
    end
    PRP_SetFontScale(self.title, fontScale, 14)
    PRP_SetFontScale(self.pageText, fontScale, 10)
    PRP_SetFontScale(self.hint, fontScale, 10)
    self.hint:SetText(PRP_ControlHint("Open", "confirm") .. "   " .. PRP_ControlHint("Close", "back") .. "   " .. PRP_ControlHint("Next page", "alternate"))
    self:UpdateButtons()
end

function PRP_QuickMenu:IsShown()
    return self.initialized and PRP_IsVisible(self.frame)
end

function PRP_QuickMenu:GetEntry(index)
    local page = self.pages[self.page]
    return page and page[index] or nil
end

function PRP_QuickMenu:UpdateButtons()
    local index
    local button
    local entry
    if not self.initialized then return end
    for index = 1, 9 do
        button = self.buttons[index]
        entry = self:GetEntry(index)
        button.prpEntry = entry
        if entry then
            button.icon:SetTexture(entry.icon)
            button.label:SetText(entry.label)
            button:SetAlpha(1)
        else
            button.icon:SetTexture(nil)
            button.label:SetText("")
            button:SetAlpha(0.30)
        end
    end
    self.pageText:SetText("Page " .. tostring(self.page) .. " / " .. tostring(PRP_TableLength(self.pages)))
    self:UpdateVisual()
end

function PRP_QuickMenu:UpdateVisual()
    local entry = self:GetEntry(self.selected)
    local button = self.buttons[self.selected]
    if self:IsShown() and entry and button then
        PRP:SetMode("QUICK MENU")
        PRP_UI:SetFocus(button, entry.label, false)
    end
end

function PRP_QuickMenu:Show()
    if PocketRealmPadDB.safeMode == 1 then return false end
    if PRP_Inventory then PRP_Inventory:Hide() end
    if PRP_Companion then PRP_Companion:Hide() end
    if PRP_Guide then PRP_Guide:Hide(false) end
    self.frame:Show()
    self:UpdateButtons()
    PRP:SetMode("QUICK MENU")
    return true
end

function PRP_QuickMenu:Hide()
    if not self.initialized then return end
    self.frame:Hide()
    PRP_UI:ClearFocus()
    PRP_UI:SetPrompt("")
    if PRP_Focus then PRP_Focus:Detect(true) else PRP:SetMode("WORLD") end
end

function PRP_QuickMenu:Toggle()
    if self:IsShown() then self:Hide() else self:Show() end
end

function PRP_QuickMenu:SetPage(page)
    local count = PRP_TableLength(self.pages)
    while page < 1 do page = page + count end
    while page > count do page = page - count end
    self.page = page
    self.selected = 5
    self:UpdateButtons()
    if PlaySound then PlaySound("igMainMenuOptionCheckBoxOn") end
end

function PRP_QuickMenu:Navigate(direction)
    local row = math.floor((self.selected - 1) / 3)
    local column = math.mod(self.selected - 1, 3)
    if direction == "UP" then row = row - 1
    elseif direction == "DOWN" then row = row + 1
    elseif direction == "LEFT" then column = column - 1
    elseif direction == "RIGHT" then column = column + 1
    else return false end
    if row < 0 then row = 2 end
    if row > 2 then row = 0 end
    if column < 0 then column = 2 end
    if column > 2 then column = 0 end
    self.selected = (row * 3) + column + 1
    self:UpdateVisual()
    if PlaySound then PlaySound("igMainMenuOptionCheckBoxOn") end
    return true
end

function PRP_QuickMenu:RunEntry(entry)
    if not entry then return false end
    if entry.kind == "HELPER" then
        return PRP_VanillaActions:Helper(entry.action)
    elseif entry.kind == "CHARACTER" then
        if ToggleCharacter then ToggleCharacter(entry.action) return true end
    elseif entry.kind == "INVENTORY" then
        self:Hide()
        return PRP_Inventory:Show()
    elseif entry.kind == "COMPANION" then
        self:Hide()
        PRP_Companion:Show()
        return true
    elseif entry.kind == "CHAT" then
        self:Hide()
        return PRP_Router:OpenChat(false)
    elseif entry.kind == "GUIDE" then
        self:Hide()
        return PRP_Guide:Show()
    elseif entry.kind == "PAGE_SET" then
        PRP_ActionBar:TogglePageSet()
        return true
    end
    return false
end

function PRP_QuickMenu:Activate()
    local entry = self:GetEntry(self.selected)
    local ok = self:RunEntry(entry)
    if entry and entry.kind ~= "INVENTORY" and entry.kind ~= "COMPANION" and entry.kind ~= "CHAT" and entry.kind ~= "GUIDE" then
        self:Hide()
    end
    return ok
end

function PRP_QuickMenu:Accept()
    return self:Activate()
end

function PRP_QuickMenu:Alternate()
    self:SetPage(self.page + 1)
    return true
end

function PRP_QuickMenu:Back()
    self:Hide()
    return true
end

function PRP_QuickMenu:OnKey(state)
    -- A single press opens or closes the menu. Selection and activation are
    -- separate actions, which is easier to learn and avoids hold timing.
    if state == "down" then
        self:Toggle()
    end
end

function PRP_QuickMenu:OnUpdate(elapsed)
end

function PRP_QuickMenuButton_OnEnter()
    if not this then return end
    PRP_QuickMenu.selected = this.prpIndex
    PRP_QuickMenu:UpdateVisual()
end

function PRP_QuickMenuButton_OnClick()
    if not this then return end
    PRP_QuickMenu.selected = this.prpIndex
    PRP_QuickMenu:Activate()
end
