# Pocket Realm Pad 0.5.0-alpha

Pocket Realm Pad is an **Android-only controller and touchscreen interface addon** for the original World of Warcraft 1.12.1 client, build 5875. It is designed for a player who may never have played World of Warcraft before. It is not a PC controller addon and it does not read a physical gamepad from Lua.

The Android/Winlator layer owns the controller, sticks, mouse, touch coordinate transform, IME, focus loss, reconnects, and release-all behavior. Pocket Realm Pad receives ordinary keyboard binding events and adds understandable gameplay meaning, large handheld UI, menu focus, inventory browsing, targeting feedback, and beginner help.

The default hardware target is the **Retroid Pocket 6 Stick Top model**. The evidence, ergonomic reasoning, alternative rear-button mode, and novice test plan are documented in `RP6_STICK_TOP_CONTROL_STUDY.md`.

## Start here: the first ten minutes

1. The Android launcher installs this addon into the **managed copy** of the client and applies the verified controller profile.
2. Use touch for the login screen and character creation.
3. Enter the world. A five-page **Controls & Help** guide opens when no chat box, popup, or menu is in the way.
4. Move with the left stick, look with the right stick, and jump with M2 (R3 backup).
5. Touch an NPC with a yellow `!`, leaving the pointer over the NPC, then press R2. R2 sends a right-click **at the current pointer**; Vanilla has no automatic Interact-with-target action.
6. In supported windows, move the bright focus ring with the D-pad. Right A confirms, Bottom B backs out, and Left Y is More.
7. Target an enemy with M1 (L3 backup) and use the four face buttons plus R1 for the first eight abilities.
8. Touch a defeated corpse and press R2 to loot.
9. Press Select to inspect bags. Right A uses/equips the selected item; Left Y picks up or places it. Normal touchscreen taps select rather than unexpectedly use an item.
10. Finish through the Android launcher’s **Save & Exit** action. The Game Menu’s desktop Quit/Logout buttons are deliberately not controller-focused.

## Recommended controls

| Control | World meaning | Menu/touch meaning |
|---|---|---|
| Left stick | Move forward/back and strafe | Winlator sends stock movement key down/up events. |
| Right stick | Camera look | Winlator sends relative mouse movement while camera-look is active. |
| Right A / Bottom B / Left Y / Top X | Abilities 1 / 2 / 3 / 4 | In supported panels: Confirm / Back / More / Quick Menu. |
| D-pad | Abilities 9 / 10 / 11 / 12 | In menus and addon grids: move selection. |
| R1 + A/B/Y/X | Abilities 5 / 6 / 7 / 8 | R1 is a compact ability bank, not a general menu modifier. |
| L1 | Ability layer 2 | Maps to ordinary action page 2; page 6 in Extra Bars mode. |
| L2 | Ability layer 3 | Maps to ordinary action page 3. |
| L1 + L2 | Ability layer 4 | Maps to ordinary action page 4. |
| M1 / L3 fallback | Target nearest enemy | Repeating it cycles using the original Vanilla target command. |
| R2 | Right-click at the current pointer | Touch or point at an NPC, object, or corpse first. Vanilla has no Interact-with-target action. |
| M2 / R3 fallback | Jump | Winlator binds directly to stock `JUMP`; it is not an addon command. |
| Start | Open/close Quick Menu | Simple press toggle; no hidden tap/hold timing. |
| Select | Open/close Controller Inventory | Right A uses/equips; Left Y picks up/places; touch selects safely. |
| Touchscreen | Precise pointer and text tasks | Login, character creation, NPC/object selection, drag, scroll, IME, money/text fields, ground-target spells, and unsupported controls. |

Controller labels are profile data. The launcher calibrates physical positions rather than raw Android letters. It also offers **M1 target/M2 jump**, **Swap M1/M2**, and **Rear buttons off**, while preserving L3/R3 fallbacks. Analogue L2/R2 require measured digital thresholds and hysteresis so sensor noise cannot create repeated layer or pointer clicks.

## What the screen is trying to communicate

The layout follows a simple visual hierarchy:

- **Top:** one compact target card. It answers “what am I targeting?” and “how much health is left?”
- **Center:** the world stays unobstructed for movement, combat, quest text, and touch selection.
- **Bottom:** a two-row, eight-button ability bar with physical control labels.
- **Center modal, only when requested:** Quick Menu, Inventory, Pet & Forms, or Controls & Help. Only one custom modal surface is shown at a time.
- **Bright focus ring:** the currently selected known Blizzard control. No ring means “use touch.”
- **Prompts:** short, temporary, and action-oriented. Raw coordinates and action-slot numbers are hidden unless debug mode is enabled.

Eight visible abilities are intentional on a 5.5-inch screen. Abilities 5–8 remain one shoulder chord away; abilities 9–12 use the lower D-pad, while deeper pages remain available without putting 12 tiny icons on the normal handheld layout.

## Action bar: stock WoW data, handheld presentation

Pocket Realm Pad does not invent a spell database. It mirrors the original action slots:

| Layer | Main set | Extra Bars set |
|---|---:|---:|
| No shoulder | Page 1 / active form or stance page | Page 5 |
| L1 | Page 2 | Page 6 |
| L2 | Page 3 | Page 3 |
| L1 + L2 | Page 4 | Page 4 |

The original client has 12 buttons across six ordinary pages: slots 1–72. The exact slot, bonus-page state, self-cast state, bank state, and semantic context are captured on key-down and completed from that capture on key-up. Releasing a shoulder first cannot change the pending action.

To place a learned spell, open the normal Spellbook and use touch to drag it onto the normal Blizzard action bar. Pocket Realm Pad immediately mirrors that slot. This familiar drag path is safer than attempting to emulate modern click-to-bind behavior in a 2006 client.

## Quick Menu

Start opens a simple two-page 3×3 grid. There is no hidden hold threshold or radial-stick gesture.

**Page 1 — everyday play**

| Character | Quest Log | Spellbook |
|---|---|---|
| Social | Inventory | World Map |
| Pet & Forms | Chat | Game Menu |

**Page 2 — occasional and learning tools**

| Skills | Talents | Reputation |
|---|---|---|
| Pet Book | Controls & Help | Extra Bars |
| Friends | Guild | Keyring |

The center is always the safest high-frequency choice: Inventory on page 1 and Controls & Help on page 2.

## Menu safety

The router priority is:

```text
CHAT > MODAL POPUP > CONTROLS & HELP > QUICK MENU > INVENTORY
     > PET & FORMS > SUPPORTED BLIZZARD WINDOW > WORLD
```

Context is captured on key-down. A quest window closing after right A confirms cannot make the later key-up cast an ability. Chat suppresses semantic shortcuts. A forced panel refresh clears any armed purchase or destructive confirmation.

| Workflow | Controller behavior | Touch role |
|---|---|---|
| Quest completion | Right A twice within 4 seconds | Select reward precisely when needed. |
| Merchant buy/buyback/repair | Right A twice within 4 seconds | Item inspection, stack counts, and unusual purchases. |
| Trainer purchase | Right A twice within 4 seconds | Review cost/details before confirming. |
| Craft/Create All | Right A twice within 4 seconds | Set quantity and inspect reagents. |
| Player trade accept | Right A twice within 4 seconds | Touch adds items and money; controller only commits/cancels. |
| Send mail | Right A twice within 4 seconds | Touch/IME enters recipient, subject, body, money, and package. |
| Auction bid/buyout/create | Right A twice within 4 seconds | Touch handles search fields, prices, stacks, and canceling auctions. |
| Taxi flight | Right A twice within 4 seconds | Touch remains available for map precision. |
| Static popup | One right-A press on Blizzard popup | The popup itself is the second explicit confirmation. |

Bank item movement, trade offers, mail contents, spell dragging, talent spending, quest abandonment, mail deletion, auction cancellation, money/text fields, and other ambiguous operations are touch tasks. This is deliberate: touch is better than making a permanent or costly action easy to trigger accidentally.

## Supported Vanilla windows

Pocket Realm Pad has explicit bounded adapters for 23 original window families plus dynamic StaticPopup1–4 handling: Quest, Gossip, Loot, Merchant, Game Menu, Spellbook, Character, Quest Log, Social/Friends/Who, World Map, Bank, Trainer, Craft, Trade Skill, Player Trade, Mail Inbox, Send Mail, Open Mail, Auction Browse, Auction Bids, Owned Auctions, Taxi, and Talents.

It does not recursively scan arbitrary addon frames. Missing controls are skipped. When no bright ring appears, use touch.

## Android display profiles

The layout is resolved from the client’s logical UI desktop (`UIParent`) and records render resolution separately. The launcher owns virtual desktop resolution, `useUiScale/uiScale`, letterboxing, Android surface scaling, and the touch-coordinate matrix.

| Profile | Resolver class | Actions | Action UI units | Inventory | Focus line | Purpose |
|---|---|---|---|---|---|---|
| COMPACT_540 | ≤560 short side | 8 | 42 | 4×3 / 44 | 3 | Thermal/compatibility fallback |
| LEGACY_600 | ≤640 | 8 | 46 | 4×3 / 48 | 3 | 800×600 current safe-client proof |
| HANDHELD_720 | ≤760 | 8 | 54 | 4×3 / 54 | 4 | Balanced handheld default |
| HANDHELD_800 | ≤860 | 8 | 60 | 4×3 / 60 | 4 | 16:10 handheld |
| HANDHELD_900 | ≤1010 | 8 | 68 | 4×3 / 68 + detail | 4 | Higher-density handheld |
| RP6_1080 | handheld hint, ~1080 short side | 8 | 82 | 4×3 / 82 + detail | 6 | Native 1080p 5.5-inch handheld |
| HANDHELD_1200 | handheld hint, 1151–1320 | 8 | 90 | 4×3 / 90 + detail | 7 | 16:10 high-density handheld |
| HANDHELD_1440 | handheld hint, ≥1321 | 8 | 108 | 4×3 / 108 + detail | 8 | QHD handheld |
| TABLET | explicit hint or non-handheld aspect | 12 | 58 | 5×4 / 58 + detail | 4 | Android tablet |
| ANDROID_LARGE | explicit TV/large hint | 12 | 54 | 5×4 / 54 + detail | 4 | Android TV/external display |

For a Retroid Pocket 6, the beginner-balanced path is a 1280×720 WoW virtual desktop using `HANDHELD_720`. Native 1920×1080 uses `RP6_1080`. Both target about the same physical control size after surface scaling; native resolution is a quality option, not a beginner requirement.

## Beginner help and recovery

The five-page in-game guide covers movement/targeting, touch/right-click interaction, ability layers, menus/bags, and a complete first quest loop. It delays itself rather than interrupting chat, a confirmation popup, or a menu the player opened.

Useful commands:

```text
/prp guide       reopen Controls & Help
/prp status      show display profile and essential binding status
/prp safe on     hide custom controller surfaces for diagnosis
/prp safe off    restore them
/prp reset       restore Android-handheld defaults
```

The launcher should check all 14 essential addon bindings before play and show a human-readable repair action when one is missing. R2 is a direct mouse mapping; M2/R3 are direct stock-WoW Jump mappings and are not counted in those 14.

## Deliberate non-features

This package does not claim retail systems that do not exist in Vanilla: native gamepad APIs, soft targeting, Interact-with-target, vehicles, extra-action buttons, collections, transmog, group finder, pet battles, secure state drivers, modern combat-lockdown remapping, modern GUID/nameplate enumeration, or analog-stick APIs in Lua.

## Engineering status

| Measure | v0.5 value |
|---|---:|
| Lua modules | 17 |
| Project bindings | 99 |
| Essential project bindings | 14 |
| Advanced project bindings | 85 |
| Project bindings requiring key-down/key-up | 31 |
| Stock Vanilla bindings audited | 228 |
| Ordinary action slots | 72 |
| Pet-action positions | 10 |
| Stance/form positions | 10 |
| Explicit panel adapters | 23 + dynamic StaticPopup1–4 |
| Android display profiles | 10 |
| Host runtime-mock assertions | 276 |

Host static checks and a mocked Vanilla runtime pass. This remains an engineering alpha until it is loaded in the actual build-5875 client and qualified on physical Android hardware, including controller reconnect, focus loss, IME, every supported class/form, panel workflows, 720p/1080p readability, and the project’s UX-T01–UX-T08 acceptance tasks.
