# Research source register — Pocket Realm Pad 0.5

## Interpretation policy

Official specifications establish hardware facts. Original WoW 1.12.1 FrameXML establishes client behavior. Reviews and community polls identify ergonomic preferences and test risks, but do not prove comfort for every hand size. Actual build-5875, RP6 Stick Top, Winlator, and novice-user results override every estimate.

## Vanilla 1.12 sources

- Blizzard WoW 1.12.1 FrameXML mirror: https://github.com/MOUZU/Blizzard-WoW-Interface/tree/master/1.12.1/FrameXML
- Original `Bindings.xml`: 228 stock bindings and fixed operations.
- Original `ActionButton.lua`: six ordinary pages, 12 buttons, bonus-page resolution, and self-cast behavior.
- Original container, pet, shapeshift, quest, merchant, mail, auction, trade, taxi, talent, social, and Game Menu FrameXML: exact bounded adapter names and behaviors.

## Controller behavior reference

- ConsolePort upstream: https://github.com/seblindfors/ConsolePort
- Used for behavioral decomposition only: action presentation, menu focus, targeting feedback, controller labels, and radial/menu organization.
- Not copied as source: current ConsolePort relies on later-client/native gamepad architecture unavailable to Interface 11200.

## Retroid Pocket 6 official sources

- Product page: https://www.goretroid.com/products/retroid-pocket-6-handheld
  - 5.5-inch 1920×1080 120 Hz AMOLED, Snapdragon 8 Gen 2, Adreno 740, Hall sticks, analogue L2/R2, 6000 mAh, active cooling.
- Delivery dashboard: https://www.goretroid.com/pages/delivery-dashboard
  - Separately identifies Stick Top and D-pad Top RP6 SKUs.
- Android Authority redesign report: https://www.androidauthority.com/retroid-pocket-6-relaunch-3611718/
  - Confirms M1/M2 were relocated to the rear in the community-driven redesign.
- Notebookcheck redesign report: https://www.notebookcheck.net/Retroid-Pocket-6-gaming-handheld-returns-in-two-new-designs-following-launch-day-debacle.1151314.0.html
  - Describes the rear controls as forefinger-accessible.
- Secondary manual mirror: https://manuals.plus/retroid/pocket-6-premium-android-handheld-gaming-console-manual
  - Describes A as Confirm, B as Cancel, analogue L2/R2, and programmable M1/M2. Treat as secondary evidence; physical firmware calibration remains authoritative.

## RP6 community and review evidence

- Community layout poll report: https://retrohandhelds.gg/retroid-crowdsources-pocket-6-design-after-community-pushback/
  - Reported 61% support for moving the left stick to the top across more than 4,800 votes.
- Discord/layout redesign report: https://retrohandhelds.gg/retroid-pocket-6-gets-redesigned-because-we-cant-have-nice-things/
  - Reported 63% Discord preference for left stick on top and Retroid’s decision to offer both layouts.
- Android Central redesign poll report: https://www.androidcentral.com/gaming/android-games/retroid-just-announced-the-pocket-6-but-the-community-wanted-something-different-and-thats-exactly-what-it-got
  - Reported almost 10,000 X votes and nearly 70% support for the broader redesign.
- Stuff hands-on review: https://www.stuff.tv/review/retroid-pocket-6-review/
  - Larger/comfier shell; shoulder buttons wrap around sides; larger triggers; quiet face buttons; reports that some users experience stick-thumb contact or dislike rear paddles.
- Junub Games review: https://junubgames.com/retroid-pocket-6-review/
  - Larger quiet face buttons; occasional right-stick/face-thumb contact; slightly small D-pad; long analogue-trigger travel; stick-top recommended for modern 3D use.
- Held Games review: https://heldgames.com/reviews/retroid-pocket-6
  - Stick-top model described as more comfortable where analogue movement carries the load.
- Retroid community thread: https://www.reddit.com/r/retroid/comments/1t5kchv/first_time_poster_long_time_lurker/
  - One user reports lower-stick thumb cramping; a stick-top owner reports the lower D-pad remained comfortable for sub-hour 2D sessions. Anecdotal and used only as a test hypothesis.

Design response:

- left thumb stays on the upper movement stick for abilities 1–8;
- face buttons + R1 provide the eight common abilities;
- lower D-pad carries abilities 9–12 and menu navigation;
- M1/M2 are safe optional taps only, with Default/Swap/Off modes and L3/R3 fallbacks;
- no destructive, costly, held-modifier, or consumable action uses a rear paddle;
- physical-position calibration prevents Nintendo/Xbox Android letter swaps;
- analogue L2/R2 use measured on/off thresholds and hysteresis rather than raw non-zero input.

## Android input and accessibility sources

- Android controller input guidance: https://developer.android.com/develop/ui/views/touch-and-input/game-controllers/controller-input
  - Use physical key/axis discovery and account for controller-layout variants rather than assuming one label scheme.
- Android accessibility guidance: https://developer.android.com/guide/topics/ui/accessibility/apps
  - Large, separated, labeled controls; approximately 48×48 dp minimum touch-target principle. WoW UI units are not dp, so physical testing is required.
- WCAG focus appearance: https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance.html
  - Thick, high-contrast focus perimeter with visible separation.

## Project sources

- Engineering porting report: fixed build 5875; Android/Winlator owns keyboard/mouse synthesis; mobile controls are release gates; UX-T01–T08.
- Repository `PLAN.md`: a project addon may supply semantics/UI but is not the input driver; RP6 qualification belongs to later gates.
- Repository `PROGRESS.md`: broader product remains in O12/G3 integrated work; physical mobile UX qualification is not complete.
