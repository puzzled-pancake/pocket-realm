# Retroid Pocket 6 stick-top control study — Pocket Realm Pad 0.5

## Decision

Pocket Realm Pad 0.5 targets the **Retroid Pocket 6 Stick Top model**: the left analogue stick is above the D-pad. The layout is optimized for a 3D game in which movement and camera control are continuous, while ability presses, targeting, jumping, interaction, bags, and menus are discrete.

The design rule is simple:

> Keep the left thumb on the upper movement stick and the right thumb near the face buttons/right stick. Put frequent combat actions under the right thumb and index fingers. Put lower-frequency actions on the lower-left D-pad. Use rear buttons only for safe, reversible taps.

## Evidence reviewed

### Official device facts

Retroid's product page identifies a 5.5-inch 1920×1080 120 Hz AMOLED handheld with Hall sticks and analogue L2/R2 triggers. Retroid's delivery dashboard separately lists Stick Top and D-pad Top SKUs, confirming that the layout is a real purchase-time hardware choice. Reporting on Retroid's redesign also confirms that M1/M2 moved to the rear panel; another hardware report describes them as forefinger-accessible. Secondary manual mirrors describe A as Confirm and B as Cancel, matching the printed Retroid/Nintendo convention used by this profile.

- https://www.goretroid.com/products/retroid-pocket-6-handheld
- https://www.goretroid.com/pages/delivery-dashboard
- https://www.androidauthority.com/retroid-pocket-6-relaunch-3611718/
- https://www.notebookcheck.net/Retroid-Pocket-6-gaming-handheld-returns-in-two-new-designs-following-launch-day-debacle.1151314.0.html
- https://manuals.plus/retroid/pocket-6-premium-android-handheld-gaming-console-manual

### Community preference and redesign feedback

Retroid asked the community about the layout after pushback over the original design. Reports of the polls recorded roughly 61–63% support for the left stick in the upper position, with more than 4,800 votes in one poll and a 63% Discord result in another. A separate redesign poll report recorded almost 10,000 X votes, with nearly 70% favoring the broader redesign. The strongest recurring reason was that the upper stick is more comfortable for modern 3D games where analogue movement is the dominant input.

- https://retrohandhelds.gg/retroid-crowdsources-pocket-6-design-after-community-pushback/
- https://retrohandhelds.gg/retroid-pocket-6-gets-redesigned-because-we-cant-have-nice-things/
- https://www.androidcentral.com/gaming/android-games/retroid-just-announced-the-pocket-6-but-the-community-wanted-something-different-and-thats-exactly-what-it-got

### Hands-on control feedback

Independent reviews consistently report:

- the larger, quieter face buttons are comfortable for repeated use;
- the shoulder buttons wrap around the sides and the larger triggers are easy to reach;
- the D-pad is accurate but somewhat small;
- the right stick is close enough to the face buttons that occasional thumb contact can occur;
- some players find the rear M1/M2 paddles useful, while others find them a nuisance or easy to bump;
- the stick-top model is generally preferred for 3D/modern games.

Sources:

- https://www.stuff.tv/review/retroid-pocket-6-review/
- https://junubgames.com/retroid-pocket-6-review/
- https://heldgames.com/reviews/retroid-pocket-6

Community reports are not laboratory measurements. They are used to select ergonomic hypotheses and failure tests, not to claim universal comfort.

A Retroid community thread also contains two useful, opposing anecdotes: one owner said the lower analogue position on the RP5 cramped their thumb and made the RP6 stick-top layout attractive; another stick-top RP6 owner said the lower D-pad remained comfortable for sub-hour Castlevania sessions. That supports using the upper stick for continuous 3D movement while keeping the lower D-pad available for discrete, lower-frequency inputs rather than removing it from gameplay.

- https://www.reddit.com/r/retroid/comments/1t5kchv/first_time_poster_long_time_lurker/

## Physical-control implications

| Physical observation | Design consequence |
|---|---|
| Upper-left stick is the continuous movement control | Do not require the left thumb to leave it for abilities 1–8. |
| Lower-left D-pad is less convenient during movement | Assign abilities 9–12 and menu navigation, not the most common combat abilities. |
| Face buttons are large, quiet, and under the right thumb | Put abilities 1–4 and menu Confirm/Back/More there. |
| R1 wraps around the side and is easy to chord | R1 + face buttons becomes abilities 5–8. |
| L1/L2 are easy to hold while the right hand presses abilities | Use them for action layers/pages. |
| R2 has long analogue travel | Use it for pointer right-click, an intentional interaction rather than a rapid combat rotation button. |
| Rear M1/M2 can be reached without removing thumbs, but may be bumped | Use only safe taps: nearest enemy and Jump. Never put purchases, consumables, destructive actions, or held modifiers there. |
| Right stick is near the face cluster | Avoid requiring simultaneous right-stick precision and rapid multi-button chords. Camera correction remains available between presses; targeting goes on M1. |
| D-pad is smaller than ideal | Avoid diagonal or gesture semantics. Use four distinct cardinal actions and deterministic menu navigation. |

## Trigger, stick, and rear-button calibration

The RP6 L2/R2 controls are analogue triggers, while WoW receives digital key or mouse transitions. The Android profile therefore needs explicit thresholds and hysteresis rather than treating any non-zero sensor noise as a press. Starting values below are calibration hypotheses, not shipping facts:

| Input | Initial on/off suggestion | Reason |
|---|---|---|
| L2 ability layer | 30% on / 20% off | A shallow deliberate pull makes page access quick while hysteresis prevents chatter. |
| R2 pointer right-click | 40% on / 25% off | Slightly deeper than L2 to reduce accidental NPC/object interaction. |
| Left stick movement | 12–18% radial dead zone, measured per unit | Prevent drift while preserving fine movement; choose the smallest value that passes the release test. |
| Right stick camera | 10–16% radial dead zone, separate sensitivity | Avoid camera creep without making small corrections difficult. |

The setup wizard must visualize live axis values, verify full return to neutral, and let the player retest. It should offer three rear-button modes: **M1 target / M2 jump** (default), **swapped**, and **off**. When swapped, the launcher must update the labels written to the addon's managed profile so the guide never lies about the printed control.

## Final RP6 Stick Top mapping

The names below refer to the **printed RP6 Nintendo-style labels and physical positions**. The Android launcher must map by physical position, not blindly by Android/Xbox letter conventions.

| RP6 control | World/combat | Supported menus | Reason |
|---|---|---|---|
| Left stick | Move/strafe | — | Continuous upper-left control; left thumb stays planted. |
| Right stick | Camera look | Pointer mode when selected | Continuous right-hand control. |
| Right **A** | Ability 1 | Confirm/choose | Matches the printed Retroid/Nintendo confirm convention and keeps Android and WoW menu semantics consistent. |
| Bottom **B** | Ability 2 | Back/cancel | Matches the printed Retroid/Nintendo cancel convention and remains easy to reach without a chord. |
| Left **Y** | Ability 3 | More/alternate | Secondary operation with low accidental cost. |
| Top **X** | Ability 4 | Quick Menu from a panel | Less frequent panel shortcut. |
| **R1 + A/B/Y/X** | Abilities 5–8 | Not a menu chord | Eight common abilities stay on the right hand. |
| D-pad U/D/L/R | Abilities 9–12 | Move focus | Lower-frequency world actions; no left-thumb travel for the core eight. |
| L1 | Ability layer 2 | — | Left index can hold while right hand acts. |
| L2 | Ability layer 3 | — | Same. |
| L1 + L2 | Ability layer 4 | — | Deliberate two-finger chord. |
| M1 | Target nearest enemy | — | Frequent, safe tap without leaving sticks. |
| M2 | Jump | — | Frequent, safe tap without leaving sticks. |
| L3 | Target fallback | — | Works when rear paddles are disabled or uncomfortable. |
| R3 | Jump fallback | — | Same. |
| R2 | Right-click at current pointer | Right-click pointer | Vanilla has no reliable Interact-with-target action. |
| Start | Quick Menu | Quick Menu | Familiar pause/menu location. |
| Select | Controller Inventory | Inventory | Frequent utility but not combat-critical. |
| Touchscreen | Precise target/object selection, ground spells | Login, character creation, drag, scroll, text, money, unknown panels | First-class part of the product, not an emergency fallback. |
| Home / Android Back | Reserved for Android/system | Reserved | Never make gameplay depend on a system button or OS chord. |

## Why the old v0.4 map changed

The earlier map put abilities 5–8 on the D-pad and 9–12 behind R1. That was reasonable for a generic gamepad, but wrong for the RP6 Stick Top geometry. During movement, the left thumb would have to leave the upper stick to reach four relatively common abilities. The v0.5 map swaps those banks:

- **R1 + face = abilities 5–8**
- **D-pad = abilities 9–12**

The visible bar remains actions 1–8 at all times. Holding R1 changes input meaning but does not reshuffle the icons, which avoids visual instability.

## Rear-button safety policy

M1/M2 are useful but controversial. Some reviewers report no issue; other users report accidental contact or dislike the paddles. Therefore:

1. M1/M2 are recommended primaries, but L3/R3 duplicates are always documented.
2. Rear buttons perform only immediate, reversible actions.
3. No rear button is a held layer, an item use, a purchase, a mail/trade commit, or a destructive operation.
4. The Android setup test asks the player to grip normally and reports accidental M1/M2 activation before accepting the profile.
5. The launcher offers `Default`, `Swap M1/M2`, and `Rear buttons off`; L3/R3 retain complete fallbacks.
6. The launcher synchronizes the selected printed labels into the addon's managed profile before WoW starts.

## Android key-label warning

Android controllers can expose Nintendo-positioned buttons with Xbox-style key names, and some firmware offers an A/B or X/Y swap. The launcher must calibrate **physical right/bottom/left/top positions** and then send the fixed Pocket Realm Pad semantic keys. In-game text shows the printed RP6 labels selected during setup.

Required calibration sequence:

1. Press the right face button.
2. Press the bottom face button.
3. Press the left face button.
4. Press the top face button.
5. Press M1 and M2, then choose Default, Swapped, or Off.
6. Pull L2 and R2 slowly so the setup can measure neutral, actuation, and release.
7. Hold R1 and press each face button.
8. Verify no duplicate raw key is assigned to two semantic commands.

## Comfort validation plan

A mapping is not accepted merely because every action is reachable. Test with at least 12 participants, including at least 6 who have never played WoW and at least 4 with smaller hands.

Record:

- mistaken-button rate per 100 presses;
- time to use abilities 1–8 while continuously moving;
- number of left-stick departures in a three-mob fight;
- accidental M1/M2 activations;
- right-thumb collisions with the right stick;
- ability-layer errors;
- menu Confirm/Back reversals;
- hand discomfort at 15, 30, 60, and 120 minutes;
- preference for rear buttons on/off;
- touch fallback frequency and success.

Acceptance targets for the beginner profile:

- zero required left-stick departures for abilities 1–8;
- less than 2% wrong-button presses after the guided tutorial;
- no destructive action from one accidental rear-button press;
- 100% of users can switch rear buttons off and continue with L3/R3;
- at least 10/12 users complete target → fight → loot → bag → equip → quest return without coaching after tutorial;
- no control requires Home, Android Back, volume, or power buttons.

## Known uncertainty

No source supplies controlled hand-size measurements, force/travel curves, or long-duration WoW-specific testing on the RP6. The mapping is evidence-informed, not physically qualified. Final claims require the actual Stick Top unit, current firmware, the selected Winlator input bridge, and moderated novice testing.
