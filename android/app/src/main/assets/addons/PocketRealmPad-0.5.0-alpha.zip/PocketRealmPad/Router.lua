-- Context-safe semantic input router. Winlator owns controller discovery,
-- sticks, camera/cursor mouse, Android focus, and release reliability.
-- Priority: chat > modal popup > guide > custom surfaces > Blizzard panels > world.

PRP_Router = {
    initialized = false,
    captured = {},
    navCaptured = {},
}

function PRP_Router:Initialize()
    self.initialized = true
end

function PRP_Router:GetContext()
    if PRP_ChatEditActive() then return "CHAT" end
    if PRP_Focus and PRP_Focus:HasModal() then
        PRP_Focus:Detect(true)
        return "MODAL"
    end
    if PRP_Guide and PRP_Guide:IsShown() then return "GUIDE" end
    if PRP_QuickMenu and PRP_QuickMenu:IsShown() then return "QUICK" end
    if PRP_Inventory and PRP_Inventory:IsShown() then return "INVENTORY" end
    if PRP_Companion and PRP_Companion:IsShown() then return "COMPANION" end
    if PRP_Focus and PRP_Focus:IsActive() then return "FOCUS" end
    return "WORLD"
end

function PRP_Router:IsUIContext(context)
    return context == "CHAT" or context == "MODAL" or context == "GUIDE"
        or context == "QUICK" or context == "INVENTORY"
        or context == "COMPANION" or context == "FOCUS"
end

function PRP_Router:ExecuteSemantic(context, index)
    if context == "MODAL" then
        if index == 1 then return PRP_Focus:Accept()
        elseif index == 2 then return PRP_Focus:Back()
        elseif index == 3 then return PRP_Focus:Alternate() end
        return true
    elseif context == "GUIDE" then
        if index == 1 then return PRP_Guide:Accept()
        elseif index == 2 then return PRP_Guide:Back()
        elseif index == 3 then return PRP_Guide:Alternate()
        elseif index == 4 then return PRP_Guide:Back() end
        return true
    elseif context == "QUICK" then
        if index == 1 then return PRP_QuickMenu:Accept()
        elseif index == 2 then return PRP_QuickMenu:Back()
        elseif index == 3 then return PRP_QuickMenu:Alternate()
        elseif index == 4 then PRP_QuickMenu:Hide() return true
        elseif index == 5 then PRP_QuickMenu:SetPage(PRP_QuickMenu.page - 1) return true
        elseif index == 6 then PRP_QuickMenu:SetPage(PRP_QuickMenu.page + 1) return true end
        return true
    elseif context == "INVENTORY" then
        if index == 1 then return PRP_Inventory:Accept()
        elseif index == 2 then return PRP_Inventory:Back()
        elseif index == 3 then return PRP_Inventory:Alternate()
        elseif index == 4 then PRP_QuickMenu:Show() return true
        elseif index == 5 then return PRP_Inventory:SetSelected(PRP_Inventory.selected - PRP_Inventory.pageSize)
        elseif index == 6 then return PRP_Inventory:SetSelected(PRP_Inventory.selected + PRP_Inventory.pageSize) end
        return true
    elseif context == "COMPANION" then
        if index == 1 then return PRP_Companion:Accept()
        elseif index == 2 then return PRP_Companion:Back()
        elseif index == 3 then return PRP_Companion:Alternate()
        elseif index == 4 then PRP_QuickMenu:Show() return true end
        return true
    elseif context == "FOCUS" then
        if index == 1 then return PRP_Focus:Accept()
        elseif index == 2 then return PRP_Focus:Back()
        elseif index == 3 then return PRP_Focus:Alternate()
        elseif index == 4 then PRP_QuickMenu:Show() return true end
        return true
    elseif context == "CHAT" then
        return true
    end
    return false
end

function PRP_Router:ActionKey(index, state)
    local context
    local captured
    if not self.initialized or not PRP:IsEnabled() then return end
    if state == "down" then
        context = self:GetContext()
        if self:IsUIContext(context) then
            self.captured[index] = context
            return
        end
        self.captured[index] = nil
        if PRP_ActionBar then PRP_ActionBar:OnKey(index, "down") end
        return
    end
    captured = self.captured[index]
    self.captured[index] = nil
    if captured then
        self:ExecuteSemantic(captured, index)
        return
    end
    if PRP_ActionBar then PRP_ActionBar:OnKey(index, "up") end
end

function PRP_Router:MoveUI(context, direction)
    if context == "MODAL" or context == "FOCUS" then
        if direction == "UP" then return PRP_Focus:Move(0, 1)
        elseif direction == "DOWN" then return PRP_Focus:Move(0, -1)
        elseif direction == "LEFT" then return PRP_Focus:Move(-1, 0)
        elseif direction == "RIGHT" then return PRP_Focus:Move(1, 0) end
    elseif context == "GUIDE" then
        return PRP_Guide:Navigate(direction)
    elseif context == "QUICK" then
        return PRP_QuickMenu:Navigate(direction)
    elseif context == "INVENTORY" then
        return PRP_Inventory:Navigate(direction)
    elseif context == "COMPANION" then
        return PRP_Companion:Navigate(direction)
    end
    return false
end

function PRP_Router:GetDpadAction(direction)
    -- On the RP6 stick-top model the D-pad is below the movement stick. Keep
    -- the eight most common actions on the right hand and put 9-12 here.
    if direction == "UP" then return 9 end
    if direction == "DOWN" then return 10 end
    if direction == "LEFT" then return 11 end
    if direction == "RIGHT" then return 12 end
    return nil
end

function PRP_Router:Navigate(direction, state)
    local context
    local captured
    local actionIndex
    if not self.initialized or not PRP:IsEnabled() then return end
    if state == "down" then
        context = self:GetContext()
        self.navCaptured[direction] = context
        if context == "CHAT" then return end
        if self:IsUIContext(context) then
            self:MoveUI(context, direction)
            return
        end
        if PocketRealmPadDB.action.dpadWorldMode == "TARGETING" then
            if PRP_Targeting then PRP_Targeting:WorldDirection(direction) end
            return
        end
        actionIndex = self:GetDpadAction(direction)
        self.navCaptured[direction] = { context = "WORLD_ACTION", action = actionIndex }
        if actionIndex and PRP_ActionBar then PRP_ActionBar:OnKey(actionIndex, "down") end
        return
    end

    captured = self.navCaptured[direction]
    self.navCaptured[direction] = nil
    if type(captured) == "table" and captured.context == "WORLD_ACTION" then
        if captured.action and PRP_ActionBar then PRP_ActionBar:OnKey(captured.action, "up") end
    end
end

function PRP_Router:QuickMenuKey(state)
    if not self.initialized or not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 or PRP_ChatEditActive() then return end
    if PRP_Focus and PRP_Focus:HasModal() then return end
    PRP_QuickMenu:OnKey(state)
end

function PRP_Router:InventoryKey()
    if not self.initialized or not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 or PRP_ChatEditActive() then return end
    if PRP_Focus and PRP_Focus:HasModal() then return end
    PRP_Inventory:Toggle()
end

function PRP_Router:CompanionKey()
    if not self.initialized or not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 or PRP_ChatEditActive() then return end
    if PRP_Focus and PRP_Focus:HasModal() then return end
    PRP_Companion:Toggle()
end

function PRP_Router:OpenChat(slash)
    if not ChatFrame_OpenChat then return false end
    if PRP_Focus and PRP_Focus:HasModal() then return false end
    PRP:ReleaseAllInputs()
    if slash then ChatFrame_OpenChat("/") else ChatFrame_OpenChat("") end
    PRP:SetMode("CHAT")
    return true
end

function PRP_Router:TargetCommand(command)
    if not self.initialized or not PRP:IsEnabled() or PRP_ChatEditActive() then return end
    if self:GetContext() ~= "WORLD" then return end
    if PRP_Targeting then PRP_Targeting:Command(command) end
end

function PRP_Router:ReleaseAll()
    local index
    self.captured = {}
    self.navCaptured = {}
    for index = 1, 12 do self.captured[index] = nil end
    if PRP_ActionBar then PRP_ActionBar:ReleaseAll() end
    if PRP_VanillaActions then PRP_VanillaActions:ReleaseAll() end
end

function PRP_ActionKey(index, state)
    if PRP_Router then PRP_Router:ActionKey(index, state) end
end

function PRP_NavKey(direction, state)
    if PRP_Router then PRP_Router:Navigate(direction, state) end
end

function PRP_QuickMenuKey(state)
    if PRP_Router then PRP_Router:QuickMenuKey(state) end
end

function PRP_InventoryKey()
    if PRP_Router then PRP_Router:InventoryKey() end
end

function PRP_ChatKey(slash)
    if PRP_Router then PRP_Router:OpenChat(slash) end
end

function PRP_TargetCommand(command)
    if PRP_Router then PRP_Router:TargetCommand(command) end
end
