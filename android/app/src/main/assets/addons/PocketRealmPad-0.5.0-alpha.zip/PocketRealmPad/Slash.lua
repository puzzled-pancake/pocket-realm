-- Recovery and configuration commands for the managed 1.12 client copy.
-- Normal play should use bindings; these commands remain intentionally small.

PRP_Slash = {
    initialized = false,
}

function PRP_Slash:Initialize()
    if self.initialized then
        return
    end
    SLASH_POCKETREALMPAD1 = "/prp"
    SLASH_POCKETREALMPAD2 = "/pocketpad"
    SlashCmdList["POCKETREALMPAD"] = PRP_SlashCommand
    self.initialized = true
end

function PRP_Slash:Split(message)
    local command
    local rest
    local startPos
    local endPos
    message = message or ""
    message = string.gsub(message, "^%s+", "")
    message = string.gsub(message, "%s+$", "")
    startPos, endPos, command, rest = string.find(message, "^(%S+)%s*(.*)$")
    if not command then
        return "", ""
    end
    return string.lower(command), rest or ""
end

function PRP_Slash:Status()
    local context = PRP_Router and PRP_Router:GetContext() or "unknown"
    local page = PRP_ActionBar and PRP_ActionBar.currentPage or 1
    PRP:Print("v" .. PRP.version .. "; " .. (PRP:IsEnabled() and "enabled" or "disabled")
        .. "; " .. (PocketRealmPadDB.safeMode == 1 and "safe mode" or "normal mode")
        .. "; current view=" .. tostring(context))
    PRP:Print("Abilities use Vanilla page " .. tostring(page)
        .. "; D-pad=" .. string.lower(tostring(PocketRealmPadDB.action.dpadWorldMode))
        .. "; extra bars=" .. (PocketRealmPadDB.action.pageSet == "B" and "on" or "off"))
    local bound, total = PRP:GetEssentialBindingStatus()
    PRP:Print("Controller essentials bound=" .. tostring(bound) .. "/" .. tostring(total))
    if PRP_Handheld then
        PRP:Print(PRP_Handheld:StatusText() .. "; addonScale=" .. tostring(PocketRealmPadDB.scale)
            .. "; textScale=" .. tostring(PocketRealmPadDB.textScale))
    end
end

function PRP_Slash:ShowConfiguredOverlays()
    if not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 then
        return
    end
    if PRP_ActionBar and PRP_ActionBar.frame then
        PRP_SetShown(PRP_ActionBar.frame, PocketRealmPadDB.bar.shown == 1)
    end
    if PRP_Targeting and PRP_Targeting.frame then
        PRP_SetShown(PRP_Targeting.frame, PocketRealmPadDB.target.shown == 1)
    end
end

function PRP_Slash:SetEnabled(enabled)
    PocketRealmPadDB.enabled = enabled and 1 or 0
    PRP:ReleaseAllInputs()
    if enabled then
        self:ShowConfiguredOverlays()
        PRP:RefreshAll()
        PRP:SetMode("WORLD")
        PRP:Print("enabled")
    else
        PRP:CloseTransientSurfaces()
        if PRP_ActionBar and PRP_ActionBar.frame then PRP_ActionBar.frame:Hide() end
        if PRP_Targeting and PRP_Targeting.frame then PRP_Targeting.frame:Hide() end
        if PRP_Focus then PRP_Focus:Clear() end
        PRP:SetMode("DISABLED")
        PRP:Print("disabled")
    end
end

function PRP_Slash:SetSafeMode(enabled)
    PocketRealmPadDB.safeMode = enabled and 1 or 0
    PRP:ReleaseAllInputs()
    if enabled then
        PRP:CloseTransientSurfaces()
        if PRP_ActionBar and PRP_ActionBar.frame then PRP_ActionBar.frame:Hide() end
        if PRP_Targeting and PRP_Targeting.frame then PRP_Targeting.frame:Hide() end
        if PRP_Focus then PRP_Focus:Clear() end
        PRP:Print("safe mode enabled: overlays and focus navigation are off; bound action execution remains available")
    else
        self:ShowConfiguredOverlays()
        PRP:RefreshAll()
        PRP:Print("safe mode disabled")
    end
end

function PRP_Slash:ApplyAddonScale()
    local value = PocketRealmPadDB.scale or 1
    if PRP_ActionBar and PRP_ActionBar.frame then PRP_ActionBar.frame:SetScale(value) end
    if PRP_Targeting and PRP_Targeting.frame then PRP_Targeting.frame:SetScale(value) end
    if PRP_Inventory and PRP_Inventory.frame then PRP_Inventory.frame:SetScale(value) end
    if PRP_QuickMenu and PRP_QuickMenu.frame then PRP_QuickMenu.frame:SetScale(value) end
    if PRP_Companion and PRP_Companion.frame then PRP_Companion.frame:SetScale(value) end
    if PRP_Guide and PRP_Guide.frame then PRP_Guide.frame:SetScale(value) end
end

function PRP_Slash:SetScale(text)
    local value = tonumber(text)
    if not value then
        PRP:Print("usage: /prp scale 0.70-1.50")
        return
    end
    value = PRP_Clamp(value, 0.70, 1.50)
    PocketRealmPadDB.scale = value
    self:ApplyAddonScale()
    PRP:Print("addon scale set to " .. tostring(value))
end

function PRP_Slash:SetTextScale(text)
    local value = tonumber(text)
    if not value then
        PRP:Print("usage: /prp textscale 0.80-1.60")
        return
    end
    value = PRP_Clamp(value, 0.80, 1.60)
    PocketRealmPadDB.textScale = value
    if PRP_Handheld then PRP_Handheld:Apply(true) end
    PRP:Print("text scale set to " .. tostring(value))
end

function PRP_Slash:SetDisplay(text)
    local value = string.lower(text or "")
    local profile
    if value == "status" or value == "" then
        PRP:Print(PRP_Handheld:StatusText())
        return
    end
    profile = PRP_Handheld:SetProfile(value)
    PRP:Print("display profile set to " .. tostring(profile) .. "; " .. PRP_Handheld:StatusText())
end

function PRP_Slash:SetDevice(text)
    local value = string.upper(text or "")
    local hint
    if value == "RP6" or value == "RETROID" or value == "RETROID_POCKET_6" then
        hint = "RETROID_POCKET_6"
    elseif value == "HANDHELD" or value == "ANDROID_HANDHELD" then
        hint = "ANDROID_HANDHELD"
    elseif value == "TABLET" or value == "ANDROID_TABLET" then
        hint = "ANDROID_TABLET"
    elseif value == "TV" or value == "LARGE" or value == "ANDROID_LARGE" or value == "DESKTOP" then
        hint = "ANDROID_LARGE"
    elseif value == "AUTO" or value == "NONE" then
        hint = ""
    else
        PRP:Print("usage: /prp device rp6|handheld|tablet|large|auto")
        return
    end
    PocketRealmPadDB.display.deviceHint = hint
    if PRP_Handheld then PRP_Handheld:Apply(true) end
    PRP:Print("device hint set to " .. (hint ~= "" and hint or "AUTO") .. "; " .. PRP_Handheld:StatusText())
end

function PRP_Slash:SetDpad(text)
    local value = string.upper(text or "")
    if value ~= "ACTIONS" and value ~= "TARGETING" then
        PRP:Print("usage: /prp dpad actions|targeting")
        return
    end
    PRP:ReleaseAllInputs()
    PocketRealmPadDB.action.dpadWorldMode = value
    PRP:Print(value == "ACTIONS" and "D-pad uses abilities 9-12 in the world" or "D-pad uses targeting in the world")
end

function PRP_Slash:SetPageSet(text)
    local value = string.upper(text or "")
    if value ~= "A" and value ~= "B" then
        PRP:Print("usage: /prp pageset a|b")
        return
    end
    PRP:ReleaseAllInputs()
    PocketRealmPadDB.action.pageSet = value
    if PRP_ActionBar then PRP_ActionBar:UpdateAll(true) end
    PRP:Print(value == "B" and "extra action bars enabled" or "main action bars enabled")
end

function PRP_Slash:SetSlots(text)
    local value = string.lower(text or "")
    if value == "on" then
        PocketRealmPadDB.action.showSlotNumbers = 1
    elseif value == "off" then
        PocketRealmPadDB.action.showSlotNumbers = 0
    else
        PRP:Print("usage: /prp slots on|off")
        return
    end
    if PRP_ActionBar then PRP_ActionBar:UpdateAll(true) end
end

function PRP_Slash:Reset()
    PocketRealmPadDB = PRP_CopyTable(PRP_DEFAULTS)
    PRP:ReleaseAllInputs()
    if PRP_Handheld then PRP_Handheld:Initialize() end
    self:ApplyAddonScale()
    self:ShowConfiguredOverlays()
    PRP:RefreshAll()
    PRP:Print("settings reset; opening Controls & Help")
    if PRP_Guide then PRP_Guide:Show() end
end

function PRP_Slash:Controls()
    PRP:Print("RP6 stick-top: left stick move; right stick camera; " .. PRP_ControlLabel("jump") .. " jump (" .. PRP_ControlLabel("jumpFallback") .. " backup); " .. PRP_ControlLabel("target") .. " nearest enemy (" .. PRP_ControlLabel("targetFallback") .. " backup)")
    PRP:Print("Touch/place the pointer on an NPC, object, or corpse; " .. PRP_ControlLabel("interact") .. " right-clicks at that pointer")
    PRP:Print("Face right/bottom/left/top " .. PRP_ControlArrayLabel("face", 1) .. "/" .. PRP_ControlArrayLabel("face", 2) .. "/" .. PRP_ControlArrayLabel("face", 3) .. "/" .. PRP_ControlArrayLabel("face", 4) .. " are abilities 1-4; " .. PRP_ControlLabel("bank") .. "+face are 5-8; D-pad is 9-12")
    PRP:Print(PRP_ControlLabel("layer1") .. " and " .. PRP_ControlLabel("layer2") .. " change ability layers; " .. PRP_ControlLabel("menu") .. " Quick Menu; " .. PRP_ControlLabel("inventory") .. " Inventory")
    PRP:Print("In supported panels: D-pad moves focus; right " .. PRP_ControlLabel("confirm") .. " chooses; bottom " .. PRP_ControlLabel("back") .. " goes back; left " .. PRP_ControlLabel("alternate") .. " is More; spending/commit actions require " .. PRP_ControlLabel("confirm") .. " twice")
end

function PRP_Slash:Help()
    PRP:Print("New player: /prp guide, /prp controls, /prp status")
    PRP:Print("Display: /prp display auto|540|600|720|800|900|1080|1200|1440|tablet|large")
    PRP:Print("Recovery: /prp safe on|off, /prp enable, /prp disable, /prp reset")
    PRP:Print("Advanced: scale, textscale, dpad, pageset, slots, bar, debug")
end

function PRP_Slash:Handle(message)
    local command
    local rest
    local sub
    command, rest = self:Split(message)
    if command == "" or command == "help" then
        self:Help()
    elseif command == "guide" then
        if PRP_Guide then PRP_Guide:Show() end
    elseif command == "controls" then
        self:Controls()
    elseif command == "status" then
        self:Status()
    elseif command == "enable" then
        self:SetEnabled(true)
    elseif command == "disable" then
        self:SetEnabled(false)
    elseif command == "safe" then
        sub = string.lower(rest or "")
        if sub == "on" then self:SetSafeMode(true)
        elseif sub == "off" then self:SetSafeMode(false)
        else PRP:Print("usage: /prp safe on|off") end
    elseif command == "bar" then
        sub = string.lower(rest or "")
        if sub == "show" then
            PocketRealmPadDB.bar.shown = 1
            self:ShowConfiguredOverlays()
        elseif sub == "hide" then
            PocketRealmPadDB.bar.shown = 0
            if PRP_ActionBar and PRP_ActionBar.frame then PRP_ActionBar.frame:Hide() end
        elseif sub == "lock" then
            PocketRealmPadDB.bar.locked = 1
            PRP:Print("action bar locked")
        elseif sub == "unlock" then
            PocketRealmPadDB.bar.locked = 0
            PRP:Print("action bar unlocked; drag it with the touch pointer")
        else
            PRP:Print("usage: /prp bar show|hide|lock|unlock")
        end
    elseif command == "scale" then
        self:SetScale(rest)
    elseif command == "textscale" then
        self:SetTextScale(rest)
    elseif command == "display" then
        self:SetDisplay(rest)
    elseif command == "device" then
        self:SetDevice(rest)
    elseif command == "dpad" then
        self:SetDpad(rest)
    elseif command == "pageset" then
        self:SetPageSet(rest)
    elseif command == "slots" then
        self:SetSlots(rest)
    elseif command == "debug" then
        sub = string.lower(rest or "")
        if sub == "on" then
            PocketRealmPadDB.debug = 1
            PRP:SetMode(PRP.mode)
            PRP:Print("debug logging and mode badge enabled")
        elseif sub == "off" then
            PocketRealmPadDB.debug = 0
            PRP:SetMode(PRP.mode)
            PRP:Print("debug logging and mode badge disabled")
        else
            PRP:Print("usage: /prp debug on|off")
        end
    elseif command == "reset" then
        self:Reset()
    else
        self:Help()
    end
end

function PRP_SlashCommand(message)
    if PRP_Slash then
        PRP_Slash:Handle(message)
    end
end
