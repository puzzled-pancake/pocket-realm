-- Vanilla targeting semantics. No soft targets, GUID/nameplate enumeration,
-- interact-target CVars, or retail target APIs are assumed.

PRP_Targeting = {
    initialized = false,
    groupIndex = 0,
    updateElapsed = 0,
}

function PRP_Targeting:Initialize()
    local frame
    local health
    if self.initialized then return end
    frame = PRP_UI:CreatePanel("PocketRealmPadTargetCard", 560, 78, "HIGH")
    frame:SetScale(PocketRealmPadDB.scale or 1)
    PRP_SetFramePosition(frame, PocketRealmPadDB.target)
    self.nameText = PRP_UI:CreateLabel(frame, "OVERLAY", "GameFontNormal", "No target")
    self.nameText:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -11)
    self.nameText:SetJustifyH("LEFT")
    self.detailText = PRP_UI:CreateLabel(frame, "OVERLAY", "GameFontHighlightSmall", "Press your Target control to select an enemy")
    self.detailText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 14, 11)
    self.detailText:SetJustifyH("LEFT")
    health = CreateFrame("StatusBar", "PocketRealmPadTargetHealth", frame)
    health:SetHeight(10)
    health:SetPoint("TOPLEFT", frame, "TOPLEFT", 14, -36)
    health:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    health:SetMinMaxValues(0, 1)
    health:SetValue(0)
    health:SetStatusBarColor(0.2, 0.8, 0.2)
    self.health = health
    self.frame = frame
    self.initialized = true
    self:ApplyMetrics()
    PRP_SetShown(frame, PRP:IsEnabled() and PocketRealmPadDB.target.shown == 1 and PocketRealmPadDB.safeMode ~= 1)
    self:Update(true)
end

function PRP_Targeting:ApplyMetrics()
    local metrics
    local width
    local height
    local fontScale
    if not self.initialized or not PRP_Handheld then return end
    metrics = PRP_Handheld:GetMetrics()
    fontScale = PRP_Handheld:GetFontScale()
    width = metrics.targetWidth
    height = metrics.targetHeight
    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    PocketRealmPadDB.target.y = metrics.targetYOffset or -42
    PRP_SetFramePosition(self.frame, PocketRealmPadDB.target)
    self.nameText:SetWidth(width - 28)
    self.detailText:SetWidth(width - 28)
    self.health:SetWidth(width - 28)
    self.health:SetHeight(metrics.targetHealthHeight or 10)
    PRP_SetFontScale(self.nameText, fontScale, 14)
    PRP_SetFontScale(self.detailText, fontScale, 11)
    self.health:ClearAllPoints()
    self.health:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, metrics.targetHealthYOffset or -36)
end

function PRP_Targeting:GetGroupUnits()
    local units = {}
    local count = 0
    local index
    count = count + 1
    units[count] = "player"
    if PRP_UnitExists("pet") then
        count = count + 1
        units[count] = "pet"
    end
    if GetNumRaidMembers and GetNumRaidMembers() > 0 then
        for index = 1, 40 do
            if PRP_UnitExists("raid" .. index) then
                count = count + 1
                units[count] = "raid" .. index
            end
            if PRP_UnitExists("raidpet" .. index) then
                count = count + 1
                units[count] = "raidpet" .. index
            end
        end
    else
        for index = 1, 4 do
            if PRP_UnitExists("party" .. index) then
                count = count + 1
                units[count] = "party" .. index
            end
            if PRP_UnitExists("partypet" .. index) then
                count = count + 1
                units[count] = "partypet" .. index
            end
        end
    end
    return units
end

function PRP_Targeting:FindCurrentGroupIndex(units)
    local index
    for index = 1, PRP_TableLength(units) do
        if UnitIsUnit and UnitIsUnit(units[index], "target") then return index end
    end
    return 0
end

function PRP_Targeting:CycleGroup(direction)
    local units = self:GetGroupUnits()
    local count = PRP_TableLength(units)
    local index
    if count == 0 then return false end
    index = self:FindCurrentGroupIndex(units)
    if index == 0 then
        index = direction < 0 and count or 1
    else
        index = index + direction
        if index < 1 then index = count elseif index > count then index = 1 end
    end
    self.groupIndex = index
    if TargetUnit then TargetUnit(units[index]) end
    return true
end

function PRP_Targeting:Command(command)
    if command == "NEXT_ENEMY" then
        if TargetNearestEnemy then TargetNearestEnemy() end
    elseif command == "PREV_ENEMY" then
        if TargetNearestEnemy then TargetNearestEnemy(1) end
    elseif command == "NEXT_FRIEND" then
        if TargetNearestFriend then TargetNearestFriend() end
    elseif command == "PREV_FRIEND" then
        if TargetNearestFriend then TargetNearestFriend(1) end
    elseif command == "GROUP_NEXT" then
        self:CycleGroup(1)
    elseif command == "GROUP_PREV" then
        self:CycleGroup(-1)
    elseif command == "LAST_HOSTILE" then
        if TargetLastEnemy then TargetLastEnemy() end
    elseif command == "ASSIST" then
        if AssistUnit then AssistUnit("target") end
    elseif command == "SELF" then
        if TargetUnit then TargetUnit("player") end
    elseif command == "PET" then
        if TargetUnit then TargetUnit("pet") end
    elseif command == "CLEAR" then
        if ClearTarget then ClearTarget() end
    elseif command == "ATTACK" then
        if AttackTarget then AttackTarget() end
    elseif command == "PET_ATTACK" then
        if PetAttack then PetAttack() end
    elseif command == "FOLLOW" then
        if FollowUnit then FollowUnit("target") end
    end
    self:Update(true)
end

function PRP_Targeting:WorldDirection(direction)
    if direction == "UP" then self:Command("NEXT_ENEMY")
    elseif direction == "DOWN" then self:Command("PREV_ENEMY")
    elseif direction == "LEFT" then self:Command("GROUP_PREV")
    elseif direction == "RIGHT" then self:Command("GROUP_NEXT") end
end

function PRP_Targeting:GetTargetColor()
    local reaction
    local color
    if UnitReaction then reaction = UnitReaction("player", "target") end
    if reaction and FACTION_BAR_COLORS then
        color = FACTION_BAR_COLORS[reaction]
        if color then return color.r or 1, color.g or 1, color.b or 1 end
    end
    if UnitCanAttack and UnitCanAttack("player", "target") then return 1, 0.2, 0.2 end
    if UnitIsFriend and UnitIsFriend("player", "target") then return 0.2, 1, 0.2 end
    return 1, 0.82, 0
end

function PRP_Targeting:GetLevelText(level)
    if not level or level < 0 then return "??" end
    return tostring(level)
end

function PRP_Targeting:Update(force)
    local name
    local level
    local classification
    local health
    local maximum
    local percent
    local r
    local g
    local b
    local status = ""
    local relation = "Neutral"
    if not self.initialized then return end
    if not PRP_UnitExists("target") then
        self.nameText:SetText("No target")
        self.nameText:SetTextColor(0.75, 0.75, 0.75)
        self.detailText:SetText("Press [" .. PRP_ControlLabel("target") .. "] for enemy. Touch NPC/object, then [" .. PRP_ControlLabel("interact") .. "].")
        self.health:SetMinMaxValues(0, 1)
        self.health:SetValue(0)
        return
    end
    name = UnitName("target") or "Target"
    level = UnitLevel and UnitLevel("target") or 0
    classification = UnitClassification and UnitClassification("target") or "normal"
    health = UnitHealth and UnitHealth("target") or 0
    maximum = UnitHealthMax and UnitHealthMax("target") or 1
    if maximum < 1 then maximum = 1 end
    percent = math.floor((health / maximum) * 100 + 0.5)
    if classification == "worldboss" then status = "Boss"
    elseif classification == "rareelite" then status = "Rare Elite"
    elseif classification == "elite" then status = "Elite"
    elseif classification == "rare" then status = "Rare" end
    if UnitIsDead and UnitIsDead("target") then
        if status ~= "" then status = status .. ", Dead" else status = "Dead" end
    end
    if UnitCanAttack and UnitCanAttack("player", "target") then relation = "Hostile"
    elseif UnitIsFriend and UnitIsFriend("player", "target") then relation = "Friendly" end
    r, g, b = self:GetTargetColor()
    self.nameText:SetText(name .. "  |cffbbbbbbL" .. self:GetLevelText(level) .. "|r")
    self.nameText:SetTextColor(r, g, b)
    if status ~= "" then
        self.detailText:SetText(status .. "   " .. relation .. "   " .. tostring(percent) .. "% health")
    else
        self.detailText:SetText(relation .. "   " .. tostring(percent) .. "% health")
    end
    self.health:SetMinMaxValues(0, maximum)
    self.health:SetValue(health)
    self.health:SetStatusBarColor(r, g, b)
end

function PRP_Targeting:OnEvent(eventName, firstArg)
    if (eventName == "UNIT_HEALTH" or eventName == "UNIT_MAXHEALTH") and firstArg ~= "target" then return end
    if eventName == "PLAYER_TARGET_CHANGED"
        or eventName == "UNIT_HEALTH"
        or eventName == "UNIT_MAXHEALTH"
        or eventName == "PARTY_MEMBERS_CHANGED"
        or eventName == "RAID_ROSTER_UPDATE" then
        self:Update(true)
    end
end

function PRP_Targeting:OnUpdate(elapsed)
    self.updateElapsed = self.updateElapsed + elapsed
    if self.updateElapsed >= 0.25 then
        self.updateElapsed = 0
        self:Update(false)
    end
end
