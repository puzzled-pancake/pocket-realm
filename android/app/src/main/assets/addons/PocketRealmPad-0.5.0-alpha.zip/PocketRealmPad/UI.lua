-- Shared visual primitives. All textures and fonts are Blizzard 1.12 assets.

PRP_UI = {
    initialized = false,
    toastUntil = 0,
    focusOuter = {},
    focusInner = {},
}

function PRP_UI:CreatePanel(name, width, height, strata)
    local frame = CreateFrame("Frame", name, UIParent)
    frame:SetWidth(width)
    frame:SetHeight(height)
    frame:SetFrameStrata(strata or "DIALOG")
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 24,
        insets = { left = 8, right = 8, top = 8, bottom = 8 },
    })
    frame:SetBackdropColor(0.025, 0.035, 0.055, 0.96)
    return frame
end

function PRP_UI:CreateLabel(parent, layer, template, text)
    local label = parent:CreateFontString(nil, layer or "OVERLAY", template or "GameFontHighlight")
    label:SetText(text or "")
    return label
end

function PRP_UI:CreateFocusEdge(frame, layer, horizontal, outer)
    local texture = frame:CreateTexture(nil, layer)
    texture:SetTexture("Interface\\Buttons\\WHITE8X8")
    if outer then
        texture:SetVertexColor(0.10, 0.75, 1.00, 1.00)
    else
        texture:SetVertexColor(0.00, 0.00, 0.00, 0.96)
    end
    if horizontal then
        texture:SetHeight(4)
    else
        texture:SetWidth(4)
    end
    return texture
end

function PRP_UI:Initialize()
    local frame
    local index
    if self.initialized then
        return
    end

    self.root = CreateFrame("Frame", "PocketRealmPadUIRoot", UIParent)
    self.root:SetAllPoints(UIParent)
    self.root:SetFrameStrata("HIGH")
    self.root:EnableMouse(false)

    self.mode = CreateFrame("Frame", "PocketRealmPadModeBadge", UIParent)
    self.mode:SetFrameStrata("HIGH")
    self.mode:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    self.mode:SetBackdropColor(0, 0, 0, 0.80)
    self.modeText = self:CreateLabel(self.mode, "OVERLAY", "GameFontNormalSmall", "Pocket Realm Pad")
    self.modeText:SetPoint("CENTER", self.mode, "CENTER", 0, 0)
    self.mode:Hide()

    self.prompt = CreateFrame("Frame", "PocketRealmPadPrompt", UIParent)
    self.prompt:SetFrameStrata("TOOLTIP")
    self.prompt:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    self.prompt:SetBackdropColor(0, 0, 0, 0.90)
    self.promptText = self:CreateLabel(self.prompt, "OVERLAY", "GameFontHighlightSmall", "")
    self.promptText:SetPoint("CENTER", self.prompt, "CENTER", 0, 0)
    self.promptText:SetJustifyH("CENTER")
    self.prompt:Hide()

    self.toast = CreateFrame("Frame", "PocketRealmPadToast", UIParent)
    self.toast:SetFrameStrata("TOOLTIP")
    self.toast:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    self.toast:SetBackdropColor(0.02, 0.02, 0.02, 0.96)
    self.toastText = self:CreateLabel(self.toast, "OVERLAY", "GameFontHighlight", "")
    self.toastText:SetPoint("CENTER", self.toast, "CENTER", 0, 0)
    self.toastText:SetJustifyH("CENTER")
    self.toast:Hide()

    frame = CreateFrame("Frame", "PocketRealmPadFocusRing", UIParent)
    frame:SetFrameStrata("TOOLTIP")
    frame:EnableMouse(false)
    self.focusRing = frame

    for index = 1, 4 do
        self.focusInner[index] = self:CreateFocusEdge(frame, "ARTWORK", index <= 2, false)
        self.focusOuter[index] = self:CreateFocusEdge(frame, "OVERLAY", index <= 2, true)
    end
    self.focusRing:Hide()

    self.initialized = true
    self:ApplyMetrics()
end

function PRP_UI:LayoutFocusEdges()
    local metrics = PRP_Handheld and PRP_Handheld:GetMetrics() or nil
    local thickness = metrics and metrics.focusThickness or 4
    local pad = metrics and metrics.focusPad or 5
    local shadow = 1
    local top = self.focusOuter[1]
    local bottom = self.focusOuter[2]
    local left = self.focusOuter[3]
    local right = self.focusOuter[4]
    local itop = self.focusInner[1]
    local ibottom = self.focusInner[2]
    local ileft = self.focusInner[3]
    local iright = self.focusInner[4]

    top:ClearAllPoints()
    top:SetHeight(thickness)
    top:SetPoint("TOPLEFT", self.focusRing, "TOPLEFT", -pad, pad)
    top:SetPoint("TOPRIGHT", self.focusRing, "TOPRIGHT", pad, pad)
    bottom:ClearAllPoints()
    bottom:SetHeight(thickness)
    bottom:SetPoint("BOTTOMLEFT", self.focusRing, "BOTTOMLEFT", -pad, -pad)
    bottom:SetPoint("BOTTOMRIGHT", self.focusRing, "BOTTOMRIGHT", pad, -pad)
    left:ClearAllPoints()
    left:SetWidth(thickness)
    left:SetPoint("TOPLEFT", self.focusRing, "TOPLEFT", -pad, pad)
    left:SetPoint("BOTTOMLEFT", self.focusRing, "BOTTOMLEFT", -pad, -pad)
    right:ClearAllPoints()
    right:SetWidth(thickness)
    right:SetPoint("TOPRIGHT", self.focusRing, "TOPRIGHT", pad, pad)
    right:SetPoint("BOTTOMRIGHT", self.focusRing, "BOTTOMRIGHT", pad, -pad)

    itop:ClearAllPoints()
    itop:SetHeight(thickness + (shadow * 2))
    itop:SetPoint("TOPLEFT", self.focusRing, "TOPLEFT", -pad - shadow, pad + shadow)
    itop:SetPoint("TOPRIGHT", self.focusRing, "TOPRIGHT", pad + shadow, pad + shadow)
    ibottom:ClearAllPoints()
    ibottom:SetHeight(thickness + (shadow * 2))
    ibottom:SetPoint("BOTTOMLEFT", self.focusRing, "BOTTOMLEFT", -pad - shadow, -pad - shadow)
    ibottom:SetPoint("BOTTOMRIGHT", self.focusRing, "BOTTOMRIGHT", pad + shadow, -pad - shadow)
    ileft:ClearAllPoints()
    ileft:SetWidth(thickness + (shadow * 2))
    ileft:SetPoint("TOPLEFT", self.focusRing, "TOPLEFT", -pad - shadow, pad + shadow)
    ileft:SetPoint("BOTTOMLEFT", self.focusRing, "BOTTOMLEFT", -pad - shadow, -pad - shadow)
    iright:ClearAllPoints()
    iright:SetWidth(thickness + (shadow * 2))
    iright:SetPoint("TOPRIGHT", self.focusRing, "TOPRIGHT", pad + shadow, pad + shadow)
    iright:SetPoint("BOTTOMRIGHT", self.focusRing, "BOTTOMRIGHT", pad + shadow, -pad - shadow)
end

function PRP_UI:ApplyMetrics()
    local metrics
    local scale
    if not self.initialized or not PRP_Handheld then
        return
    end
    metrics = PRP_Handheld:GetMetrics()
    scale = PRP_Handheld:GetFontScale()

    self.mode:ClearAllPoints()
    self.mode:SetPoint("TOPLEFT", UIParent, "TOPLEFT", metrics.edgePadding or 12, -(metrics.edgePadding or 12))
    self.mode:SetWidth(metrics.modeWidth or 196)
    self.mode:SetHeight(metrics.modeHeight or 26)

    self.prompt:ClearAllPoints()
    self.prompt:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, metrics.actionYOffset - 24)
    self.prompt:SetWidth(metrics.promptWidth)
    self.prompt:SetHeight(metrics.promptHeight or 32)
    self.promptText:SetWidth(metrics.promptWidth - 18)

    self.toast:ClearAllPoints()
    self.toast:SetPoint("CENTER", UIParent, "CENTER", 0, metrics.toastYOffset or 128)
    self.toast:SetWidth(metrics.toastWidth)
    self.toast:SetHeight(metrics.toastHeight or 54)
    self.toastText:SetWidth(metrics.toastWidth - 26)

    PRP_SetFontScale(self.modeText, scale, 10)
    PRP_SetFontScale(self.promptText, scale, 10)
    PRP_SetFontScale(self.toastText, scale, 12)
    self:LayoutFocusEdges()
end

function PRP_UI:SetMode(mode)
    if not self.initialized then return end
    self.modeText:SetText("Pocket Realm Pad  |cff79b7ff" .. tostring(mode) .. "|r")
    if PocketRealmPadDB and PocketRealmPadDB.ui
        and (PocketRealmPadDB.ui.showModeBadge == 1 or PocketRealmPadDB.debug == 1) then
        self.mode:Show()
    else
        self.mode:Hide()
    end
end

function PRP_UI:SetPrompt(text)
    if not self.initialized then
        return
    end
    if not text or text == "" then
        self.prompt:Hide()
        return
    end
    self.promptText:SetText(text)
    self.prompt:Show()
end

function PRP_UI:SetFocus(frame, label, showPrompt)
    if not self.initialized or not frame or not PRP_IsVisible(frame) then
        self:ClearFocus()
        return
    end
    self.focusRing:ClearAllPoints()
    self.focusRing:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    self.focusRing:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    self.focusRing:Show()
    if showPrompt ~= false and label and label ~= "" then
        self:SetPrompt("Move: D-pad   " .. PRP_ControlHint("Confirm", "confirm") .. "   " .. PRP_ControlHint("Back", "back") .. "   " .. PRP_ControlHint("More", "alternate") .. "   |cff79b7ff" .. label .. "|r")
    end
end

function PRP_UI:ClearFocus()
    if self.initialized then
        self.focusRing:Hide()
        self:SetPrompt("")
    end
end

function PRP_UI:ShowToast(text, seconds)
    if not self.initialized then
        return
    end
    self.toastText:SetText(tostring(text or ""))
    self.toastUntil = GetTime() + (seconds or 2.0)
    self.toast:Show()
end

function PRP_UI:OnUpdate(elapsed)
    if self.toast and PRP_IsVisible(self.toast) and self.toastUntil > 0 and GetTime() >= self.toastUntil then
        self.toast:Hide()
        self.toastUntil = 0
    end
end
