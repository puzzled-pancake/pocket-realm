# Vanilla 1.12 action and binding audit — Pocket Realm Pad v0.5

## Executive result

The build-5875 client exposes 12 main action buttons across six ordinary pages: **72 ordinary slots**. Form/stance/stealth bonus bars substitute for semantic page 1. Pet actions and stance/form positions are separate 10-position systems.

Pocket Realm Pad adds **99 fixed project bindings**: **14 Essentials** and **85 Advanced**. **31** require reliable key-down/key-up delivery. The stock client catalog contains **228 bindings**.

## Stock disposition totals

| Disposition | Count | Meaning |
|---|---:|---|
| Developer-only | 9 | Debug/renderer commands excluded from normal profiles. |
| Omitted | 5 | Platform-irrelevant feature deliberately excluded. |
| PRP semantic | 148 | Project provides a controller-aware semantic equivalent or surface. |
| Stock optional | 50 | Valid Vanilla command available only in an advanced/manual profile. |
| Winlator direct | 16 | Continuous movement/camera/pointer plus default Jump belong to the Android/Wine input bridge. |

## Default novice map

| Control | World meaning | Menu/touch meaning |
|---|---|---|
| Left stick | Move forward/back and strafe | Winlator sends stock movement key down/up events. |
| Right stick | Camera look | Winlator sends relative mouse movement while camera-look is active. |
| Right A / Bottom B / Left Y / Top X | Abilities 1 / 2 / 3 / 4 | In supported panels: Confirm / Back / More / Quick Menu. |
| D-pad | Abilities 9 / 10 / 11 / 12 | In menus and addon grids: move selection. |
| R1 + A/B/Y/X | Abilities 5 / 6 / 7 / 8 | R1 is a compact ability bank, not a general menu modifier. |
| L1 | Ability layer 2 | Maps to ordinary action page 2; page 6 in Extra Bars mode. |
| L2 | Ability layer 3 | Maps to ordinary action page 3. |
| L1 + L2 | Ability layer 4 | Maps to ordinary action page 4. |
| M1 / L3 fallback | Target nearest enemy | Repeating it cycles using the original Vanilla target command. |
| R2 | Right-click at the current pointer | Touch or point at an NPC, object, or corpse first. Vanilla has no Interact-with-target action. |
| M2 / R3 fallback | Jump | Winlator binds directly to stock `JUMP`; it is not an addon command. |
| Start | Open/close Quick Menu | Simple press toggle; no hidden tap/hold timing. |
| Select | Open/close Controller Inventory | Right A uses/equips; Left Y picks up/places; touch selects safely. |
| Touchscreen | Precise pointer and text tasks | Login, character creation, NPC/object selection, drag, scroll, IME, money/text fields, ground-target spells, and unsupported controls. |

Target self is Advanced/unbound. Stock auto-run remains optional Advanced because it creates a latched movement state. R2 is a mouse operation, not an Interact action.
The launcher may swap or disable M1/M2 while preserving L3/R3 fallbacks; it updates the displayed control labels in the managed saved variables. Analogue L2/R2 are converted to hysteretic digital transitions outside Lua.

## Correct action-page mapping

| Page | Slots | FrameXML relationship |
|---:|---:|---|
| 1 | 1–12 | Main page or active bonus/form page |
| 2 | 13–24 | Second main page |
| 3 | 25–36 | Right multibar |
| 4 | 37–48 | Left multibar |
| 5 | 49–60 | Bottom-right multibar |
| 6 | 61–72 | Bottom-left multibar |

Page set A maps none/L1/L2/L1+L2 to pages 1/2/3/4. Page set B maps them to 5/6/3/4. Keeping pages 3 and 4 stable protects learned muscle memory.

## Project binding catalog (99)

| Section | Binding | Player label | Down/up | Fixed operation |
|---|---|---|---|---|
| Essential | `PRP_ACTION1` | Ability 1 / Confirm in menus (RP6: right A) | yes | `PRP_ActionKey(1, keystate);` |
| Essential | `PRP_ACTION2` | Ability 2 / Back in menus (RP6: bottom B) | yes | `PRP_ActionKey(2, keystate);` |
| Essential | `PRP_ACTION3` | Ability 3 / More in menus (RP6: left Y) | yes | `PRP_ActionKey(3, keystate);` |
| Essential | `PRP_ACTION4` | Ability 4 / Quick Menu in panels (RP6: top X) | yes | `PRP_ActionKey(4, keystate);` |
| Essential | `PRP_MOD_SHIFT` | Ability layer 2 (recommended: L1) | yes | `PRP_ActionModifier("shift", keystate);` |
| Essential | `PRP_MOD_CTRL` | Ability layer 3 (recommended: L2) | yes | `PRP_ActionModifier("control", keystate);` |
| Essential | `PRP_MOD_BANK` | Primary ability bank: hold for abilities 5-8 (RP6: R1) | yes | `PRP_ActionModifier("bank", keystate);` |
| Essential | `PRP_NAV_UP` | D-pad up / Ability 9 in world | yes | `PRP_NavKey("UP", keystate);` |
| Essential | `PRP_NAV_DOWN` | D-pad down / Ability 10 in world | yes | `PRP_NavKey("DOWN", keystate);` |
| Essential | `PRP_NAV_LEFT` | D-pad left / Ability 11 in world | yes | `PRP_NavKey("LEFT", keystate);` |
| Essential | `PRP_NAV_RIGHT` | D-pad right / Ability 12 in world | yes | `PRP_NavKey("RIGHT", keystate);` |
| Essential | `PRP_QUICK_MENU` | Open / close Quick Menu (recommended: Start) | yes | `PRP_QuickMenuKey(keystate);` |
| Essential | `PRP_INVENTORY` | Controller inventory / bags | no | `PRP_InventoryKey();` |
| Essential | `PRP_TARGET_NEXT_ENEMY` | Target nearest enemy (RP6: M1; L3 fallback) | no | `PRP_TargetCommand("NEXT_ENEMY");` |
| Advanced | `PRP_ACTION5` | Ability 5 / R1 + primary face | yes | `PRP_ActionKey(5, keystate);` |
| Advanced | `PRP_ACTION6` | Ability 6 / R1 + second face | yes | `PRP_ActionKey(6, keystate);` |
| Advanced | `PRP_ACTION7` | Ability 7 / R1 + third face | yes | `PRP_ActionKey(7, keystate);` |
| Advanced | `PRP_ACTION8` | Ability 8 / R1 + fourth face | yes | `PRP_ActionKey(8, keystate);` |
| Advanced | `PRP_ACTION9` | Ability 9 / D-pad up in world | yes | `PRP_ActionKey(9, keystate);` |
| Advanced | `PRP_ACTION10` | Ability 10 / D-pad down in world | yes | `PRP_ActionKey(10, keystate);` |
| Advanced | `PRP_ACTION11` | Ability 11 / D-pad left in world | yes | `PRP_ActionKey(11, keystate);` |
| Advanced | `PRP_ACTION12` | Ability 12 / D-pad right in world | yes | `PRP_ActionKey(12, keystate);` |
| Advanced | `PRP_MOD_ALT` | Self-cast modifier (optional) | yes | `PRP_ActionModifier("alt", keystate);` |
| Advanced | `PRP_PAGE_SET` | Toggle main / extra action bars | no | `PRP_TogglePageSet();` |
| Advanced | `PRP_COMPANION` | Pet and stance/form panel | no | `PRP_CompanionKey();` |
| Advanced | `PRP_CHAT` | Open chat | no | `PRP_ChatKey(false);` |
| Advanced | `PRP_CHAT_SLASH` | Open slash command | no | `PRP_ChatKey(true);` |
| Advanced | `PRP_TARGET_PREV_ENEMY` | Target previous enemy | no | `PRP_TargetCommand("PREV_ENEMY");` |
| Advanced | `PRP_TARGET_NEXT_FRIEND` | Target nearest friend | no | `PRP_TargetCommand("NEXT_FRIEND");` |
| Advanced | `PRP_TARGET_PREV_FRIEND` | Target previous friend | no | `PRP_TargetCommand("PREV_FRIEND");` |
| Advanced | `PRP_TARGET_GROUP_NEXT` | Target next player, pet, party, or raid unit | no | `PRP_TargetCommand("GROUP_NEXT");` |
| Advanced | `PRP_TARGET_GROUP_PREV` | Target previous player, pet, party, or raid unit | no | `PRP_TargetCommand("GROUP_PREV");` |
| Advanced | `PRP_TARGET_LAST_HOSTILE` | Target last hostile | no | `PRP_TargetCommand("LAST_HOSTILE");` |
| Advanced | `PRP_ASSIST_TARGET` | Assist current target | no | `PRP_TargetCommand("ASSIST");` |
| Advanced | `PRP_TARGET_SELF` | Target self | no | `PRP_TargetCommand("SELF");` |
| Advanced | `PRP_TARGET_PET` | Target pet | no | `PRP_TargetCommand("PET");` |
| Advanced | `PRP_CLEAR_TARGET` | Clear target | no | `PRP_TargetCommand("CLEAR");` |
| Advanced | `PRP_ATTACK_TARGET` | Attack current target | no | `PRP_TargetCommand("ATTACK");` |
| Advanced | `PRP_PET_ATTACK` | Command pet to attack | no | `PRP_TargetCommand("PET_ATTACK");` |
| Advanced | `PRP_FOLLOW_TARGET` | Follow current target | no | `PRP_TargetCommand("FOLLOW");` |
| Advanced | `PRP_RAID_MARK_CLEAR` | Clear raid target icon | no | `PRP_RaidMarker(0);` |
| Advanced | `PRP_RAID_MARK_1` | Set raid target icon: Star | no | `PRP_RaidMarker(1);` |
| Advanced | `PRP_RAID_MARK_2` | Set raid target icon: Circle | no | `PRP_RaidMarker(2);` |
| Advanced | `PRP_RAID_MARK_3` | Set raid target icon: Diamond | no | `PRP_RaidMarker(3);` |
| Advanced | `PRP_RAID_MARK_4` | Set raid target icon: Triangle | no | `PRP_RaidMarker(4);` |
| Advanced | `PRP_RAID_MARK_5` | Set raid target icon: Moon | no | `PRP_RaidMarker(5);` |
| Advanced | `PRP_RAID_MARK_6` | Set raid target icon: Square | no | `PRP_RaidMarker(6);` |
| Advanced | `PRP_RAID_MARK_7` | Set raid target icon: Cross | no | `PRP_RaidMarker(7);` |
| Advanced | `PRP_RAID_MARK_8` | Set raid target icon: Skull | no | `PRP_RaidMarker(8);` |
| Advanced | `PRP_STOCK_PAGE1` | Stock Blizzard action bar: page 1 | no | `PRP_PageCommand("PAGE1");` |
| Advanced | `PRP_STOCK_PAGE2` | Stock Blizzard action bar: page 2 | no | `PRP_PageCommand("PAGE2");` |
| Advanced | `PRP_STOCK_PAGE3` | Stock Blizzard action bar: page 3 | no | `PRP_PageCommand("PAGE3");` |
| Advanced | `PRP_STOCK_PAGE4` | Stock Blizzard action bar: page 4 | no | `PRP_PageCommand("PAGE4");` |
| Advanced | `PRP_STOCK_PAGE5` | Stock Blizzard action bar: page 5 | no | `PRP_PageCommand("PAGE5");` |
| Advanced | `PRP_STOCK_PAGE6` | Stock Blizzard action bar: page 6 | no | `PRP_PageCommand("PAGE6");` |
| Advanced | `PRP_STOCK_PAGE_PREV` | Stock Blizzard action bar: previous page | no | `PRP_PageCommand("PREVIOUS");` |
| Advanced | `PRP_STOCK_PAGE_NEXT` | Stock Blizzard action bar: next page | no | `PRP_PageCommand("NEXT");` |
| Advanced | `PRP_ACTIONBAR_LOCK` | Toggle stock Blizzard action-bar lock | no | `PRP_PageCommand("LOCK");` |
| Advanced | `PRP_AUTO_SELF_CAST` | Toggle Vanilla auto self-cast | no | `PRP_PageCommand("AUTO_SELF_CAST");` |
| Advanced | `PRP_PET_ACTION1` | Pet action 1 | yes | `PRP_PetActionKey(1, keystate);` |
| Advanced | `PRP_PET_ACTION2` | Pet action 2 | yes | `PRP_PetActionKey(2, keystate);` |
| Advanced | `PRP_PET_ACTION3` | Pet action 3 | yes | `PRP_PetActionKey(3, keystate);` |
| Advanced | `PRP_PET_ACTION4` | Pet action 4 | yes | `PRP_PetActionKey(4, keystate);` |
| Advanced | `PRP_PET_ACTION5` | Pet action 5 | yes | `PRP_PetActionKey(5, keystate);` |
| Advanced | `PRP_PET_ACTION6` | Pet action 6 | yes | `PRP_PetActionKey(6, keystate);` |
| Advanced | `PRP_PET_ACTION7` | Pet action 7 | yes | `PRP_PetActionKey(7, keystate);` |
| Advanced | `PRP_PET_ACTION8` | Pet action 8 | yes | `PRP_PetActionKey(8, keystate);` |
| Advanced | `PRP_PET_ACTION9` | Pet action 9 | yes | `PRP_PetActionKey(9, keystate);` |
| Advanced | `PRP_PET_ACTION10` | Pet action 10 | yes | `PRP_PetActionKey(10, keystate);` |
| Advanced | `PRP_FORM_ACTION1` | Stance, form, or stealth position 1 | no | `PRP_FormAction(1);` |
| Advanced | `PRP_FORM_ACTION2` | Stance, form, or stealth position 2 | no | `PRP_FormAction(2);` |
| Advanced | `PRP_FORM_ACTION3` | Stance, form, or stealth position 3 | no | `PRP_FormAction(3);` |
| Advanced | `PRP_FORM_ACTION4` | Stance, form, or stealth position 4 | no | `PRP_FormAction(4);` |
| Advanced | `PRP_FORM_ACTION5` | Stance, form, or stealth position 5 | no | `PRP_FormAction(5);` |
| Advanced | `PRP_FORM_ACTION6` | Stance, form, or stealth position 6 | no | `PRP_FormAction(6);` |
| Advanced | `PRP_FORM_ACTION7` | Stance, form, or stealth position 7 | no | `PRP_FormAction(7);` |
| Advanced | `PRP_FORM_ACTION8` | Stance, form, or stealth position 8 | no | `PRP_FormAction(8);` |
| Advanced | `PRP_FORM_ACTION9` | Stance, form, or stealth position 9 | no | `PRP_FormAction(9);` |
| Advanced | `PRP_FORM_ACTION10` | Stance, form, or stealth position 10 | no | `PRP_FormAction(10);` |
| Advanced | `PRP_CHARACTER` | Character panel | no | `PRP_VanillaHelper("CHARACTER");` |
| Advanced | `PRP_SPELLBOOK` | Spellbook | no | `PRP_VanillaHelper("SPELLBOOK");` |
| Advanced | `PRP_PETBOOK` | Pet spellbook | no | `PRP_VanillaHelper("PETBOOK");` |
| Advanced | `PRP_TALENTS` | Talent panel | no | `PRP_VanillaHelper("TALENTS");` |
| Advanced | `PRP_QUESTS` | Quest log | no | `PRP_VanillaHelper("QUESTS");` |
| Advanced | `PRP_MAP` | World map | no | `PRP_VanillaHelper("MAP");` |
| Advanced | `PRP_GAMEMENU` | Game menu | no | `PRP_VanillaHelper("GAMEMENU");` |
| Advanced | `PRP_SOCIAL` | Social panel | no | `PRP_VanillaHelper("SOCIAL");` |
| Advanced | `PRP_FRIENDS` | Friends tab | no | `PRP_VanillaHelper("FRIENDS");` |
| Advanced | `PRP_WHO` | Who tab | no | `PRP_VanillaHelper("WHO");` |
| Advanced | `PRP_GUILD` | Guild tab | no | `PRP_VanillaHelper("GUILD");` |
| Advanced | `PRP_RAID` | Raid tab | no | `PRP_VanillaHelper("RAID");` |
| Advanced | `PRP_BACKPACK` | Backpack | no | `PRP_VanillaHelper("BACKPACK");` |
| Advanced | `PRP_ALL_BAGS` | Open all bags | no | `PRP_VanillaHelper("ALL_BAGS");` |
| Advanced | `PRP_KEYRING` | Keyring | no | `PRP_VanillaHelper("KEYRING");` |
| Advanced | `PRP_MINIMAP` | Toggle minimap | no | `PRP_VanillaHelper("MINIMAP");` |
| Advanced | `PRP_BATTLEFIELD_MAP` | Toggle battlefield minimap | no | `PRP_VanillaHelper("BATTLEFIELD_MAP");` |
| Advanced | `PRP_WORLD_SCORES` | Toggle world-state scores | no | `PRP_VanillaHelper("WORLD_SCORES");` |
| Advanced | `PRP_NAMEPLATES` | Toggle enemy nameplates | no | `PRP_VanillaHelper("NAMEPLATES");` |
| Advanced | `PRP_SCREENSHOT` | Take screenshot | no | `PRP_VanillaHelper("SCREENSHOT");` |

## Stock binding audit (228)

| # | Stock group | Stock binding | Disposition | Reason |
|---:|---|---|---|---|
| 001 | MOVEMENT | `MOVEANDSTEER` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 002 | MOVEMENT | `MOVEFORWARD` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 003 | MOVEMENT | `MOVEBACKWARD` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 004 | MOVEMENT | `TURNLEFT` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 005 | MOVEMENT | `TURNRIGHT` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 006 | MOVEMENT | `STRAFELEFT` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 007 | MOVEMENT | `STRAFERIGHT` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 008 | MOVEMENT | `JUMP` | **Winlator direct** | Default RP6 profile maps M2 and the optional R3 fallback directly to the stock `JUMP` binding; it is not duplicated by the addon. |
| 009 | MOVEMENT | `SITORSTAND` | **Stock optional** | Useful Vanilla movement utility; bind a spare translated key directly in WoW when desired. |
| 010 | MOVEMENT | `TOGGLESHEATH` | **Stock optional** | Useful Vanilla movement utility; bind a spare translated key directly in WoW when desired. |
| 011 | MOVEMENT | `TOGGLEAUTORUN` | **Stock optional** | Useful Vanilla movement utility; bind a spare translated key directly in WoW when desired. |
| 012 | MOVEMENT | `PITCHUP` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 013 | MOVEMENT | `PITCHDOWN` | **Winlator direct** | Continuous movement/turn/pitch belongs to the physical-input bridge; release-all is mandatory. |
| 014 | MOVEMENT | `TOGGLERUN` | **Stock optional** | Useful Vanilla movement utility; bind a spare translated key directly in WoW when desired. |
| 015 | MOVEMENT | `FOLLOWTARGET` | **PRP semantic** | Covered by PRP_FOLLOW_TARGET using the Vanilla FollowUnit("target") operation. |
| 016 | CHAT | `OPENCHAT` | **PRP semantic** | Covered by PRP_CHAT/PRP_CHAT_SLASH with input release before the normal chat edit box opens. |
| 017 | CHAT | `OPENCHATSLASH` | **PRP semantic** | Covered by PRP_CHAT/PRP_CHAT_SLASH with input release before the normal chat edit box opens. |
| 018 | CHAT | `CHATPAGEUP` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 019 | CHAT | `CHATPAGEDOWN` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 020 | CHAT | `CHATBOTTOM` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 021 | CHAT | `REPLY` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 022 | CHAT | `REPLY2` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 023 | CHAT | `COMBATLOGPAGEUP` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 024 | CHAT | `COMBATLOGPAGEDOWN` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 025 | CHAT | `COMBATLOGBOTTOM` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 026 | CHAT | `TOGGLECOMBATLOG` | **Stock optional** | Retain as a normal WoW binding; it does not require controller-specific Lua semantics. |
| 027 | ACTIONBAR | `ACTIONBUTTON1` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 028 | ACTIONBAR | `ACTIONBUTTON2` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 029 | ACTIONBAR | `ACTIONBUTTON3` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 030 | ACTIONBAR | `ACTIONBUTTON4` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 031 | ACTIONBAR | `ACTIONBUTTON5` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 032 | ACTIONBAR | `ACTIONBUTTON6` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 033 | ACTIONBAR | `ACTIONBUTTON7` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 034 | ACTIONBAR | `ACTIONBUTTON8` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 035 | ACTIONBAR | `ACTIONBUTTON9` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 036 | ACTIONBAR | `ACTIONBUTTON10` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 037 | ACTIONBAR | `ACTIONBUTTON11` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 038 | ACTIONBAR | `ACTIONBUTTON12` | **PRP semantic** | Covered by semantic actions 1-12 with captured slot identity on key-down. |
| 039 | ACTIONBAR | `SELFACTIONBUTTON1` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 040 | ACTIONBAR | `SELFACTIONBUTTON2` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 041 | ACTIONBAR | `SELFACTIONBUTTON3` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 042 | ACTIONBAR | `SELFACTIONBUTTON4` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 043 | ACTIONBAR | `SELFACTIONBUTTON5` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 044 | ACTIONBAR | `SELFACTIONBUTTON6` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 045 | ACTIONBAR | `SELFACTIONBUTTON7` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 046 | ACTIONBAR | `SELFACTIONBUTTON8` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 047 | ACTIONBAR | `SELFACTIONBUTTON9` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 048 | ACTIONBAR | `SELFACTIONBUTTON10` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 049 | ACTIONBAR | `SELFACTIONBUTTON11` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 050 | ACTIONBAR | `SELFACTIONBUTTON12` | **PRP semantic** | Covered by semantic action plus the PRP Alt self-cast modifier; bonus pages intentionally ignore self-cast exactly as Vanilla does. |
| 051 | ACTIONBAR | `SHAPESHIFTBUTTON1` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 052 | ACTIONBAR | `SHAPESHIFTBUTTON2` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 053 | ACTIONBAR | `SHAPESHIFTBUTTON3` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 054 | ACTIONBAR | `SHAPESHIFTBUTTON4` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 055 | ACTIONBAR | `SHAPESHIFTBUTTON5` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 056 | ACTIONBAR | `SHAPESHIFTBUTTON6` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 057 | ACTIONBAR | `SHAPESHIFTBUTTON7` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 058 | ACTIONBAR | `SHAPESHIFTBUTTON8` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 059 | ACTIONBAR | `SHAPESHIFTBUTTON9` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 060 | ACTIONBAR | `SHAPESHIFTBUTTON10` | **PRP semantic** | Covered by PRP_FORM_ACTION1-10 and the companion surface. |
| 061 | ACTIONBAR | `BONUSACTIONBUTTON1` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 062 | ACTIONBAR | `BONUSACTIONBUTTON2` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 063 | ACTIONBAR | `BONUSACTIONBUTTON3` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 064 | ACTIONBAR | `BONUSACTIONBUTTON4` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 065 | ACTIONBAR | `BONUSACTIONBUTTON5` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 066 | ACTIONBAR | `BONUSACTIONBUTTON6` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 067 | ACTIONBAR | `BONUSACTIONBUTTON7` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 068 | ACTIONBAR | `BONUSACTIONBUTTON8` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 069 | ACTIONBAR | `BONUSACTIONBUTTON9` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 070 | ACTIONBAR | `BONUSACTIONBUTTON10` | **PRP semantic** | Covered automatically when the Vanilla bonus bar is visible on semantic page 1. |
| 071 | ACTIONBAR | `ACTIONPAGE1` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 072 | ACTIONBAR | `ACTIONPAGE2` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 073 | ACTIONBAR | `ACTIONPAGE3` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 074 | ACTIONBAR | `ACTIONPAGE4` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 075 | ACTIONBAR | `ACTIONPAGE5` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 076 | ACTIONBAR | `ACTIONPAGE6` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 077 | ACTIONBAR | `PREVIOUSACTIONPAGE` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 078 | ACTIONBAR | `NEXTACTIONPAGE` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 079 | ACTIONBAR | `TOGGLEACTIONBARLOCK` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 080 | ACTIONBAR | `TOGGLEAUTOSELFCAST` | **PRP semantic** | Covered by explicit six-page, previous/next, lock, or auto-self-cast commands. |
| 081 | TARGETING | `TARGETNEARESTENEMY` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 082 | TARGETING | `TARGETPREVIOUSENEMY` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 083 | TARGETING | `TARGETNEARESTFRIEND` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 084 | TARGETING | `TARGETPREVIOUSFRIEND` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 085 | TARGETING | `TARGETSELF` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 086 | TARGETING | `TARGETPARTYMEMBER1` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 087 | TARGETING | `TARGETPARTYMEMBER2` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 088 | TARGETING | `TARGETPARTYMEMBER3` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 089 | TARGETING | `TARGETPARTYMEMBER4` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 090 | TARGETING | `TARGETPET` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 091 | TARGETING | `TARGETPARTYPET1` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 092 | TARGETING | `TARGETPARTYPET2` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 093 | TARGETING | `TARGETPARTYPET3` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 094 | TARGETING | `TARGETPARTYPET4` | **Stock optional** | Exact party-member/pet targeting remains available as a stock binding; PRP also supplies deterministic group cycling. |
| 095 | TARGETING | `TARGETLASTHOSTILE` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 096 | TARGETING | `ASSISTTARGET` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 097 | TARGETING | `NAMEPLATES` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 098 | TARGETING | `FRIENDNAMEPLATES` | **Stock optional** | Useful but not required by the default handheld profile; bind directly through WoW if needed. |
| 099 | TARGETING | `ALLNAMEPLATES` | **Stock optional** | Useful but not required by the default handheld profile; bind directly through WoW if needed. |
| 100 | TARGETING | `ATTACKTARGET` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 101 | TARGETING | `PETATTACK` | **PRP semantic** | Covered by a project binding using the corresponding Vanilla targeting operation. |
| 102 | INTERFACE | `TOGGLECHARACTER0` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 103 | INTERFACE | `TOGGLEBACKPACK` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 104 | INTERFACE | `TOGGLEBAG1` | **Stock optional** | Individual bag windows remain stock; PRP inventory and Open All Bags cover the default controller flow. |
| 105 | INTERFACE | `TOGGLEBAG2` | **Stock optional** | Individual bag windows remain stock; PRP inventory and Open All Bags cover the default controller flow. |
| 106 | INTERFACE | `TOGGLEBAG3` | **Stock optional** | Individual bag windows remain stock; PRP inventory and Open All Bags cover the default controller flow. |
| 107 | INTERFACE | `TOGGLEBAG4` | **Stock optional** | Individual bag windows remain stock; PRP inventory and Open All Bags cover the default controller flow. |
| 108 | INTERFACE | `OPENALLBAGS` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 109 | INTERFACE | `TOGGLEKEYRING` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 110 | INTERFACE | `TOGGLESPELLBOOK` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 111 | INTERFACE | `TOGGLEPETBOOK` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 112 | INTERFACE | `TOGGLETALENTS` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 113 | INTERFACE | `TOGGLECHARACTER4` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 114 | INTERFACE | `TOGGLECHARACTER3` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 115 | INTERFACE | `TOGGLECHARACTER2` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 116 | INTERFACE | `TOGGLECHARACTER1` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 117 | INTERFACE | `TOGGLEQUESTLOG` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 118 | INTERFACE | `TOGGLEGAMEMENU` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 119 | INTERFACE | `TOGGLEMINIMAP` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 120 | INTERFACE | `TOGGLEWORLDMAP` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 121 | INTERFACE | `TOGGLESOCIAL` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 122 | INTERFACE | `TOGGLEFRIENDSTAB` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 123 | INTERFACE | `TOGGLEWHOTAB` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 124 | INTERFACE | `TOGGLEGUILDTAB` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 125 | INTERFACE | `TOGGLERAIDTAB` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 126 | INTERFACE | `TOGGLEWORLDSTATESCORES` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 127 | INTERFACE | `TOGGLEBATTLEFIELDMINIMAP` | **PRP semantic** | Covered by a direct helper, quick-menu entry, companion surface, or controller inventory. |
| 128 | MISC | `MINIMAPZOOMIN` | **Stock optional** | Can be mapped to spare keys or mouse wheel; no semantic addon layer is needed. |
| 129 | MISC | `MINIMAPZOOMOUT` | **Stock optional** | Can be mapped to spare keys or mouse wheel; no semantic addon layer is needed. |
| 130 | MISC | `TOGGLEMUSIC` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 131 | MISC | `TOGGLESOUND` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 132 | MISC | `MASTERVOLUMEUP` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 133 | MISC | `MASTERVOLUMEDOWN` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 134 | MISC | `TOGGLEUI` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 135 | MISC | `TOGGLEFPS` | **Stock optional** | Useful optional client command; keep outside the core controller vocabulary. |
| 136 | MISC | `SCREENSHOT` | **PRP semantic** | Covered by PRP_SCREENSHOT. |
| 137 | MISC | `TOGGLESTATS` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 138 | MISC | `TOGGLETRIS` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 139 | MISC | `TOGGLEPORTALS` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 140 | MISC | `TOGGLECOLLISION` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 141 | MISC | `TOGGLECOLLISIONDISPLAY` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 142 | MISC | `TOGGLEPLAYERBOUNDS` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 143 | MISC | `TOGGLEPERFORMANCEDISPLAY` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 144 | MISC | `TOGGLEPERFORMANCEVALUES` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 145 | MISC | `RESETPERFORMANCEVALUES` | **Developer-only** | Renderer/debug visualization command; omit from normal handheld profiles. |
| 146 | CAMERA | `NEXTVIEW` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 147 | CAMERA | `PREVVIEW` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 148 | CAMERA | `CAMERAZOOMIN` | **Winlator direct** | Map to mouse wheel/relative mouse behavior where possible; retain the stock binding only as a fallback. |
| 149 | CAMERA | `CAMERAZOOMOUT` | **Winlator direct** | Map to mouse wheel/relative mouse behavior where possible; retain the stock binding only as a fallback. |
| 150 | CAMERA | `SETVIEW1` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 151 | CAMERA | `SETVIEW2` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 152 | CAMERA | `SETVIEW3` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 153 | CAMERA | `SETVIEW4` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 154 | CAMERA | `SETVIEW5` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 155 | CAMERA | `SAVEVIEW2` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 156 | CAMERA | `SAVEVIEW3` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 157 | CAMERA | `SAVEVIEW4` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 158 | CAMERA | `SAVEVIEW5` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 159 | CAMERA | `RESETVIEW2` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 160 | CAMERA | `RESETVIEW3` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 161 | CAMERA | `RESETVIEW4` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 162 | CAMERA | `RESETVIEW5` | **Stock optional** | Saved-view functions are valid Vanilla features but low-frequency on a handheld. |
| 163 | CAMERA | `FLIPCAMERAYAW` | **Winlator direct** | Map to mouse wheel/relative mouse behavior where possible; retain the stock binding only as a fallback. |
| 164 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON1` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 165 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON2` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 166 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON3` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 167 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON4` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 168 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON5` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 169 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON6` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 170 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON7` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 171 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON8` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 172 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON9` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 173 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON10` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 174 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON11` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 175 | MULTIACTIONBAR | `MULTIACTIONBAR1BUTTON12` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 176 | BLANK | `MULTIACTIONBAR2BUTTON1` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 177 | BLANK | `MULTIACTIONBAR2BUTTON2` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 178 | BLANK | `MULTIACTIONBAR2BUTTON3` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 179 | BLANK | `MULTIACTIONBAR2BUTTON4` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 180 | BLANK | `MULTIACTIONBAR2BUTTON5` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 181 | BLANK | `MULTIACTIONBAR2BUTTON6` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 182 | BLANK | `MULTIACTIONBAR2BUTTON7` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 183 | BLANK | `MULTIACTIONBAR2BUTTON8` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 184 | BLANK | `MULTIACTIONBAR2BUTTON9` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 185 | BLANK | `MULTIACTIONBAR2BUTTON10` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 186 | BLANK | `MULTIACTIONBAR2BUTTON11` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 187 | BLANK | `MULTIACTIONBAR2BUTTON12` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 188 | BLANK2 | `MULTIACTIONBAR3BUTTON1` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 189 | BLANK2 | `MULTIACTIONBAR3BUTTON2` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 190 | BLANK2 | `MULTIACTIONBAR3BUTTON3` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 191 | BLANK2 | `MULTIACTIONBAR3BUTTON4` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 192 | BLANK2 | `MULTIACTIONBAR3BUTTON5` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 193 | BLANK2 | `MULTIACTIONBAR3BUTTON6` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 194 | BLANK2 | `MULTIACTIONBAR3BUTTON7` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 195 | BLANK2 | `MULTIACTIONBAR3BUTTON8` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 196 | BLANK2 | `MULTIACTIONBAR3BUTTON9` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 197 | BLANK2 | `MULTIACTIONBAR3BUTTON10` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 198 | BLANK2 | `MULTIACTIONBAR3BUTTON11` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 199 | BLANK2 | `MULTIACTIONBAR3BUTTON12` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 200 | BLANK3 | `MULTIACTIONBAR4BUTTON1` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 201 | BLANK3 | `MULTIACTIONBAR4BUTTON2` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 202 | BLANK3 | `MULTIACTIONBAR4BUTTON3` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 203 | BLANK3 | `MULTIACTIONBAR4BUTTON4` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 204 | BLANK3 | `MULTIACTIONBAR4BUTTON5` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 205 | BLANK3 | `MULTIACTIONBAR4BUTTON6` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 206 | BLANK3 | `MULTIACTIONBAR4BUTTON7` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 207 | BLANK3 | `MULTIACTIONBAR4BUTTON8` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 208 | BLANK3 | `MULTIACTIONBAR4BUTTON9` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 209 | BLANK3 | `MULTIACTIONBAR4BUTTON10` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 210 | BLANK3 | `MULTIACTIONBAR4BUTTON11` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 211 | BLANK3 | `MULTIACTIONBAR4BUTTON12` | **PRP semantic** | These 48 visible multibar actions are ordinary slots on pages 3-6 and are covered by the six-page action model. |
| 212 | RAID_TARGET | `RAIDTARGET1` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 213 | RAID_TARGET | `RAIDTARGET2` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 214 | RAID_TARGET | `RAIDTARGET3` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 215 | RAID_TARGET | `RAIDTARGET4` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 216 | RAID_TARGET | `RAIDTARGET5` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 217 | RAID_TARGET | `RAIDTARGET6` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 218 | RAID_TARGET | `RAIDTARGET7` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 219 | RAID_TARGET | `RAIDTARGET8` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 220 | RAID_TARGET | `RAIDTARGETNONE` | **PRP semantic** | Covered by clear plus raid-target icons 1-8. |
| 221 | RAID_TARGET | `TURNORACTION` | **Winlator direct** | Hidden mouse/steering composite; the compatibility layer owns pointer and camera behavior. |
| 222 | RAID_TARGET | `CAMERAORSELECTORMOVE` | **Winlator direct** | Hidden mouse/steering composite; the compatibility layer owns pointer and camera behavior. |
| 223 | RAID_TARGET | `CAMERAORSELECTORMOVESTICKY` | **Winlator direct** | Hidden mouse/steering composite; the compatibility layer owns pointer and camera behavior. |
| 224 | ITUNES_REMOTE | `ITUNES_PLAYPAUSE` | **Omitted** | Legacy desktop iTunes integration is irrelevant to an Android local-realm handheld. |
| 225 | ITUNES_REMOTE | `ITUNES_NEXTTRACK` | **Omitted** | Legacy desktop iTunes integration is irrelevant to an Android local-realm handheld. |
| 226 | ITUNES_REMOTE | `ITUNES_BACKTRACK` | **Omitted** | Legacy desktop iTunes integration is irrelevant to an Android local-realm handheld. |
| 227 | ITUNES_REMOTE | `ITUNES_VOLUMEUP` | **Omitted** | Legacy desktop iTunes integration is irrelevant to an Android local-realm handheld. |
| 228 | ITUNES_REMOTE | `ITUNES_VOLUMEDOWN` | **Omitted** | Legacy desktop iTunes integration is irrelevant to an Android local-realm handheld. |

## Vanilla-only feature conclusions

- `JUMP` is a direct M2 stock binding with R3 as an optional duplicate.
- `TOGGLEAUTORUN` is valid but optional Advanced.
- There is no universal Interact-with-target binding; pointer right-click is required.
- All six ordinary action pages matter; a 48-slot design is incomplete.
- Bonus action substitution applies only while semantic page 1 is active.
- Pet and form actions are not ordinary slots 73+.
- The original client has no vehicles, extra action button, pet battles, collections, transmog, dungeon finder, retail soft targeting, or native controller API.
- iTunes remote bindings are platform-irrelevant and omitted.

## Panel coverage and touch exclusions

Pocket Realm Pad covers 23 explicit panel families plus dynamic static popups. It deliberately leaves ambiguous, drag-heavy, text-heavy, or irreversible operations to touch. The detailed safety matrix is:

| Workflow | Controller behavior | Touch role |
|---|---|---|
| Quest completion | Right A twice within 4 seconds | Select reward precisely when needed. |
| Merchant buy/buyback/repair | Right A twice within 4 seconds | Item inspection, stack counts, and unusual purchases. |
| Trainer purchase | Right A twice within 4 seconds | Review cost/details before confirming. |
| Craft/Create All | Right A twice within 4 seconds | Set quantity and inspect reagents. |
| Player trade accept | Right A twice within 4 seconds | Touch adds items and money; controller only commits/cancels. |
| Send mail | Right A twice within 4 seconds | Touch/IME enters recipient, subject, body, money, and package. |
| Auction bid/buyout/create | Right A twice within 4 seconds | Touch handles search fields, prices, stacks, and canceling auctions. |
| Taxi flight | Right A twice within 4 seconds | Touch remains available for map precision. |
| Static popup | One right-A press on Blizzard popup | The popup itself is the second explicit confirmation. |

## Qualification boundary

The catalog is mechanically consistent with `Bindings.xml` and generated tests. Exact execution and frame names still require the actual build-5875 client. Locale-specific layouts and third-party addon panels are not guaranteed.
