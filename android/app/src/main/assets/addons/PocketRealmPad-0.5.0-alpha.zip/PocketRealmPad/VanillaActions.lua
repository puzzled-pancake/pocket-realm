-- Explicit WoW 1.12.1 helpers. Each command is a fixed allowlisted operation
-- mirrored from the stock 1.12 Bindings.xml behavior.

PRP_VanillaActions = {
    petHeld = {},
}

function PRP_VanillaActions:SetPage(page)
    page = tonumber(page)
    if not page or page < 1 or page > 6 then
        return false
    end
    if CURRENT_ACTIONBAR_PAGE ~= page then
        CURRENT_ACTIONBAR_PAGE = page
        if ChangeActionBarPage then
            ChangeActionBarPage()
        end
    end
    if PRP_ActionBar then
        PRP_ActionBar:UpdateAll(true)
    end
    return true
end

function PRP_VanillaActions:PageCommand(command)
    local page
    if PRP_ChatEditActive() then return false end
    if string.sub(command, 1, 4) == "PAGE" then
        page = tonumber(string.sub(command, 5))
        return self:SetPage(page)
    elseif command == "PREVIOUS" then
        if ActionBar_PageDown then
            ActionBar_PageDown()
            return true
        end
    elseif command == "NEXT" then
        if ActionBar_PageUp then
            ActionBar_PageUp()
            return true
        end
    elseif command == "LOCK" then
        if LOCK_ACTIONBAR == "1" then
            LOCK_ACTIONBAR = "0"
            if PRP_UI then PRP_UI:ShowToast("Blizzard action bar unlocked", 1.4) end
        else
            LOCK_ACTIONBAR = "1"
            if PRP_UI then PRP_UI:ShowToast("Blizzard action bar locked", 1.4) end
        end
        return true
    elseif command == "AUTO_SELF_CAST" then
        if GetCVar and SetCVar then
            if GetCVar("autoSelfCast") == "1" then
                SetCVar("autoSelfCast", "0")
                if PRP_UI then PRP_UI:ShowToast("Auto self cast off", 1.4) end
            else
                SetCVar("autoSelfCast", "1")
                if PRP_UI then PRP_UI:ShowToast("Auto self cast on", 1.4) end
            end
            return true
        end
    end
    return false
end

function PRP_VanillaActions:PetKey(index, state)
    index = tonumber(index)
    if not index or index < 1 or index > 10 or not PRP:IsEnabled() or PRP_ChatEditActive() then
        return
    end
    if state == "down" then
        self.petHeld[index] = 1
        if PRP_Companion then PRP_Companion:SetPetPressed(index, true) end
        return
    end
    if self.petHeld[index] ~= 1 then
        return
    end
    self.petHeld[index] = nil
    if PRP_Companion then PRP_Companion:SetPetPressed(index, false) end
    if CastPetAction then
        CastPetAction(index)
    end
end

function PRP_VanillaActions:Form(index)
    index = tonumber(index)
    if not index or index < 1 or index > 10 or not PRP:IsEnabled() or PRP_ChatEditActive() then
        return false
    end
    if ShapeshiftBar_ChangeForm then
        ShapeshiftBar_ChangeForm(index)
        return true
    elseif CastShapeshiftForm then
        CastShapeshiftForm(index)
        return true
    end
    return false
end

function PRP_VanillaActions:RaidMarker(index)
    index = tonumber(index)
    if PRP_ChatEditActive() then return false end
    if not index or index < 0 or index > 8 then
        return false
    end
    if index == 0 then
        if SetRaidTarget then
            SetRaidTarget("target", 0)
            return true
        end
    elseif SetRaidTargetIcon then
        SetRaidTargetIcon("target", index)
        return true
    end
    return false
end

function PRP_VanillaActions:Helper(command)
    if PRP_ChatEditActive() then return false end
    if command == "CHARACTER" then
        if ToggleCharacter then ToggleCharacter("PaperDollFrame") return true end
    elseif command == "SPELLBOOK" then
        if ToggleSpellBook then ToggleSpellBook(BOOKTYPE_SPELL) return true end
    elseif command == "PETBOOK" then
        if ToggleSpellBook then ToggleSpellBook(BOOKTYPE_PET) return true end
    elseif command == "TALENTS" then
        if ToggleTalentFrame then ToggleTalentFrame() return true end
    elseif command == "QUESTS" then
        if ToggleQuestLog then ToggleQuestLog() return true end
    elseif command == "MAP" then
        if ToggleWorldMap then ToggleWorldMap() return true end
    elseif command == "GAMEMENU" then
        if ToggleGameMenu then ToggleGameMenu() return true end
    elseif command == "SOCIAL" then
        if ToggleFriendsFrame then ToggleFriendsFrame() return true end
    elseif command == "FRIENDS" then
        if ToggleFriendsFrame then ToggleFriendsFrame(1) return true end
    elseif command == "WHO" then
        if ToggleFriendsFrame then ToggleFriendsFrame(2) return true end
    elseif command == "GUILD" then
        if ToggleFriendsFrame then ToggleFriendsFrame(3) return true end
    elseif command == "RAID" then
        if ToggleFriendsFrame then ToggleFriendsFrame(4) return true end
    elseif command == "BACKPACK" then
        if ToggleBackpack then ToggleBackpack() return true end
    elseif command == "ALL_BAGS" then
        if OpenAllBags then OpenAllBags() return true end
    elseif command == "KEYRING" then
        if ToggleKeyRing then ToggleKeyRing() return true end
    elseif command == "MINIMAP" then
        if ToggleMinimap then ToggleMinimap() return true end
    elseif command == "BATTLEFIELD_MAP" then
        if ToggleBattlefieldMinimap then ToggleBattlefieldMinimap() return true end
    elseif command == "WORLD_SCORES" then
        if ToggleWorldStateScoreFrame then ToggleWorldStateScoreFrame() return true end
    elseif command == "NAMEPLATES" then
        if NAMEPLATES_ON and not FRIENDNAMEPLATES_ON then
            if HideNameplates then HideNameplates() end
            NAMEPLATES_ON = nil
        else
            if ShowNameplates then ShowNameplates() end
            NAMEPLATES_ON = 1
            if HideFriendNameplates then HideFriendNameplates() end
            FRIENDNAMEPLATES_ON = nil
        end
        return true
    elseif command == "SCREENSHOT" then
        if TakeScreenshot then TakeScreenshot() return true end
    end
    return false
end

function PRP_VanillaActions:ReleaseAll()
    local index
    for index = 1, 10 do
        self.petHeld[index] = nil
        if PRP_Companion then PRP_Companion:SetPetPressed(index, false) end
    end
end

function PRP_PageCommand(command)
    if PRP_VanillaActions then
        PRP_VanillaActions:PageCommand(command)
    end
end

function PRP_PetActionKey(index, state)
    if PRP_VanillaActions then
        PRP_VanillaActions:PetKey(index, state)
    end
end

function PRP_FormAction(index)
    if PRP_VanillaActions then
        PRP_VanillaActions:Form(index)
    end
end

function PRP_RaidMarker(index)
    if PRP_VanillaActions then
        PRP_VanillaActions:RaidMarker(index)
    end
end

function PRP_VanillaHelper(command)
    if PRP_VanillaActions then
        PRP_VanillaActions:Helper(command)
    end
end
