# Winlator controller profile — Pocket Realm Pad 0.5 / RP6 Stick Top

## Ownership

Winlator/Android owns the physical controller, axes, dead zones, mouse, touch transform, focus, reconnect, Android IME, and release-all. Pocket Realm Pad receives keyboard binding events and supplies only WoW semantics and UI.

## Position-first calibration

The RP6 uses printed Nintendo-style labels. Android/firmware may report Xbox-style key names or apply A/B and X/Y swaps. Configure by **physical position**, then display the printed label:

| Position | Printed RP6 label | PRP semantic key |
|---|---|---|
| Right face | A | Ability 1 / Confirm |
| Bottom face | B | Ability 2 / Back |
| Left face | Y | Ability 3 / More |
| Top face | X | Ability 4 / panel Quick Menu |

Do not bind by raw letter without completing the four-position test.

## Recommended mappings

```text
right A           -> PRP_ACTION1
bottom B          -> PRP_ACTION2
left Y            -> PRP_ACTION3
top X             -> PRP_ACTION4
R1                -> PRP_MOD_BANK
L1                -> PRP_MOD_SHIFT
L2                -> PRP_MOD_CTRL
D-pad U/D/L/R     -> PRP_NAV_UP/DOWN/LEFT/RIGHT
Start             -> PRP_QUICK_MENU
Select            -> PRP_INVENTORY
M1                -> PRP_TARGET_NEXT_ENEMY
L3                -> PRP_TARGET_NEXT_ENEMY  (fallback/duplicate)
M2                -> stock JUMP
R3                -> stock JUMP              (fallback/duplicate)
R2                -> Wine right mouse button
left stick        -> W/S and A/D strafe key states
right stick       -> relative mouse camera movement
```

R1 + the four face positions becomes abilities 5–8 inside the addon. D-pad U/D/L/R becomes abilities 9–12 in the world and focus navigation in menus.

## Rear-button policy

M1/M2 are optional convenience controls. They are limited to Target Nearest Enemy and Jump because those are safe, reversible taps. Never assign a rear paddle to:

- an ability layer or held modifier;
- item use;
- Confirm;
- mail/trade/auction commit;
- purchase or repair;
- Delete, abandon, logout, or quit.

The setup screen should provide **Default (M1 target/M2 jump)**, **Swap M1/M2**, and **Rear buttons off**. L3/R3 always remain target/jump fallbacks. When swapped, the launcher also updates the printed labels in the managed addon profile before starting WoW.

## Analogue calibration starting points

These are initial values for the physical setup wizard and must be replaced by measured per-device results:

```text
left stick radial dead zone:   12–18%, lowest value with zero drift
right stick radial dead zone:  10–16%, separately tuned camera sensitivity
L2 layer press:                30% on / 20% off
R2 right-click:                40% on / 25% off
```

Display live axis values during setup. A trigger must emit exactly one down transition crossing the on threshold and one up transition crossing the lower off threshold. Axis noise must never generate repeated layer or mouse presses.

## Key-down/key-up requirements

The 31 `runOnUp` commands must deliver both transitions. Pocket Realm Pad captures action semantic, layer, page, slot, bonus state, and R1 bank state on key-down. Releasing R1/L1/L2 before the face button must not alter the pending action.

Release every logically held key/button on:

- activity pause or focus loss;
- IME opening;
- controller disconnect;
- profile switch;
- overlay restart;
- Wine/client exit;
- Android task interruption.

## Pointer and touch

R2 is right mouse at the current pointer, not Interact-with-target. Touch must transform through the same virtual-desktop/letterbox matrix as the visible surface. A drag beginning on a touch UI control must not become camera motion after leaving it.

## Collision check

Before launch, reject a profile when one synthetic key is assigned to two conflicting commands, or when a PRP semantic key is also assigned to a stock WoW action. M1/L3 and M2/R3 are intentional physical duplicates that must generate the same single semantic key, not two simultaneous keys.
