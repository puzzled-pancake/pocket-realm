-- Host-side behavioral smoke test for the subset of the WoW 1.12.1 UI API
-- used by Pocket Realm Pad. This is not an actual build-5875 client proof.

math.mod = math.fmod
table.getn = function(value) return #value end
unpack = table.unpack

local failures = 0
local assertions = 0
local function check(condition, message)
    assertions = assertions + 1
    if not condition then
        failures = failures + 1
        io.stderr:write("ASSERT FAIL: " .. tostring(message) .. "\n")
    end
end
local function equal(actual, expected, message)
    check(actual == expected, tostring(message) .. " (expected " .. tostring(expected) .. ", got " .. tostring(actual) .. ")")
end

local registry = {}
local objectMethods = {}
local objectMeta = { __index = objectMethods }
local fontSizes = {
    GameFontNormalSmall = 10,
    GameFontNormal = 12,
    GameFontNormalLarge = 16,
    GameFontHighlightSmall = 10,
    GameFontHighlightSmallOutline = 10,
    GameFontHighlight = 12,
    NumberFontNormalSmallGray = 10,
    NumberFontNormal = 12,
}

local function newObject(name, parent, template)
    local obj = setmetatable({
        name = name,
        parent = parent,
        shown = true,
        enabled = true,
        scripts = {},
        events = {},
        x = 0,
        y = 0,
        width = 40,
        height = 40,
        frameLevel = 1,
        text = "",
        value = 0,
        minValue = 0,
        maxValue = 100,
        fontPath = "Fonts\\FRIZQT__.TTF",
        fontSize = fontSizes[template] or 12,
        fontFlags = "",
        template = template,
    }, objectMeta)
    if name then
        registry[name] = obj
        _G[name] = obj
    end
    return obj
end

function objectMethods:GetName() return self.name end
function objectMethods:GetParent() return self.parent end
function objectMethods:SetParent(parent) self.parent = parent end
function objectMethods:SetWidth(value) self.width = value end
function objectMethods:SetHeight(value) self.height = value end
function objectMethods:GetWidth() return self.width end
function objectMethods:GetHeight() return self.height end
function objectMethods:SetFrameStrata(value) self.strata = value end
function objectMethods:SetFrameLevel(value) self.frameLevel = value end
function objectMethods:GetFrameLevel() return self.frameLevel end
function objectMethods:SetBackdrop(value) self.backdrop = value end
function objectMethods:SetBackdropColor(...) self.backdropColor = {...} end
function objectMethods:SetScale(value) self.scale = value end
function objectMethods:GetScale() return self.scale or 1 end
function objectMethods:SetAlpha(value) self.alpha = value end
function objectMethods:GetAlpha() return self.alpha or 1 end
function objectMethods:EnableMouse(value) self.mouse = value end
function objectMethods:SetMovable(value) self.movable = value end
function objectMethods:RegisterForDrag(...) self.drag = {...} end
function objectMethods:RegisterForClicks(...) self.clicks = {...} end
function objectMethods:RegisterEvent(value) self.events[value] = true end
function objectMethods:UnregisterEvent(value) self.events[value] = nil end
function objectMethods:SetScript(kind, fn) self.scripts[kind] = fn end
function objectMethods:GetScript(kind) return self.scripts[kind] end
function objectMethods:SetPoint(point, relative, relativePoint, x, y)
    self.point = point
    self.relative = relative
    self.relativePoint = relativePoint
    self.x = x or 0
    self.y = y or 0
end
function objectMethods:GetPoint(index)
    return self.point or "CENTER", self.relative, self.relativePoint or "CENTER", self.x or 0, self.y or 0
end
function objectMethods:ClearAllPoints()
    self.point = nil
    self.relative = nil
    self.relativePoint = nil
    self.x = 0
    self.y = 0
end
function objectMethods:SetAllPoints(relative) self.relative = relative or self.parent end
function objectMethods:GetCenter()
    if self.centerX and self.centerY then return self.centerX, self.centerY end
    local px = 640
    local py = 360
    if self.relative and self.relative ~= self and self.relative.GetCenter then
        px, py = self.relative:GetCenter()
    end
    return px + (self.x or 0), py + (self.y or 0)
end
function objectMethods:Show() self.shown = true end
function objectMethods:Hide() self.shown = false end
function objectMethods:IsShown() return self.shown end
function objectMethods:IsVisible() return self.shown end
function objectMethods:IsEnabled() return self.enabled end
function objectMethods:SetEnabled(value) self.enabled = value and true or false end
function objectMethods:StartMoving() self.moving = true end
function objectMethods:StopMovingOrSizing() self.moving = false end
function objectMethods:SetNormalTexture(value)
    self.normalTexturePath = value
    if not self.normalTexture then self.normalTexture = newObject(nil, self) end
end
function objectMethods:GetNormalTexture()
    if not self.normalTexture then self.normalTexture = newObject(nil, self) end
    return self.normalTexture
end
function objectMethods:SetPushedTexture(value) self.pushedTexture = value end
function objectMethods:SetHighlightTexture(value, mode) self.highlightTexture = value end
function objectMethods:SetCheckedTexture(value, mode) self.checkedTexture = value end
function objectMethods:SetChecked(value) self.checked = value end
function objectMethods:SetButtonState(value) self.buttonState = value end
function objectMethods:GetButtonState() return self.buttonState or "NORMAL" end
function objectMethods:CreateTexture(name, layer) return newObject(name, self) end
function objectMethods:CreateFontString(name, layer, template) return newObject(name, self, template) end
function objectMethods:SetTexture(value) self.texture = value end
function objectMethods:SetVertexColor(...) self.vertex = {...} end
function objectMethods:SetBlendMode(value) self.blend = value end
function objectMethods:SetText(value) self.text = tostring(value or "") end
function objectMethods:GetText() return self.text end
function objectMethods:SetTextColor(...) self.textColor = {...} end
function objectMethods:SetJustifyH(value) self.justifyH = value end
function objectMethods:SetJustifyV(value) self.justifyV = value end
function objectMethods:GetFont() return self.fontPath, self.fontSize, self.fontFlags end
function objectMethods:SetFont(path, size, flags) self.fontPath = path; self.fontSize = size; self.fontFlags = flags end
function objectMethods:SetStatusBarTexture(value) self.statusTexture = value end
function objectMethods:SetStatusBarColor(...) self.statusColor = {...} end
function objectMethods:SetMinMaxValues(minimum, maximum) self.minValue = minimum; self.maxValue = maximum end
function objectMethods:GetMinMaxValues() return self.minValue, self.maxValue end
function objectMethods:SetValue(value) self.value = value end
function objectMethods:GetValue() return self.value end
function objectMethods:SetOwner(owner, anchor) self.owner = owner; self.anchor = anchor end
function objectMethods:SetAction(slot) self.tooltipAction = slot; return true end
function objectMethods:SetBagItem(bag, slot) self.tooltipBag = bag; self.tooltipSlot = slot end
function objectMethods:SetPetAction(index) self.tooltipPet = index end
function objectMethods:IsOwned(owner) return self.owner == owner end
function objectMethods:SetID(id) self.id = id end
function objectMethods:GetID() return self.id or 0 end
function objectMethods:SetDesaturated(value) self.desaturated = value end

function CreateFrame(frameType, name, parent, template)
    local frame = newObject(name, parent, template)
    frame.frameType = frameType
    frame.frameTemplate = template
    return frame
end
function getglobal(name) return registry[name] or _G[name] end

local screenWidth = 1280
local screenHeight = 720
function GetScreenWidth() return screenWidth end
function GetScreenHeight() return screenHeight end

UIParent = newObject("UIParent", nil)
UIParent.width = screenWidth
UIParent.height = screenHeight
UIParent.centerX = screenWidth / 2
UIParent.centerY = screenHeight / 2
DEFAULT_CHAT_FRAME = { AddMessage = function(self, text) self.last = text end }
GameTooltip = newObject("GameTooltip", UIParent)
GameTooltip.shown = false
ChatFrameEditBox = newObject("ChatFrameEditBox", UIParent)
ChatFrameEditBox.shown = false
BonusActionBarFrame = newObject("BonusActionBarFrame", UIParent)
BonusActionBarFrame.shown = false
BonusActionBarFrame.lastBonusBar = 0
MerchantFrame = newObject("MerchantFrame", UIParent)
MerchantFrame.shown = false

-- Known Blizzard panels are absent/hidden unless a test opens one.
local panelNames = {
    "QuestFrame", "GossipFrame", "LootFrame", "BankFrame", "ClassTrainerFrame",
    "CraftFrame", "TradeSkillFrame", "TradeFrame", "OpenMailFrame", "SendMailFrame",
    "InboxFrame", "AuctionFrame", "BidFrame", "AuctionsFrame", "TaxiFrame",
    "TalentFrame", "GameMenuFrame", "SpellBookFrame", "CharacterFrame",
    "QuestLogFrame", "FriendsFrame", "WorldMapFrame",
}
for _, name in ipairs(panelNames) do local frame = newObject(name, UIParent); frame.shown = false end
for i = 1, 4 do local frame = newObject("StaticPopup" .. i, UIParent); frame.shown = false end

SlashCmdList = {}
ITEM_QUALITY_COLORS = {
    [0] = {r=0.6,g=0.6,b=0.6}, [1] = {r=1,g=1,b=1}, [2] = {r=0.1,g=1,b=0.1},
    [3] = {r=0.1,g=0.5,b=1}, [4] = {r=0.64,g=0.21,b=0.93},
}
FACTION_BAR_COLORS = { [5] = {r=0.1,g=1,b=0.1}, [2] = {r=1,g=0.1,b=0.1} }
BOOKTYPE_SPELL = "spell"
BOOKTYPE_PET = "pet"
CURRENT_ACTIONBAR_PAGE = 1
NUM_ACTIONBAR_PAGES = 6
NUM_ACTIONBAR_BUTTONS = 12
LOCK_ACTIONBAR = "1"
NAMEPLATES_ON = nil
FRIENDNAMEPLATES_ON = nil

local mockTime = 100
function GetTime() return mockTime end
local function advance(value) mockTime = mockTime + value end

local shiftDown = false
local controlDown = false
local altDown = false
function IsShiftKeyDown() return shiftDown end
function IsControlKeyDown() return controlDown end
function IsAltKeyDown() return altDown end
local bonusOffset = 0
function GetBonusBarOffset() return bonusOffset end

local usedActions = {}
function GetActionTexture(slot) if slot >= 1 and slot <= 120 then return "Texture" .. slot end return nil end
function GetActionCount(slot) return slot == 1 and 5 or 0 end
function GetActionCooldown(slot) return 0, 0, 1 end
function IsConsumableAction(slot) return slot == 1 end
function IsUsableAction(slot) return true, false end
function IsCurrentAction(slot) return false end
function IsAutoRepeatAction(slot) return false end
function IsEquippedAction(slot) return false end
function ActionHasRange(slot) return false end
function IsActionInRange(slot) return 1 end
function HasAction(slot) return slot >= 1 and slot <= 120 end
function UseAction(slot, cursor, selfCast) usedActions[#usedActions + 1] = {slot=slot,selfCast=selfCast} end
function MacroFrame_SaveMacro() end
function CooldownFrame_SetTimer(frame, start, duration, enable) frame.cooldown = {start,duration,enable}; frame:Show() end
function GetBindingKey(name) return nil, nil end
function GetBindingText(key, prefix, abbreviate) return key end
function PlaySound(name) end

local pageChanges = 0
function ChangeActionBarPage() pageChanges = pageChanges + 1 end
function ActionBar_PageUp()
    CURRENT_ACTIONBAR_PAGE = CURRENT_ACTIONBAR_PAGE + 1
    if CURRENT_ACTIONBAR_PAGE > 6 then CURRENT_ACTIONBAR_PAGE = 1 end
    ChangeActionBarPage()
end
function ActionBar_PageDown()
    CURRENT_ACTIONBAR_PAGE = CURRENT_ACTIONBAR_PAGE - 1
    if CURRENT_ACTIONBAR_PAGE < 1 then CURRENT_ACTIONBAR_PAGE = 6 end
    ChangeActionBarPage()
end
local cvars = { autoSelfCast = "0" }
function GetCVar(name) return cvars[name] or "0" end
function SetCVar(name, value) cvars[name] = tostring(value) end

local container = {
    [0] = {
        [1] = {texture="ItemA", count=2, quality=2, link="|cff1eff00|Hitem:1|h[Item A]|h|r"},
        [2] = {texture="ItemB", count=1, quality=1, link="|cffffffff|Hitem:2|h[Item B]|h|r"},
        [3] = false,
        [4] = false,
    },
    [1] = { [1] = false, [2] = false },
    [2] = {}, [3] = {}, [4] = {},
}
local containerUses = {}
local containerPickups = {}
local cursorHasItem = false
function GetContainerNumSlots(bag) if bag == 0 then return 4 elseif bag == 1 then return 2 end return 0 end
function GetContainerItemInfo(bag, slot)
    local item = container[bag] and container[bag][slot]
    if not item then return nil, 0, nil, nil, nil end
    return item.texture, item.count, nil, item.quality, nil
end
function GetContainerItemLink(bag, slot)
    local item = container[bag] and container[bag][slot]
    return item and item.link or nil
end
function UseContainerItem(bag, slot) containerUses[#containerUses + 1] = tostring(bag) .. ":" .. tostring(slot) end
function PickupContainerItem(bag, slot) containerPickups[#containerPickups + 1] = tostring(bag) .. ":" .. tostring(slot) end
function CursorHasItem() return cursorHasItem end

local units = {
    player = {name="Player", health=100, max=100, reaction=5, level=60},
    pet = {name="Pet", health=90, max=100, reaction=5, level=60},
    party1 = {name="Party One", health=80, max=100, reaction=5, level=55},
    partypet1 = {name="Party Pet", health=75, max=100, reaction=5, level=55},
    enemy = {name="Enemy", health=50, max=100, reaction=2, level=-1},
    friend = {name="Friend", health=70, max=100, reaction=5, level=40},
}
local targetUnitName = nil
local targetingLog = {}
function UnitExists(unit) return unit == "target" and targetUnitName ~= nil or units[unit] ~= nil end
local function resolveUnit(unit) if unit == "target" then return targetUnitName and units[targetUnitName] or nil end return units[unit] end
function UnitName(unit) local data = resolveUnit(unit); return data and data.name or nil end
function UnitHealth(unit) local data = resolveUnit(unit); return data and data.health or 0 end
function UnitHealthMax(unit) local data = resolveUnit(unit); return data and data.max or 1 end
function UnitLevel(unit) local data = resolveUnit(unit); return data and data.level or 0 end
function UnitClassification(unit) return unit == "target" and targetUnitName == "enemy" and "elite" or "normal" end
function UnitReaction(a, b) local data = resolveUnit(b); return data and data.reaction or 5 end
function UnitCanAttack(a, b) return b == "target" and targetUnitName == "enemy" end
function UnitIsFriend(a, b) return not UnitCanAttack(a, b) end
function UnitIsDead(unit) return false end
function UnitIsUnit(a, b)
    local aa = a == "target" and targetUnitName or a
    local bb = b == "target" and targetUnitName or b
    return aa == bb
end
function GetNumRaidMembers() return 0 end
function TargetUnit(unit) targetUnitName = unit; targetingLog[#targetingLog + 1] = "target:" .. tostring(unit) end
function TargetNearestEnemy(reverse) targetUnitName = "enemy"; targetingLog[#targetingLog + 1] = reverse and "enemy-prev" or "enemy-next" end
function TargetNearestFriend(reverse) targetUnitName = "friend"; targetingLog[#targetingLog + 1] = reverse and "friend-prev" or "friend-next" end
function TargetLastEnemy() targetUnitName = "enemy"; targetingLog[#targetingLog + 1] = "last-enemy" end
function AssistUnit(unit) targetingLog[#targetingLog + 1] = "assist:" .. tostring(unit) end
function ClearTarget() targetUnitName = nil; targetingLog[#targetingLog + 1] = "clear" end
function AttackTarget() targetingLog[#targetingLog + 1] = "attack" end
function PetAttack() targetingLog[#targetingLog + 1] = "pet-attack" end
function FollowUnit(unit) targetingLog[#targetingLog + 1] = "follow:" .. tostring(unit) end

local petActions = {}
for i = 1, 3 do petActions[i] = {name="Pet Skill " .. i, texture="PetTexture" .. i, active=i==2, autoAllowed=true, autoEnabled=i==3} end
local petCasts = {}
local petAutoToggles = {}
function GetPetActionInfo(index)
    local data = petActions[index]
    if not data then return nil end
    return data.name, "", data.texture, nil, data.active, data.autoAllowed, data.autoEnabled
end
function GetPetActionCooldown(index) return 0, 0, 1 end
function CastPetAction(index) petCasts[#petCasts + 1] = index end
function TogglePetAutocast(index) petAutoToggles[#petAutoToggles + 1] = index; petActions[index].autoEnabled = not petActions[index].autoEnabled end
local formCasts = {}
function GetNumShapeshiftForms() return 2 end
function GetShapeshiftFormInfo(index)
    if index == 1 then return "FormTexture1", "Bear Form", false, true end
    if index == 2 then return "FormTexture2", "Cat Form", true, true end
    return nil
end
function GetShapeshiftFormCooldown(index) return 0, 0, 1 end
function ShapeshiftBar_ChangeForm(index) formCasts[#formCasts + 1] = index end

local raidMarks = {}
function SetRaidTargetIcon(unit, index) raidMarks[#raidMarks + 1] = tostring(unit) .. ":" .. tostring(index) end
function SetRaidTarget(unit, index) raidMarks[#raidMarks + 1] = tostring(unit) .. ":" .. tostring(index) end

local toggles = {}
local function logToggle(value) toggles[#toggles + 1] = value end
function ToggleCharacter(name) logToggle("character:" .. tostring(name)) end
function ToggleSpellBook(name) logToggle("spellbook:" .. tostring(name)) end
function ToggleTalentFrame() logToggle("talents") end
function ToggleQuestLog() logToggle("quests") end
function ToggleWorldMap() logToggle("map") end
function ToggleGameMenu() logToggle("menu") end
function ToggleFriendsFrame(tab) logToggle("social:" .. tostring(tab or "default")) end
function ToggleBackpack() logToggle("backpack") end
function OpenAllBags() logToggle("all-bags") end
function ToggleKeyRing() logToggle("keyring") end
function ToggleMinimap() logToggle("minimap") end
function ToggleBattlefieldMinimap() logToggle("battlefield-map") end
function ToggleWorldStateScoreFrame() logToggle("world-scores") end
function ShowNameplates() logToggle("show-nameplates") end
function HideNameplates() logToggle("hide-nameplates") end
function ShowFriendNameplates() logToggle("show-friend-nameplates") end
function HideFriendNameplates() logToggle("hide-friend-nameplates") end
function TakeScreenshot() logToggle("screenshot") end
function ChatFrame_OpenChat(text) logToggle("chat:" .. tostring(text)); ChatFrameEditBox.shown = true end

-- Minimal quest-log and taxi APIs used by the explicit Vanilla adapters.
local questWatchSet = {}
local selectedQuestLogIndex = 0
local questTitles = {
    [1] = {title="Starter Zone", header=true, objectives=0},
    [2] = {title="A Real Quest", header=false, objectives=1},
    [3] = {title="No Objectives", header=false, objectives=0},
}
QUEST_WATCH_LIST = {}
QUEST_WATCH_NO_EXPIRE = -1
MAX_WATCHABLE_QUESTS = 5
QUEST_WATCH_NO_OBJECTIVES = "No objectives"
QUEST_WATCH_TOO_MANY = "Too many: %d"
QuestLogListScrollFrame = newObject("QuestLogListScrollFrame", QuestLogFrame)
function FauxScrollFrame_GetOffset(frame) return 0 end
function GetQuestLogTitle(index)
    local data = questTitles[index]
    if not data then return nil end
    return data.title, 10, nil, data.header, false, false
end
function GetNumQuestLeaderBoards(index)
    local data = questTitles[index]
    return data and data.objectives or 0
end
function SelectQuestLogEntry(index) selectedQuestLogIndex = index end
function IsQuestWatched(index) return questWatchSet[index] and true or false end
function AddQuestWatch(index) questWatchSet[index] = true end
function RemoveQuestWatch(index) questWatchSet[index] = nil end
function GetNumQuestWatches()
    local count = 0
    local key, value
    for key, value in pairs(questWatchSet) do if value then count = count + 1 end end
    return count
end
function AutoQuestWatch_Insert(index, timer)
    table.insert(QUEST_WATCH_LIST, {index=index, timer=timer})
    AddQuestWatch(index)
end
function QuestWatch_Update() end
function QuestLog_Update() end
UIErrorsFrame = { messages = {}, AddMessage = function(self, text) table.insert(self.messages, text) end }
NUM_TAXI_BUTTONS = 0
local mockTaxiNodes = 0
function NumTaxiNodes() return mockTaxiNodes end

PocketRealmPadDB = {}

local scriptPath = arg[0] or "/mnt/data/PocketRealmPad/tests/runtime_mock.lua"
local root = string.gsub(scriptPath, "tests/runtime_mock.lua$", "")
local files = {
    "Locale.lua", "Profile.lua", "Compat.lua", "Handheld.lua", "UI.lua",
    "VanillaActions.lua", "ActionBar.lua", "Targeting.lua", "Adapters.lua",
    "Focus.lua", "Inventory.lua", "QuickMenu.lua", "Companion.lua",
    "Guide.lua", "Router.lua", "Slash.lua", "Core.lua",
}
for _, name in ipairs(files) do
    local fn, err = loadfile(root .. name)
    check(fn ~= nil, "loadfile " .. name .. ": " .. tostring(err))
    if fn then
        local ok, runtimeErr = pcall(fn)
        check(ok, "execute " .. name .. ": " .. tostring(runtimeErr))
    end
end

local ok, initErr = pcall(function() PRP:Initialize() end)
check(ok, "initialize: " .. tostring(initErr))
check(PRP.initialized, "core initialized")
equal(PRP.version, "0.5.0-alpha", "version")
equal(#PRP_ActionBar.buttons, 12, "12 action buttons")
equal(#PRP_Inventory.cells, 20, "20 inventory cells")
equal(#PRP_QuickMenu.buttons, 9, "9 quick-menu cells")
equal(#PRP_QuickMenu.pages, 2, "2 quick-menu pages")
equal(#PRP_Companion.buttons, 20, "20 companion cells")
check(PRP_Guide.initialized, "new-player guide initialized")
equal(PRP_Guide.pageCount, 5, "new-player guide has five short progressive pages")
local essentialBound, essentialTotal = PRP:GetEssentialBindingStatus()
equal(essentialBound, 0, "unconfigured mock reports no essential bindings")
equal(essentialTotal, 14, "beginner setup requires fourteen addon bindings")
check(not PRP_UI.mode:IsShown(), "technical mode badge hidden by default")
equal(PocketRealmPadDB.action.showSlotNumbers, 0, "slot numbers hidden by default")

-- Responsive profiles preserve approximately equivalent physical size when the
-- virtual desktop moves from 720p to 1080p.
equal(PRP_Handheld.resolved, "HANDHELD_720", "auto 720p profile")
equal(PRP_Handheld:GetMetrics().actionButton, 54, "720p action size")
equal(PocketRealmPadDB.action.visibleButtons, 8, "720p visible actions")
equal(PRP_Inventory.pageSize, 12, "720p inventory page size")
local basePromptFont = PRP_UI.promptText.fontSize

screenWidth = 1920; screenHeight = 1080; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 960; UIParent.centerY = 540
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "RP6_1080", "auto 5.5-inch 1080p profile")
equal(PRP_Handheld:GetMetrics().actionButton, 82, "1080p action size")
equal(PocketRealmPadDB.bar.buttonSize, 82, "1080p applied action size")
equal(PRP_Inventory.pageSize, 12, "1080p compact inventory remains 4x3")
check(PocketRealmPadDB.inventory.showDetails == 1, "1080p inventory details enabled")
check(PRP_UI.promptText.fontSize > basePromptFont, "1080p fonts enlarged")
equal(PRP_UI.focusOuter[1].height, 6, "1080p focus ring thickness")
local font1080 = PRP_UI.promptText.fontSize

screenWidth = 1920; screenHeight = 1200; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 960; UIParent.centerY = 600
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_1200", "auto 1200p 16:10 handheld profile")
equal(PRP_Handheld:GetMetrics().actionButton, 90, "1200p action size")
check(PRP_UI.promptText.fontSize > font1080, "1200p fonts enlarged over 1080p")
local font1200 = PRP_UI.promptText.fontSize

screenWidth = 2560; screenHeight = 1440; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 1280; UIParent.centerY = 720
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_1440", "auto high-density 1440p handheld profile")
equal(PRP_Handheld:GetMetrics().actionButton, 108, "1440p action size")
equal(PRP_Inventory.pageSize, 12, "1440p handheld inventory remains 4x3")
check(PRP_UI.promptText.fontSize > font1200, "1440p fonts enlarged over 1200p")
equal(PRP_UI.focusOuter[1].height, 8, "1440p focus ring thickness")

screenWidth = 1600; screenHeight = 900; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 800; UIParent.centerY = 450
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_900", "900p profile")
equal(PRP_Handheld:GetMetrics().actionButton, 68, "900p action size")

screenWidth = 1280; screenHeight = 800; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 640; UIParent.centerY = 400
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_800", "800p 16:10 profile")
equal(PRP_Handheld:GetMetrics().actionButton, 60, "800p action size")

screenWidth = 800; screenHeight = 1280; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 400; UIParent.centerY = 640
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_800", "orientation-normalized 800p profile")

screenWidth = 800; screenHeight = 600; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 400; UIParent.centerY = 300
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "LEGACY_600", "actual 800x600 client has deliberate profile")
equal(PocketRealmPadDB.action.visibleButtons, 8, "600p keeps eight readable actions")

screenWidth = 960; screenHeight = 540; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 480; UIParent.centerY = 270
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "COMPACT_540", "540p profile")
equal(PocketRealmPadDB.action.visibleButtons, 8, "540p keeps eight visible actions")
PRP_ActionBar:SetModifier("bank", "down")
equal(PocketRealmPadDB.schema, 5, "saved-variable schema")
equal(PocketRealmPadDB.mappingProfile, "retroid-pocket-6-stick-top-v5", "RP6 stick-top profile")
equal(PocketRealmPadDB.controls.confirm, "A", "right A is physical confirm")
equal(PocketRealmPadDB.controls.back, "B", "bottom B is physical back")
equal(PocketRealmPadDB.controls.target, "M1", "rear M1 targets")
equal(PocketRealmPadDB.controls.jump, "M2", "rear M2 jumps")
PocketRealmPadDB.controls.target = "M2"
PocketRealmPadDB.controls.jump = "M1"
equal(PRP_ControlLabel("target"), "M2", "launcher may swap the rear target label")
equal(PRP_ControlLabel("jump"), "M1", "launcher may swap the rear jump label")
PocketRealmPadDB.controls.target = "M1"
PocketRealmPadDB.controls.jump = "M2"
equal(PRP_ActionBar:GetDisplaySemantic(1), 1, "visible bar remains stable while R1 is held")
equal(PRP_ActionBar:GetInputSemantic(1), 5, "R1 maps first face control to action 5")
equal(PRP_ActionBar:GetInputSemantic(5), 5, "R1 does not remap direct action 5")
equal(PRP_ActionBar:GetSemanticLabel(1), "A", "ability 1 uses right printed A")
equal(PRP_ActionBar:GetSemanticLabel(5), "R1+A", "ability 5 uses R1 plus right A")
equal(PRP_ActionBar:GetSemanticLabel(9), "D-UP", "ability 9 uses D-pad up")
local bankActionsBefore = #usedActions
PRP_Router:ActionKey(1, "down")
PRP_ActionBar:SetModifier("bank", "up")
PRP_Router:ActionKey(1, "up")
equal(#usedActions, bankActionsBefore + 1, "bank action executes after early bank release")
equal(usedActions[#usedActions].slot, 5, "R1 bank captures action 5 on key-down")

PRP_Handheld:SetProfile("large")
equal(PRP_Handheld.resolved, "ANDROID_LARGE", "manual Android large-display profile")
equal(PocketRealmPadDB.action.visibleButtons, 12, "large Android display shows 12 actions")
PocketRealmPadDB.display.profile = "AUTO"
screenWidth = 1920; screenHeight = 1080; UIParent.width = 1280; UIParent.height = 720; UIParent.centerX = 640; UIParent.centerY = 360
PRP_Handheld:Apply(true)
equal(PRP_Handheld.resolved, "HANDHELD_720", "layout follows logical UI desktop, not render pixels alone")
equal(PRP_Handheld.renderWidth, 1920, "render width recorded separately")
screenWidth = 1280; screenHeight = 720; UIParent.width = screenWidth; UIParent.height = screenHeight; UIParent.centerX = 640; UIParent.centerY = 360
PRP_Handheld:Apply(true)

-- Six ordinary Vanilla pages and exact bonus-page formula.
equal(PRP_ActionBar:GetPageForLayer(1), 1, "set A base page 1")
equal(PRP_ActionBar:GetPageForLayer(2), 2, "set A shift page 2")
equal(PRP_ActionBar:GetPageForLayer(3), 3, "set A control page 3")
equal(PRP_ActionBar:GetPageForLayer(4), 4, "set A combined page 4")
PocketRealmPadDB.action.pageSet = "B"
equal(PRP_ActionBar:GetPageForLayer(1), 5, "set B base page 5")
equal(PRP_ActionBar:GetPageForLayer(2), 6, "set B shift page 6")
equal(PRP_ActionBar:GetPageForLayer(3), 3, "set B control remains page 3")
equal(PRP_ActionBar:GetPageForLayer(4), 4, "set B combined remains page 4")
equal(PRP_ActionBar:GetSlot(12, 6), 72, "ordinary slot 72")
PocketRealmPadDB.action.pageSet = "A"
BonusActionBarFrame.shown = true; bonusOffset = 2
equal(PRP_ActionBar:GetSlot(1, 1), 85, "bonus offset 2 maps to slot 85")
equal(PRP_ActionBar:GetSlot(1, 2), 13, "bonus never replaces page 2")
BonusActionBarFrame.shown = false; bonusOffset = 0

shiftDown = true
equal(PRP_ActionBar:GetLayer(), 2, "physical shift layer")
shiftDown = false; controlDown = true
equal(PRP_ActionBar:GetLayer(), 3, "physical control layer")
shiftDown = true
equal(PRP_ActionBar:GetLayer(), 4, "physical combined layer")
shiftDown = false; controlDown = false

local beforeActions = #usedActions
PRP_Router:ActionKey(5, "down")
PRP_Router:ActionKey(5, "up")
equal(#usedActions, beforeActions + 1, "world action executes once")
equal(usedActions[#usedActions].slot, 5, "world action 5 uses slot 5")

-- Slot and self-cast state are captured on key-down, not re-resolved on key-up.
shiftDown = true
PRP_Router:ActionKey(1, "down")
shiftDown = false
PocketRealmPadDB.action.pageSet = "B"
PRP_Router:ActionKey(1, "up")
equal(usedActions[#usedActions].slot, 13, "early modifier release preserves page-2 slot")
PocketRealmPadDB.action.pageSet = "A"
altDown = true
PRP_Router:ActionKey(2, "down")
altDown = false
PRP_Router:ActionKey(2, "up")
equal(usedActions[#usedActions].slot, 2, "self-cast action slot captured")
equal(usedActions[#usedActions].selfCast, 1, "self-cast captured on key-down")

beforeActions = #usedActions
BonusActionBarFrame.shown = true; bonusOffset = 1; altDown = true
PRP_Router:ActionKey(1, "down")
BonusActionBarFrame.shown = false; bonusOffset = 0; altDown = false
PRP_Router:ActionKey(1, "up")
equal(usedActions[#usedActions].slot, 73, "bonus slot captured")
check(usedActions[#usedActions].selfCast == nil, "bonus action suppresses ordinary self-cast flag")
PRP_Router:ActionKey(12, "up")
equal(#usedActions, beforeActions + 1, "orphan key-up does not execute")

-- D-pad routes to actions in the world and to targeting in targeting mode.
PocketRealmPadDB.action.dpadWorldMode = "ACTIONS"
beforeActions = #usedActions
PRP_Router:Navigate("UP", "down")
PRP_Router:Navigate("UP", "up")
equal(#usedActions, beforeActions + 1, "world D-pad action executes once")
equal(usedActions[#usedActions].slot, 9, "D-pad up maps to semantic action 9")
PocketRealmPadDB.action.dpadWorldMode = "TARGETING"
beforeActions = #usedActions
local beforeTargets = #targetingLog
PRP_Router:Navigate("UP", "down")
PRP_Router:Navigate("UP", "up")
equal(#usedActions, beforeActions, "targeting D-pad does not cast")
equal(#targetingLog, beforeTargets + 1, "targeting D-pad invokes one target operation")
PocketRealmPadDB.action.dpadWorldMode = "ACTIONS"

-- Controller inventory and context-captured key-up behavior.
PRP_Inventory:Show()
equal(PRP_Router:GetContext(), "INVENTORY", "inventory context")
check(PRP_Inventory.selectedName:IsShown(), "selected item name is always visible")
equal(PRP_Inventory.selectedName:GetText(), "Item A", "selected item name shown at handheld size")
equal(PRP_Inventory.cells[1].bagText:GetText(), "", "raw bag and slot coordinates hidden for newcomers")
check(string.find(PRP_Inventory.detailText:GetText(), "Backpack", 1, true) ~= nil, "inventory details use a friendly backpack label")
check(string.find(string.lower(PRP_Inventory.detailText:GetText()), "slot", 1, true) == nil, "inventory details hide technical slot numbers outside debug mode")
check(not PRP_UI.prompt:IsShown(), "controller inventory uses one embedded help line, not a duplicate global prompt")
local touchUses = #containerUses
this = PRP_Inventory.cells[2]; arg1 = "LeftButton"; PRP_InventoryCell_OnClick()
equal(PRP_Inventory.selected, 2, "normal touch selects an inventory item")
equal(#containerUses, touchUses, "normal touch does not accidentally use or equip an item")
arg1 = "RightButton"; PRP_InventoryCell_OnClick()
equal(#containerUses, touchUses + 1, "secondary click keeps Vanilla use/equip behavior")
this = nil; arg1 = nil
PRP_Inventory:SetSelected(1)
local beforeUses = #containerUses
beforeActions = #usedActions
PRP_Router:ActionKey(1, "down")
PRP_Inventory:Hide()
PRP_Router:ActionKey(1, "up")
equal(#usedActions, beforeActions, "captured UI action never falls through to combat")
equal(#containerUses, beforeUses + 1, "captured inventory accept uses selected item")

PRP_Inventory:Show()
MerchantFrame.shown = true
beforeUses = #containerUses
PRP_Inventory:Accept()
equal(#containerUses, beforeUses, "merchant first press only prepares sale")
check(PRP_Inventory.pendingSaleKey ~= nil, "sale confirmation is visible state")
PRP_Inventory:Back()
check(PRP_Inventory.pendingSaleKey == nil and PRP_Inventory:IsShown(), "Back cancels sale without closing inventory")
PRP_Inventory:Accept()
advance(0.2)
PRP_Inventory:Accept()
equal(#containerUses, beforeUses + 1, "merchant confirmed sale is requested")
PRP_Inventory:Accept()
PRP_Inventory:SetSelected(2)
check(PRP_Inventory.pendingSaleKey == nil, "selection change cancels merchant confirmation")
MerchantFrame.shown = false
local beforePickups = #containerPickups
PRP_Inventory:Alternate()
equal(#containerPickups, beforePickups + 1, "inventory alternate picks up item")
PRP_Inventory:Hide()

-- Quick menu is a digital 3x3 surface with two pages.
PRP_QuickMenu.page = 1; PRP_QuickMenu.selected = 1
PRP_QuickMenu:Show()
equal(PRP_Router:GetContext(), "QUICK", "quick-menu context")
PRP_QuickMenu:Accept()
equal(toggles[#toggles], "character:PaperDollFrame", "quick menu opens character")
PRP_QuickMenu:Show()
equal(PRP_QuickMenu.pages[1][5].kind, "INVENTORY", "quick menu centers the common inventory task")
PRP_QuickMenu:SetPage(2)
equal(PRP_QuickMenu.page, 2, "quick menu page 2")
equal(PRP_QuickMenu:GetEntry(5).kind, "GUIDE", "quick menu second page centers controls and help")
equal(PRP_QuickMenu:GetEntry(6).kind, "PAGE_SET", "quick menu keeps extra bars out of daily page")
PRP_QuickMenu:Hide()
PRP_QuickMenu:OnKey("down")
check(PRP_QuickMenu:IsShown(), "one Quick Menu press opens")
PRP_QuickMenu:OnKey("up")
check(PRP_QuickMenu:IsShown(), "Quick Menu release does not activate or close")
check(not PRP_UI.prompt:IsShown(), "Quick Menu uses its embedded help line without duplicate prompt")
PRP_QuickMenu:OnKey("down")
check(not PRP_QuickMenu:IsShown(), "second Quick Menu press closes")
PRP_QuickMenu:OnKey("up")
check(not PRP_QuickMenu:IsShown(), "closing release is side-effect free")

ChatFrameEditBox.shown = true
PRP_Router:QuickMenuKey("down")
PRP_Router:InventoryKey()
PRP_Router:CompanionKey()
check(not PRP_QuickMenu:IsShown(), "chat suppresses Quick Menu shortcut")
check(not PRP_Inventory:IsShown(), "chat suppresses inventory shortcut")
check(not PRP_Companion:IsShown(), "chat suppresses companion shortcut")
ChatFrameEditBox.shown = false

-- The first-run guide is controller-readable and captures inputs without casting.
PRP_Guide:Show()
equal(PRP_Router:GetContext(), "GUIDE", "guide context")
local guideActionsBefore = #usedActions
PRP_Router:ActionKey(1, "down")
PRP_Router:ActionKey(1, "up")
equal(PRP_Guide.page, 2, "guide confirm advances page")
equal(#usedActions, guideActionsBefore, "guide input never casts")
PRP_Guide:Back()
check(PocketRealmPadDB.onboarding.completed == 1, "closing guide completes onboarding")
PocketRealmPadDB.onboarding.completed = 0
PRP.pendingGuideAt = GetTime()
PRP_Inventory:Show()
PRP:OnUpdate(0)
check(not PRP_Guide:IsShown(), "automatic guide never interrupts a menu the player opened")
check(PRP.pendingGuideAt and PRP.pendingGuideAt > GetTime(), "blocked automatic guide is postponed rather than lost")
PRP_Inventory:Hide()
advance(0.60)
PRP:OnUpdate(0)
check(PRP_Guide:IsShown(), "postponed guide opens after returning to the world")
PRP_Guide:Hide(true)

-- Static confirmation popups have priority over custom addon surfaces.
PRP_Inventory:Show()
local popup = StaticPopup1
local popupConfirm = newObject("StaticPopup1Button1", popup)
local popupCancel = newObject("StaticPopup1Button2", popup)
local popupClose = newObject("StaticPopup1CloseButton", popup)
local popupConfirmed = 0
popup.shown = true; popupConfirm.shown = true; popupCancel.shown = true; popupClose.shown = true
popupConfirm:SetScript("OnClick", function() popupConfirmed = popupConfirmed + 1; popup.shown = false; popupConfirm.shown = false; popupCancel.shown = false; popupClose.shown = false end)
equal(PRP_Router:GetContext(), "MODAL", "modal popup outranks inventory")
PRP_Router:ActionKey(1, "down")
PRP_Router:ActionKey(1, "up")
equal(popupConfirmed, 1, "modal confirm executes")
check(PRP_Inventory:IsShown(), "underlying inventory remains open after popup")
PRP_Inventory:Hide()

-- Companion surface exposes the real Vanilla pet/form positions.
PRP_Companion:Show()
equal(PRP_Router:GetContext(), "COMPANION", "companion context")
equal(PRP_Companion.entries[1].name, "Pet Skill 1", "pet action entry")
equal(PRP_Companion.entries[11].name, "Bear Form", "form entry")
equal(PRP_Companion.buttons[1].label:GetText(), "", "companion panel hides raw P/F index labels")
equal(PRP_Companion.buttons[1].count:GetText(), "", "companion panel hides duplicate index counts")
check(not PRP_UI.prompt:IsShown(), "companion panel uses one embedded help line")
local beforePetCasts = #petCasts
PRP_Companion.selected = 1; PRP_Companion:Accept()
equal(#petCasts, beforePetCasts + 1, "companion accept casts pet action")
local beforeAuto = #petAutoToggles
PRP_Companion:Alternate()
equal(#petAutoToggles, beforeAuto + 1, "companion alternate toggles pet autocast")
local beforeFormCasts = #formCasts
PRP_Companion.selected = 11; PRP_Companion:Accept()
equal(#formCasts, beforeFormCasts + 1, "companion accept changes form")
PRP_Companion:Hide()
local savedGetPetActionInfo = GetPetActionInfo
local savedGetNumShapeshiftForms = GetNumShapeshiftForms
GetPetActionInfo = function(index) return nil end
GetNumShapeshiftForms = function() return 0 end
PRP_Companion:Show()
check(PRP_Companion.emptyText:IsShown(), "companion panel has a clear empty state")
check(not PRP_Companion.buttons[1]:IsShown(), "unavailable companion cells are hidden")
PRP_Companion:Hide()
GetPetActionInfo = savedGetPetActionInfo
GetNumShapeshiftForms = savedGetNumShapeshiftForms
PRP_Companion:Rebuild()

beforePetCasts = #petCasts
PRP_VanillaActions:PetKey(2, "down")
PRP_VanillaActions:PetKey(2, "up")
equal(#petCasts, beforePetCasts + 1, "direct pet binding uses down/up capture")
equal(petCasts[#petCasts], 2, "direct pet action index")

-- Targeting uses only the Vanilla target/unit APIs.
targetUnitName = nil
PRP_Targeting:CycleGroup(1); equal(targetUnitName, "player", "group cycle starts at player")
PRP_Targeting:CycleGroup(1); equal(targetUnitName, "pet", "group cycle includes pet")
PRP_Targeting:CycleGroup(1); equal(targetUnitName, "party1", "group cycle includes party")
PRP_Targeting:CycleGroup(1); equal(targetUnitName, "partypet1", "group cycle includes party pet")
PRP_Targeting:CycleGroup(-1); equal(targetUnitName, "party1", "group cycle reverses")
PRP_Targeting:Command("NEXT_ENEMY"); equal(targetUnitName, "enemy", "nearest enemy")
PRP_Targeting:Update(true); check(string.find(PRP_Targeting.nameText:GetText(), "L??", 1, true) ~= nil, "unknown hostile level shown as ??")
PRP_Targeting:Command("SELF"); equal(targetUnitName, "player", "target self")
PRP_Targeting:Command("SELF"); equal(targetUnitName, "player", "target self remains player when already selected")
PRP_Targeting:Command("PET"); equal(targetUnitName, "pet", "target pet")
PRP_Targeting:Command("CLEAR"); check(targetUnitName == nil, "clear target")
PRP_Targeting:Command("ATTACK"); equal(targetingLog[#targetingLog], "attack", "attack target command")
PRP_Targeting:Command("PET_ATTACK"); equal(targetingLog[#targetingLog], "pet-attack", "pet attack command")
PRP_Targeting:Command("FOLLOW"); equal(targetingLog[#targetingLog], "follow:target", "follow target command")

-- Explicit raid markers, stock pages, and fixed Vanilla helpers.
PRP_VanillaActions:RaidMarker(8); equal(raidMarks[#raidMarks], "target:8", "skull raid marker")
PRP_VanillaActions:RaidMarker(0); equal(raidMarks[#raidMarks], "target:0", "clear raid marker")
CURRENT_ACTIONBAR_PAGE = 1
PRP_VanillaActions:PageCommand("PAGE6"); equal(CURRENT_ACTIONBAR_PAGE, 6, "stock page 6")
PRP_VanillaActions:PageCommand("NEXT"); equal(CURRENT_ACTIONBAR_PAGE, 1, "stock next page wraps")
PRP_VanillaActions:PageCommand("PREVIOUS"); equal(CURRENT_ACTIONBAR_PAGE, 6, "stock previous page wraps")
PRP_VanillaActions:PageCommand("LOCK"); equal(LOCK_ACTIONBAR, "0", "stock action bar unlock")
PRP_VanillaActions:PageCommand("AUTO_SELF_CAST"); equal(GetCVar("autoSelfCast"), "1", "auto self cast toggle")
PRP_VanillaActions:Helper("TALENTS"); equal(toggles[#toggles], "talents", "talent helper")
PRP_VanillaActions:Helper("ALL_BAGS"); equal(toggles[#toggles], "all-bags", "all bags helper")
PRP_VanillaActions:Helper("NAMEPLATES"); equal(NAMEPLATES_ON, 1, "nameplates helper")
PRP_VanillaActions:Helper("SCREENSHOT"); equal(toggles[#toggles], "screenshot", "screenshot helper")

-- Vanilla mail and auction controls use the actual 1.12 single-package/page widgets.
local sendPackage = newObject("SendMailPackageButton", SendMailFrame); sendPackage.shown = true
local sendMailButton = newObject("SendMailMailButton", SendMailFrame); sendMailButton.shown = true
SendMailFrame.shown = true
local adapterNodes = {}
PRP_Adapters.sendMail:Collect(adapterNodes)
local foundSendPackage = false
local sendMailNode = nil
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == sendPackage then foundSendPackage = true end
    if adapterNodes[i].frame == sendMailButton then sendMailNode = adapterNodes[i] end
end
check(not foundSendPackage, "send-mail package drag slot remains touch-only")
check(sendMailNode ~= nil and sendMailNode.confirm ~= nil, "send-mail commit requires controller confirmation")
SendMailFrame.shown = false; sendPackage.shown = false; sendMailButton.shown = false

local openLetter = newObject("OpenMailLetterButton", OpenMailFrame); openLetter.shown = true
local openPackage = newObject("OpenMailPackageButton", OpenMailFrame); openPackage.shown = true
local openMoney = newObject("OpenMailMoneyButton", OpenMailFrame); openMoney.shown = true
OpenMailFrame.shown = true
adapterNodes = {}
PRP_Adapters.openMail:Collect(adapterNodes)
local foundLetter, foundPackage, foundMoney = false, false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == openLetter then foundLetter = true end
    if adapterNodes[i].frame == openPackage then foundPackage = true end
    if adapterNodes[i].frame == openMoney then foundMoney = true end
end
check(foundLetter and foundPackage and foundMoney, "open-mail adapter exposes Vanilla letter/package/money controls")
OpenMailFrame.shown = false; openLetter.shown = false; openPackage.shown = false; openMoney.shown = false

local browsePrev = newObject("BrowsePrevPageButton", AuctionFrame); browsePrev.shown = true
local browseNext = newObject("BrowseNextPageButton", AuctionFrame); browseNext.shown = true
AuctionFrame.shown = true
adapterNodes = {}
PRP_Adapters.auctionBrowse:Collect(adapterNodes)
local foundBrowsePrev, foundBrowseNext = false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == browsePrev then foundBrowsePrev = true end
    if adapterNodes[i].frame == browseNext then foundBrowseNext = true end
end
check(foundBrowsePrev and foundBrowseNext, "auction browse adapter exposes Vanilla result paging")
AuctionFrame.shown = false; browsePrev.shown = false; browseNext.shown = false

-- Quest-log names and semantics match the 1.12 FrameXML: six visible title
-- rows, QuestFramePushQuestButton/QuestFrameExitButton, and shift-click-style
-- watch toggling through Action 3 rather than nonexistent retail controls.
local questTitle2 = newObject("QuestLogTitle2", QuestLogFrame); questTitle2.shown = true; questTitle2:SetID(2)
local questPush = newObject("QuestFramePushQuestButton", QuestLogFrame); questPush.shown = true
local questExit = newObject("QuestFrameExitButton", QuestLogFrame); questExit.shown = true
local questClose = newObject("QuestLogFrameCloseButton", QuestLogFrame); questClose.shown = true
local questCollapse = newObject("QuestLogCollapseAllButton", QuestLogFrame); questCollapse.shown = true
QuestLogFrame.shown = true
adapterNodes = {}
PRP_Adapters.questLog:Collect(adapterNodes)
local questNode = nil
local foundQuestPush, foundQuestExit = false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == questTitle2 then questNode = adapterNodes[i] end
    if adapterNodes[i].frame == questPush then foundQuestPush = true end
    if adapterNodes[i].frame == questExit then foundQuestExit = true end
end
check(questNode ~= nil and questNode.alternate ~= nil, "quest-log title exposes alternate watch semantic")
check(foundQuestPush and foundQuestExit, "quest-log adapter uses exact Vanilla share/exit controls")
check(questNode.alternate(questTitle2), "quest alternate adds quest watch")
check(IsQuestWatched(2), "quest became watched")
equal(selectedQuestLogIndex, 2, "quest alternate selects visible quest")
check(questNode.alternate(questTitle2), "quest alternate removes quest watch")
check(not IsQuestWatched(2), "quest watch removed")
QuestLogFrame.shown = false; questTitle2.shown = false; questPush.shown = false; questExit.shown = false; questClose.shown = false; questCollapse.shown = false

-- Trade item buttons are inherited $parentItemButton controls; money edit boxes
-- are intentionally omitted from click focus. Taxi nodes are runtime-created
-- TaxiButtonN controls and the close button is TaxiCloseButton.
local tradePlayerItem = newObject("TradePlayerItem1ItemButton", TradeFrame); tradePlayerItem.shown = true
local tradeRecipientItem = newObject("TradeRecipientItem1ItemButton", TradeFrame); tradeRecipientItem.shown = true
local tradeAccept = newObject("TradeFrameTradeButton", TradeFrame); tradeAccept.shown = true
local tradeCancel = newObject("TradeFrameCancelButton", TradeFrame); tradeCancel.shown = true
local tradeClose = newObject("TradeFrameCloseButton", TradeFrame); tradeClose.shown = true
TradeFrame.shown = true
adapterNodes = {}
PRP_Adapters.trade:Collect(adapterNodes)
local foundTradePlayer, foundTradeRecipient, foundTradeClose = false, false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == tradePlayerItem then foundTradePlayer = true end
    if adapterNodes[i].frame == tradeRecipientItem then foundTradeRecipient = true end
    if adapterNodes[i].frame == tradeClose then foundTradeClose = true end
end
local tradeAcceptNode = nil
for i = 1, #adapterNodes do if adapterNodes[i].frame == tradeAccept then tradeAcceptNode = adapterNodes[i] end end
check(not foundTradePlayer and not foundTradeRecipient and foundTradeClose, "trade item placement remains touch-only")
check(tradeAcceptNode ~= nil and tradeAcceptNode.confirm ~= nil, "trade acceptance requires controller confirmation")
TradeFrame.shown = false; tradePlayerItem.shown = false; tradeRecipientItem.shown = false; tradeAccept.shown = false; tradeCancel.shown = false; tradeClose.shown = false

mockTaxiNodes = 3; NUM_TAXI_BUTTONS = 3
local taxi1 = newObject("TaxiButton1", TaxiFrame); taxi1.shown = true
local taxi2 = newObject("TaxiButton2", TaxiFrame); taxi2.shown = true
local taxi3 = newObject("TaxiButton3", TaxiFrame); taxi3.shown = true
local taxiClose = newObject("TaxiCloseButton", TaxiFrame); taxiClose.shown = true
TaxiFrame.shown = true
adapterNodes = {}
PRP_Adapters.taxi:Collect(adapterNodes)
local taxiNodeCount, foundTaxiClose = 0, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == taxi1 or adapterNodes[i].frame == taxi2 or adapterNodes[i].frame == taxi3 then taxiNodeCount = taxiNodeCount + 1 end
    if adapterNodes[i].frame == taxiClose then foundTaxiClose = true end
end
equal(taxiNodeCount, 3, "taxi adapter collects runtime-created Vanilla nodes")
check(foundTaxiClose, "taxi adapter uses TaxiCloseButton")
TaxiFrame.shown = false; taxi1.shown = false; taxi2.shown = false; taxi3.shown = false; taxiClose.shown = false

-- Destructive or drag-oriented controls remain touch-only for a newcomer.
local characterHead = newObject("CharacterHeadSlot", CharacterFrame); characterHead.shown = true
local characterTab = newObject("CharacterFrameTab1", CharacterFrame); characterTab.shown = true
local characterClose = newObject("CharacterFrameCloseButton", CharacterFrame); characterClose.shown = true
adapterNodes = {}
PRP_Adapters.character:Collect(adapterNodes)
local sawCharacterHead, sawCharacterTab = false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == characterHead then sawCharacterHead = true end
    if adapterNodes[i].frame == characterTab then sawCharacterTab = true end
end
check(not sawCharacterHead and sawCharacterTab, "character adapter leaves equipment drag slots to touch")
characterHead.shown = false; characterTab.shown = false; characterClose.shown = false

local abandonQuest = newObject("QuestLogFrameAbandonButton", QuestLogFrame); abandonQuest.shown = true
adapterNodes = {}
PRP_Adapters.questLog:Collect(adapterNodes)
local sawAbandon = false
for i = 1, #adapterNodes do if adapterNodes[i].frame == abandonQuest then sawAbandon = true end end
check(not sawAbandon, "quest abandonment remains touch-only")
abandonQuest.shown = false

local talentCell = newObject("TalentFrameTalent1", TalentFrame); talentCell.shown = true
local talentTab = newObject("TalentFrameTab1", TalentFrame); talentTab.shown = true
local talentClose = newObject("TalentFrameCloseButton", TalentFrame); talentClose.shown = true
adapterNodes = {}
PRP_Adapters.talents:Collect(adapterNodes)
local sawTalentCell, sawTalentTab = false, false
for i = 1, #adapterNodes do
    if adapterNodes[i].frame == talentCell then sawTalentCell = true end
    if adapterNodes[i].frame == talentTab then sawTalentTab = true end
end
check(not sawTalentCell and sawTalentTab, "talent spending remains touch-only while tabs stay controller-readable")
talentCell.shown = false; talentTab.shown = false; talentClose.shown = false

-- Focus geometry and explicit-adapter behavior.
local f1 = newObject("MockFocus1", UIParent); f1.centerX = 100; f1.centerY = 100
local f2 = newObject("MockFocus2", UIParent); f2.centerX = 200; f2.centerY = 100
local f3 = newObject("MockFocus3", UIParent); f3.centerX = 100; f3.centerY = 200
PRP_Focus.nodes = {{frame=f1},{frame=f2},{frame=f3}}
PRP_Focus.index = 1
PRP_Focus.adapter = {id="mock",title="Mock"}
equal(PRP_Focus:GetDirectionalCandidate(1, 0), 2, "focus geometry right")
equal(PRP_Focus:GetDirectionalCandidate(0, 1), 3, "focus geometry up")
PRP_Inventory:Show(); check(not PRP_Focus:IsActive(), "custom surface suppresses panel focus"); PRP_Inventory:Hide()
local bankItem = newObject("BankFrameItem1", BankFrame); bankItem.shown = true
local bankClose = newObject("BankCloseButton", BankFrame); bankClose.shown = true
BankFrame.shown = true
PRP_Focus:Detect(true)
equal(PRP_Focus.adapter.id, "bank", "explicit bank adapter selected")
check(PRP_Focus:IsActive(), "bank focus active")
equal(#PRP_Focus.nodes, 1, "bank controller focus exposes only the close action")
check(PRP_Focus.nodes[1].frame == bankClose, "bank item movement remains touch-only")
check(PRP_UI.prompt:IsShown(), "ordinary Blizzard panel focus shows one global action prompt")
PRP_Focus:Clear()
check(not PRP_UI.prompt:IsShown(), "clearing focus also clears its prompt")
BankFrame.shown = false; bankItem.shown = false; bankClose.shown = false; PRP_Focus:Detect(true)

-- Spending and commit controls require a deliberate second Confirm press.
local confirmInvocations = 0
local confirmFrame = newObject("MockConfirmPurchase", UIParent); confirmFrame.centerX = 100; confirmFrame.centerY = 100
confirmFrame:SetScript("OnClick", function() confirmInvocations = confirmInvocations + 1 end)
local safeFrame = newObject("MockSafeControl", UIParent); safeFrame.centerX = 200; safeFrame.centerY = 100
safeFrame:SetScript("OnClick", function() end)
local backInvocations = 0
PRP_Focus.adapter = {id="confirm-test", title="Confirm test", Back=function() backInvocations = backInvocations + 1; return true end}
PRP_Focus.nodes = {
    {frame=confirmFrame, label="Buy", confirm="Buy this item"},
    {frame=safeFrame, label="Next"},
}
PRP_Focus.index = 1
PRP_Focus:ClearPendingConfirm(false)
check(PRP_Focus:Accept(), "first confirm press is consumed")
equal(confirmInvocations, 0, "first confirm press does not invoke spending action")
check(PRP_Focus.pendingConfirmFrame == confirmFrame, "first confirm press arms exact focused control")
check(string.find(PRP_UI.promptText:GetText(), "again", 1, true) ~= nil, "focus prompt explains second confirm press")
-- Prevent Detect from replacing the mock adapter while testing the confirmation state.
local savedDetect = PRP_Focus.Detect
PRP_Focus.Detect = function() end
check(PRP_Focus:Accept(), "second confirm press invokes action")
equal(confirmInvocations, 1, "second confirm press invokes exactly once")
check(PRP_Focus.pendingConfirmFrame == nil, "successful confirmation clears pending state")

PRP_Focus:Accept()
equal(confirmInvocations, 1, "new confirmation cycle still waits on first press")
check(PRP_Focus:Back(), "Back cancels pending confirmation")
equal(confirmInvocations, 1, "Back cancellation does not invoke action")
equal(backInvocations, 0, "Back cancellation does not close the panel")
check(PRP_Focus.pendingConfirmFrame == nil, "Back clears pending confirmation")

PRP_Focus:Accept()
PRP_Focus:SetIndex(2)
check(PRP_Focus.pendingConfirmFrame == nil, "moving focus cancels pending confirmation")
PRP_Focus:SetIndex(1)
PRP_Focus:Accept()
advance(4.1)
PRP_Focus:OnUpdate(0)
check(PRP_Focus.pendingConfirmFrame == nil, "confirmation expires after four seconds")
equal(confirmInvocations, 1, "expired confirmation never invokes action")
PRP_Focus.Detect = savedDetect
local savedGetActive = PRP_Adapters.GetActive
PRP_Adapters.GetActive = function()
    return {
        id = "confirm-test",
        title = "Confirm test",
        Collect = function(_, nodes)
            nodes[1] = {frame=confirmFrame, label="Buy", confirm="Buy this item"}
        end,
    }
end
PRP_Focus.adapter = PRP_Adapters:GetActive()
PRP_Focus.nodes = {{frame=confirmFrame, label="Buy", confirm="Buy this item"}}
PRP_Focus.index = 1
PRP_Focus.pendingConfirmFrame = confirmFrame
PRP_Focus.pendingConfirmUntil = GetTime() + 4
PRP_Focus:Detect(true)
check(PRP_Focus.pendingConfirmFrame == nil, "forced UI refresh cancels stale destructive confirmation")
PRP_Adapters.GetActive = savedGetActive
PRP_Focus:Clear()

-- Safe mode hides semantic surfaces but leaves already-bound actions usable.
PRP_Slash:SetSafeMode(true)
check(not PRP_ActionBar.frame:IsShown(), "safe mode hides action presentation")
check(not PRP_Targeting.frame:IsShown(), "safe mode hides target card")
check(not PRP_Inventory:Show(), "safe mode blocks inventory surface")
beforeActions = #usedActions
PRP_Router:ActionKey(3, "down"); PRP_Router:ActionKey(3, "up")
equal(#usedActions, beforeActions + 1, "safe mode retains direct semantic action execution")
PRP_Slash:SetSafeMode(false)

-- Recovery/configuration commands cover display, D-pad, pages, and scaling.
local command, rest = PRP_Slash:Split("  DISPLAY 1080 ")
equal(command, "display", "slash parser command")
equal(rest, "1080", "slash parser remainder")
PRP_Slash:SetDisplay("1080"); equal(PocketRealmPadDB.display.profile, "RP6_1080", "slash 1080 display profile")
PRP_Slash:SetDisplay("600"); equal(PocketRealmPadDB.display.profile, "LEGACY_600", "slash 600 display profile")
PRP_Slash:SetDisplay("800"); equal(PocketRealmPadDB.display.profile, "HANDHELD_800", "slash 800 display profile")
PRP_Slash:SetDisplay("1200"); equal(PocketRealmPadDB.display.profile, "HANDHELD_1200", "slash 1200 display profile")
PRP_Slash:SetDisplay("qhd"); equal(PocketRealmPadDB.display.profile, "HANDHELD_1440", "slash QHD display profile")
PRP_Slash:SetDevice("rp6"); equal(PocketRealmPadDB.display.deviceHint, "RETROID_POCKET_6", "slash RP6 device hint")
PRP_Slash:SetDevice("tablet"); equal(PocketRealmPadDB.display.deviceHint, "ANDROID_TABLET", "slash tablet device hint")
PRP_Slash:SetDevice("handheld"); equal(PocketRealmPadDB.display.deviceHint, "ANDROID_HANDHELD", "slash handheld device hint")
PRP_Slash:SetDevice("large"); equal(PocketRealmPadDB.display.deviceHint, "ANDROID_LARGE", "slash Android large device hint")
PRP_Slash:SetDpad("targeting"); equal(PocketRealmPadDB.action.dpadWorldMode, "TARGETING", "slash D-pad mode")
PRP_Slash:SetPageSet("b"); equal(PocketRealmPadDB.action.pageSet, "B", "slash page set")
PRP_Slash:SetTextScale("1.20"); equal(PocketRealmPadDB.textScale, 1.2, "slash text scale")
PRP_Slash:SetScale("1.10"); equal(PocketRealmPadDB.scale, 1.1, "slash addon scale")

PRP_Router:ReleaseAll()
check(next(PRP_Router.captured) == nil, "captured action contexts released")
check(next(PRP_Router.navCaptured) == nil, "captured navigation contexts released")
for i = 1, 10 do check(PRP_VanillaActions.petHeld[i] == nil, "pet hold released " .. i) end

if failures > 0 then
    io.stderr:write(string.format("RUNTIME MOCK FAIL: %d/%d assertions failed\n", failures, assertions))
    os.exit(1)
end
print(string.format("RUNTIME MOCK PASS: %d assertions", assertions))
