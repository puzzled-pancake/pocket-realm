#!/usr/bin/env python3
"""Static compatibility and package-structure checks for PocketRealmPad.

These checks intentionally target the WoW 1.12.1 / Lua 5.0 compatibility
subset. They do not replace an actual build-5875 client run.
"""
from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
TOC = ROOT / "PocketRealmPad.toc"

TOC_FILES = [
    "Locale.lua",
    "Profile.lua",
    "Compat.lua",
    "Handheld.lua",
    "UI.lua",
    "VanillaActions.lua",
    "ActionBar.lua",
    "Targeting.lua",
    "Adapters.lua",
    "Focus.lua",
    "Inventory.lua",
    "QuickMenu.lua",
    "Companion.lua",
    "Guide.lua",
    "Router.lua",
    "Slash.lua",
    "Core.lua",
]

FORBIDDEN_TOKENS = {
    "modern namespace C_": re.compile(r"\bC_[A-Za-z0-9_]*\b"),
    "Enum namespace": re.compile(r"\bEnum\."),
    "modern state driver": re.compile(r"\bRegisterStateDriver\b"),
    "secure handler template": re.compile(r"\bSecureHandler[A-Za-z0-9_]*\b"),
    "secure action template": re.compile(r"\bSecureActionButtonTemplate\b"),
    "override binding API": re.compile(r"\bSetOverrideBinding(?:Click)?\b"),
    "modern gamepad API": re.compile(r"\b(?:GetGamePad|GamePad)[A-Za-z0-9_]*\b"),
    "retail soft-target API": re.compile(r"\b(?:SetCVar\s*\(\s*[\"']SoftTarget|C_NamePlate|UnitGUID)\b"),
    "hooksecurefunc": re.compile(r"\bhooksecurefunc\b"),
    "combat lockdown API": re.compile(r"\bInCombatLockdown\b"),
    "C_Timer": re.compile(r"\bC_Timer\b"),
    "mixin API": re.compile(r"\b(?:CreateFromMixins|Mixin)\s*\("),
    "BackdropTemplate": re.compile(r"\bBackdropTemplate\b"),
    "RegisterUnitEvent": re.compile(r"\bRegisterUnitEvent\b"),
    "post-Vanilla action key CVar": re.compile(r"\bACTION_BUTTON_USE_KEY_DOWN\b"),
    "Lua 5.1 string.match": re.compile(r"\bstring\.match\b"),
    "Lua 5.1 string.gmatch": re.compile(r"\bstring\.gmatch\b"),
    "Lua goto": re.compile(r"\bgoto\b"),
}


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def strip_lua_comments_and_strings(text: str) -> str:
    out: list[str] = []
    i = 0
    state = "code"
    quote = ""
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if state == "code":
            if ch == "-" and nxt == "-":
                state = "comment"
                out.extend("  ")
                i += 2
            elif ch in ("'", '"'):
                state = "string"
                quote = ch
                out.append(" ")
                i += 1
            else:
                out.append(ch)
                i += 1
        elif state == "comment":
            if ch == "\n":
                state = "code"
                out.append("\n")
            else:
                out.append(" ")
            i += 1
        else:
            if ch == "\\":
                out.append(" ")
                if i + 1 < len(text):
                    out.append("\n" if text[i + 1] == "\n" else " ")
                i += 2
            elif ch == quote:
                state = "code"
                out.append(" ")
                i += 1
            else:
                out.append("\n" if ch == "\n" else " ")
                i += 1
    return "".join(out)


def read_toc_files() -> list[str]:
    text = TOC.read_text(encoding="utf-8")
    if not re.search(r"^## Interface:\s*11200\s*$", text, re.MULTILINE):
        fail("TOC must declare Interface 11200")
    if not re.search(r"^## Version:\s*0\.5\.0-alpha\s*$", text, re.MULTILINE):
        fail("TOC version must be 0.5.0-alpha")
    if "## SavedVariables: PocketRealmPadDB" not in text:
        fail("TOC SavedVariables declaration missing")
    files = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith("##")]
    if files != TOC_FILES:
        fail(f"TOC order/file set mismatch: got {files!r}")
    for rel in files:
        if not (ROOT / rel).is_file():
            fail(f"TOC references missing file {rel}")
    return files


def check_bindings() -> None:
    path = ROOT / "Bindings.xml"
    try:
        root = ElementTree.parse(path).getroot()
    except ElementTree.ParseError as exc:
        fail(f"Bindings.xml is not well formed: {exc}")
    bindings = root.findall("Binding")
    names = [node.attrib.get("name", "") for node in bindings]
    if len(names) != 99:
        fail(f"expected 99 project bindings, found {len(names)}")
    if len(names) != len(set(names)):
        fail("duplicate binding name")
    essential = {
        "PRP_ACTION1", "PRP_ACTION2", "PRP_ACTION3", "PRP_ACTION4",
        "PRP_MOD_SHIFT", "PRP_MOD_CTRL", "PRP_MOD_BANK",
        "PRP_NAV_UP", "PRP_NAV_DOWN", "PRP_NAV_LEFT", "PRP_NAV_RIGHT",
        "PRP_QUICK_MENU", "PRP_INVENTORY", "PRP_TARGET_NEXT_ENEMY",
    }
    # Vanilla's stock Bindings.xml starts a category by putting a header only
    # on its first binding; subsequent bindings inherit the current category.
    # Keep Essentials contiguous and first so a newcomer does not have to hunt
    # through repeated/interleaved headers.
    current_header = None
    categories = {}
    header_starts = []
    for node in bindings:
        if node.attrib.get("header"):
            current_header = node.attrib["header"]
            header_starts.append((node.attrib.get("name", ""), current_header))
        if current_header not in {"POCKETREALMPAD", "POCKETREALMPAD_ADVANCED"}:
            fail("binding appears before a known Essentials or Advanced category")
        categories[node.attrib.get("name", "")] = current_header
    if header_starts != [("PRP_ACTION1", "POCKETREALMPAD"), ("PRP_ACTION5", "POCKETREALMPAD_ADVANCED")]:
        fail(f"binding categories must start once, in beginner-first order: {header_starts!r}")
    actual_essential = {name for name, header in categories.items() if header == "POCKETREALMPAD"}
    if actual_essential != essential:
        fail(f"essential binding category mismatch: {sorted(actual_essential ^ essential)!r}")
    if len(categories) - len(actual_essential) != len(bindings) - len(essential):
        fail("advanced binding category count mismatch")

    expected_run_on_up = {f"PRP_ACTION{i}" for i in range(1, 13)}
    expected_run_on_up.update({"PRP_MOD_SHIFT", "PRP_MOD_CTRL", "PRP_MOD_ALT", "PRP_MOD_BANK"})
    expected_run_on_up.update({f"PRP_NAV_{direction}" for direction in ("UP", "DOWN", "LEFT", "RIGHT")})
    expected_run_on_up.add("PRP_QUICK_MENU")
    expected_run_on_up.update({f"PRP_PET_ACTION{i}" for i in range(1, 11)})
    actual_run_on_up = {node.attrib["name"] for node in bindings if node.attrib.get("runOnUp") == "true"}
    if actual_run_on_up != expected_run_on_up:
        fail(f"runOnUp binding set mismatch: {sorted(actual_run_on_up ^ expected_run_on_up)!r}")

    required = {
        *[f"PRP_ACTION{i}" for i in range(1, 13)],
        *[f"PRP_STOCK_PAGE{i}" for i in range(1, 7)],
        *[f"PRP_PET_ACTION{i}" for i in range(1, 11)],
        *[f"PRP_FORM_ACTION{i}" for i in range(1, 11)],
        *[f"PRP_RAID_MARK_{i}" for i in range(1, 9)],
        "PRP_RAID_MARK_CLEAR",
        "PRP_INVENTORY",
        "PRP_COMPANION",
        "PRP_QUICK_MENU",
        "PRP_CHAT",
        "PRP_CHAT_SLASH",
    }
    missing = sorted(required - set(names))
    if missing:
        fail(f"required binding names missing: {missing!r}")

    locale = (ROOT / "Locale.lua").read_text(encoding="utf-8")
    if 'BINDING_HEADER_POCKETREALMPAD_ADVANCED = "Pocket Realm Pad — Advanced"' not in locale:
        fail("advanced binding category localization missing")
    for name in names:
        if f"BINDING_NAME_{name} =" not in locale:
            fail(f"missing localized name for {name}")

    catalog = ROOT / "tests" / "binding_catalog.tsv"
    rows = [line for line in catalog.read_text(encoding="utf-8").splitlines()[1:] if line]
    if len(rows) != 99:
        fail("generated project binding catalog must contain 99 rows")


def check_stock_catalog() -> None:
    path = ROOT / "tests" / "stock_binding_catalog.tsv"
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines or lines[0].strip() != "count 228":
        fail("stock binding catalog must identify 228 WoW 1.12 bindings")
    if len([line for line in lines[1:] if line.strip()]) != 228:
        fail("stock binding catalog row count is not 228")
    groups = Counter(line.split()[1] for line in lines[1:] if line.strip())
    expected = {
        "MOVEMENT": 15,
        "CHAT": 11,
        "ACTIONBAR": 54,
        "TARGETING": 21,
        "INTERFACE": 26,
        "MISC": 18,
        "CAMERA": 18,
        "MULTIACTIONBAR": 12,
        "BLANK": 12,
        "BLANK2": 12,
        "BLANK3": 12,
        "RAID_TARGET": 12,
        "ITUNES_REMOTE": 5,
    }
    if dict(groups) != expected:
        fail(f"stock binding group counts changed: {dict(groups)!r}")


def check_lua(files: list[str]) -> None:
    combined_text: list[str] = []
    for rel in files:
        path = ROOT / rel
        text = path.read_text(encoding="utf-8")
        combined_text.append(text)
        code = strip_lua_comments_and_strings(text)
        if "[[" in code or "]]" in code:
            fail(f"{rel}: long bracket syntax is outside this compatibility subset")
        if "#" in code:
            fail(f"{rel}: Lua 5.1 length operator '#' found; use table.getn")
        if re.search(r"(?<![<>=~])%(?![=])", code):
            fail(f"{rel}: modulo operator '%' found; use math.mod for Lua 5.0")
        for label, pattern in FORBIDDEN_TOKENS.items():
            match = pattern.search(code)
            if match:
                line = code.count("\n", 0, match.start()) + 1
                fail(f"{rel}:{line}: forbidden {label}: {match.group(0)!r}")

    combined = "\n".join(combined_text)
    required_api = (
        "UseAction(",
        "TargetNearestEnemy(",
        "GetContainerItemInfo(",
        "ChatFrame_OpenChat(",
        "GetBindingKey(",
        "CooldownFrame_SetTimer(",
        "CastPetAction(",
        "ShapeshiftBar_ChangeForm(",
        "SetRaidTargetIcon(",
        "SetRaidTarget(\"target\", 0)",
        "ChangeActionBarPage(",
        "GetBonusBarOffset(",
    )
    for token in required_api:
        if token not in combined:
            fail(f"expected 1.12 API use not found: {token}")

    action = (ROOT / "ActionBar.lua").read_text(encoding="utf-8")
    if "NUM_ACTIONBAR_PAGES or 6" not in action or "NUM_ACTIONBAR_BUTTONS or 12" not in action:
        fail("Vanilla action constants with 6/12 fallbacks are missing")
    if "index + ((page - 1) * buttons)" not in action:
        fail("ordinary 1-72 slot formula missing")
    if "index + ((pages + offset - 1) * buttons)" not in action:
        fail("Vanilla bonus-action slot formula missing")
    if "if page ~= 1 then" not in action:
        fail("bonus actions must be restricted to semantic page 1")
    for profile in ("COMPACT_540", "LEGACY_600", "HANDHELD_720", "HANDHELD_800", "HANDHELD_900", "RP6_1080", "HANDHELD_1200", "HANDHELD_1440", "TABLET", "ANDROID_LARGE"):
        if profile not in combined:
            fail(f"responsive display profile missing: {profile}")
    for adapter in (
        "BankCloseButton", "ClassTrainerSkill", "ClassTrainerTrainButton",
        "TradeSkillSkill", "TradeSkillCreateButton", "CraftCreateButton",
        "AuctionFrameTab", "BrowsePrevPageButton", "BrowseNextPageButton",
        "MailFrameCloseButton", "SendMailMailButton", "OpenMailLetterButton",
        "OpenMailPackageButton", "OpenMailMoneyButton",
        "QuestFramePushQuestButton", "QuestFrameExitButton", "QuestLogCollapseAllButton",
        "TradeFrameTradeButton", "TradeFrameCloseButton",
        "TaxiButton", "TaxiCloseButton",
    ):
        if adapter not in combined:
            fail(f"explicit Vanilla panel adapter evidence missing: {adapter}")
    unsafe_controller_nodes = (
        "CharacterHeadSlot", "QuestLogFrameAbandonButton", "TalentFrameTalent",
        "CraftReagent", "TradeSkillReagent", "TradeRecipientItem", "TradePlayerItem",
        "BankFrameItem", "BankFrameBag", "BankFramePurchaseButton",
        "SendMailPackageButton", "SpellButton",
        "OpenMailDeleteButton", "AuctionsCancelAuctionButton",
        "GameMenuButtonLogout", "GameMenuButtonQuit",
    )
    adapters_text = (ROOT / "Adapters.lua").read_text(encoding="utf-8")
    profile_text = (ROOT / "Profile.lua").read_text(encoding="utf-8")
    for node_name in unsafe_controller_nodes:
        if node_name in adapters_text:
            fail(f"novice-risk controller focus node must remain touch-only: {node_name}")

    confirmation_phrases = (
        "Complete this quest with the selected reward",
        "Buy this item", "Buy back this item",
        "Pay to repair one item", "Pay to repair all items",
        "Pay to learn this skill",
        "Use materials to create this item",
        "Accept this trade", "Send this mail",
        "Place this bid", "Buy this auction now",
        "Post this auction and pay its deposit",
        "Pay for this flight",
    )
    for phrase in confirmation_phrases:
        if phrase not in adapters_text:
            fail(f"novice double-confirmation text missing: {phrase}")

    focus_text = (ROOT / "Focus.lua").read_text(encoding="utf-8")
    for token in ("pendingConfirmFrame", "confirmSeconds", "Press [", "Action cancelled"):
        if token not in focus_text and token != "confirmSeconds":
            fail(f"focus confirmation behavior missing: {token}")
    if "if force then" not in focus_text or "self:ClearPendingConfirm(false)" not in focus_text:
        fail("forced panel refresh must cancel an armed destructive confirmation")
    if "confirmSeconds = 4.0" not in profile_text:
        fail("panel confirmation window must be four seconds")

    for retail_mail_name in ("SendMailAttachment", "OpenMailAttachmentButton"):
        if retail_mail_name in combined:
            fail(f"retail-style mail control leaked into Vanilla adapter: {retail_mail_name}")

    for invalid_vanilla_name in (
        "QuestLogFrameTrackButton",
        "QuestLogFramePushQuestButton",
        "QuestLogFrameCancelButton",
        "TaxiFrameCloseButton",
    ):
        if invalid_vanilla_name in combined:
            fail(f"nonexistent 1.12 FrameXML control leaked into adapter: {invalid_vanilla_name}")

    if "schema = 5" not in profile_text or "showSlotNumbers = 0" not in profile_text:
        fail("v0.5 RP6 newcomer defaults are missing")
    if "sellConfirmSeconds = 5.0" not in profile_text:
        fail("merchant-sale confirmation window must be five seconds")
    if 'PRP_PROFILE_ID = "retroid-pocket-6-stick-top-v5"' not in profile_text:
        fail("RP6 stick-top profile identifier is missing")
    for token in ('confirm = "A"', 'back = "B"', 'face = { "A", "B", "Y", "X" }'):
        if token not in profile_text:
            fail("RP6 mapping must preserve printed A-confirm/B-back positions")
    for token in ('target = "M1"', 'targetFallback = "L3"', 'jump = "M2"', 'jumpFallback = "R3"', 'self = "UNBOUND"'):
        if token not in profile_text:
            fail("RP6 rear-button primary controls and safe fallbacks are incomplete: " + token)
    action_text = (ROOT / "ActionBar.lua").read_text(encoding="utf-8")
    if "return index + 4" not in action_text or "function PRP_ActionBar:GetInputSemantic" not in action_text:
        fail("R1 face bank must resolve abilities 5-8 at key-down")
    router_text = (ROOT / "Router.lua").read_text(encoding="utf-8")
    for token in ('if direction == "UP" then return 9 end', 'if direction == "DOWN" then return 10 end', 'if direction == "LEFT" then return 11 end', 'if direction == "RIGHT" then return 12 end'):
        if token not in router_text:
            fail("RP6 lower D-pad must carry less-frequent world abilities 9-12")
    expected_priority = ("CHAT", "MODAL", "GUIDE", "QUICK", "INVENTORY", "COMPANION", "FOCUS", "WORLD")
    positions = [router_text.find(f'return "{name}"') for name in expected_priority]
    if any(pos < 0 for pos in positions) or positions != sorted(positions):
        fail("semantic context priority is not chat > modal > guide > quick > inventory > companion > focus > world")
    for shortcut in ("QuickMenuKey", "InventoryKey", "CompanionKey"):
        match = re.search(rf"function PRP_Router:{shortcut}\([^)]*\)(.*?)(?=\nfunction PRP_Router:|\Z)", router_text, re.S)
        if not match or "PRP_ChatEditActive()" not in match.group(1):
            fail(f"chat must suppress the {shortcut} shortcut")
    slash_text = (ROOT / "Slash.lua").read_text(encoding="utf-8")
    if "D-pad uses abilities 9-12 in the world" not in slash_text or "D-pad uses abilities 5-8 in the world" in slash_text:
        fail("player-facing D-pad status must match RP6 actions 9-12")
    quick_menu_text = (ROOT / "QuickMenu.lua").read_text(encoding="utf-8")
    if 'if state == "down" then' not in quick_menu_text or 'self:Toggle()' not in quick_menu_text:
        fail("quick menu must use a simple press-to-toggle interaction")
    if "holdThreshold" in quick_menu_text or "movedWhileHeld" in quick_menu_text:
        fail("hidden quick-menu hold timing must not remain in the interaction path")
    ui_text = (ROOT / "UI.lua").read_text(encoding="utf-8")
    if "function PRP_UI:SetFocus(frame, label, showPrompt)" not in ui_text:
        fail("custom surfaces must be able to suppress the duplicate global prompt")
    if 'self:SetPrompt("")' not in ui_text:
        fail("clearing focus must also clear the global prompt")
    inventory_text = (ROOT / "Inventory.lua").read_text(encoding="utf-8")
    if 'PocketRealmPadDB.debug == 1' not in inventory_text or 'cell.bagText:SetText("")' not in inventory_text:
        fail("raw bag/slot coordinates must be hidden outside debug mode")
    if 'function PRP_Inventory:GetBagLabel' not in inventory_text or 'if arg1 == "RightButton" then PRP_Inventory:Accept() end' not in inventory_text:
        fail("inventory must use friendly bag labels and make a normal touch select-only")
    vanilla_actions_text = (ROOT / "VanillaActions.lua").read_text(encoding="utf-8")
    for direct_helper in ("PageCommand", "PetKey", "Form", "RaidMarker", "Helper"):
        match = re.search(rf"function PRP_VanillaActions:{direct_helper}\([^)]*\)(.*?)(?=\nfunction PRP_VanillaActions:|\Z)", vanilla_actions_text, re.S)
        if not match or "PRP_ChatEditActive()" not in match.group(1):
            fail(f"chat must suppress direct advanced helper {direct_helper}")
    companion_text = (ROOT / "Companion.lua").read_text(encoding="utf-8")
    if 'button.count:SetText("")' not in companion_text or 'self.emptyText:Show()' not in companion_text:
        fail("companion panel must avoid raw index clutter and provide an empty state")

    guide_text = (ROOT / "Guide.lua").read_text(encoding="utf-8")
    if "pageCount = 5" not in guide_text:
        fail("first-run guide must remain five short progressive pages")
    for phrase in ("Move, look, and choose a target", "Use abilities without a crowded screen", "Menus and bags", "A simple first adventure"):
        if phrase not in guide_text:
            fail(f"first-run guide section missing: {phrase}")

    core = (ROOT / "Core.lua").read_text(encoding="utf-8")
    for event_name in (
        "BANKFRAME_OPENED", "BANKFRAME_CLOSED", "TRAINER_SHOW", "TRAINER_CLOSED",
        "CRAFT_SHOW", "CRAFT_CLOSE", "TRADE_SKILL_SHOW", "TRADE_SKILL_CLOSE",
        "TRADE_SHOW", "TRADE_CLOSED", "MAIL_SHOW", "MAIL_CLOSED",
        "AUCTION_HOUSE_SHOW", "AUCTION_HOUSE_CLOSED", "TAXIMAP_OPENED", "TAXIMAP_CLOSED",
    ):
        if f'RegisterEvent("{event_name}")' not in core:
            fail(f"panel refresh event not registered: {event_name}")



def check_docs() -> None:
    required_docs = (
        "README.md", "ANDROID_QUICK_START.md", "WINLATOR_PROFILE.md",
        "INTEGRATION.md", "NOVICE_UX_AUDIT.md", "RP6_STICK_TOP_CONTROL_STUDY.md",
        "HANDHELD_RESOLUTION_DESIGN.md", "RESEARCH_SOURCES.md",
    )
    combined = "\n".join((ROOT / name).read_text(encoding="utf-8") for name in required_docs)
    for token in (
        "Retroid Pocket 6 Stick Top", "right A", "bottom B", "left Y", "top X",
        "R1 +", "abilities 5–8", "abilities 9–12", "M1", "M2", "L3", "R3",
        "physical position", "rear buttons", "touch",
    ):
        if token not in combined:
            fail(f"RP6 documentation requirement missing: {token}")
    forbidden = (
        "D-pad | Abilities 5 / 6 / 7 / 8",
        "R1 + A/B/Y/X | Abilities 9 / 10 / 11 / 12",
        "R3 maps directly to stock `JUMP`",
        "L3 is a high-frequency targeting action",
    )
    for phrase in forbidden:
        if phrase in combined:
            fail(f"stale pre-RP6 control documentation remains: {phrase}")
    for phrase in (
        "R1 + A/B/Y/X | Abilities 5 / 6 / 7 / 8",
        "D-pad | Abilities 9 / 10 / 11 / 12",
    ):
        if phrase not in combined:
            fail(f"current RP6 control documentation missing: {phrase}")

def main() -> None:
    files = read_toc_files()
    check_bindings()
    check_stock_catalog()
    check_lua(files)
    check_docs()
    print("STATIC PASS: 17 Lua modules, 99 project bindings, 228 stock bindings audited")


if __name__ == "__main__":
    main()
