# Radically Improving CMaNGOS Playerbots

## Architecture, behaviour, scaling and Snapdragon 8 Gen 2 feasibility study

**Target:** Offline Vanilla WoW 1.12.1 realm on a Snapdragon 8 Gen 2 Android device  
**Population objective:** approximately 500 simultaneously present Playerbots while preserving responsive human play  
**Research date:** 1 August 2026  
**Public code revisions:** Playerbots `b4f6148799802f50535e5535d235b46bf024021c`; CMaNGOS Classic `de8f72993b9e1faa1bf92dd5505f3daec5cea3ce`

> **Scope statement.** This report examines public repositories, permanent commit-specific source links, public issues, documentation, community reports, videos and primary technical literature. It does not claim access to, or inspection of, any private fork. Performance claims that lack a reproducible build, workload description and tick data are treated as anecdotes rather than benchmarks.

# 1. Executive summary

## Decision

The strongest future architecture is an **event-driven, deadline-scheduled hierarchical utility system with shared party blackboards and deterministic tactical solvers**, while retaining the mature Playerbots action library and CMaNGOS integration. The present trigger/strategy/action framework should be treated as a valuable action-and-domain-knowledge layer, not as the final orchestration architecture.

The first work should not be neural. It should be a measurement and scheduling prototype that repairs a source-proven update-path defect, replaces random/coarse activity gating with deterministic deadlines, and attributes world-tick cost to concrete Playerbots subsystems. At the pinned revisions, `Map.cpp` calculates a per-bot `minimal` update flag, but `Player::UpdateAI(diff, minimal)` calls `PlayerbotAI::UpdateAI(diff)` without forwarding that flag. PlayerbotAI itself supports the flag. This likely disables an intended temporal-level-of-detail mechanism at the core/module boundary. The defect is verified by source; its performance impact is not known until measured. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp) [C02](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h)

## Ten decision-ready findings

1. **The current AI is not merely “scripted.”** It combines a four-state finite-state controller, reactive trigger rules, composable strategies, utility/relevance ranking, multiplicative scoring modifiers, and small action graphs made from prerequisites, alternatives and continuers. It is a sophisticated reactive utility architecture, but not a general planner, behaviour tree, learned policy or shared multi-agent reasoning system. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp)

2. **Its strongest asset is mature domain knowledge.** The public code contains class/spec strategy composition, spell legality checks, target filters, projected damage and threat logic, heal cancellation, cure triggers, crowd-control filters, travel, quest, dungeon and battleground behaviours, plus a broad command surface. Replacing all of this would be unnecessarily risky. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp) [C26](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp) [C27](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/BattleGroundTactics.cpp) [C28](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp)

3. **Its largest behavioural limitation is the absence of general party intent and reservations.** Bots can inspect group state and sometimes share target-related values, but the examined architecture has no general party blackboard that assigns and reserves heals, interrupts, dispels, crowd control, pulls, tank targets or positions. Many locally sensible decisions can therefore collide or duplicate. This conclusion is an architectural inference from the examined public code, not a proof that every encounter fails. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp)

4. **The hot path performs repeated per-bot orchestration.** Active strategies scan trigger nodes, default actions are repopulated, a linear priority queue is searched, action nodes are dynamically created/deleted, and named Values are retrieved through strings, maps and runtime casts. Shared-value integration is commented out in `AiObjectContext`; its general update pass is also disabled with a source comment that it consumed approximately 8% CPU while doing no useful work. These are verified implementation properties; their relative cost at 500 bots requires profiling. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C05](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp) [C07](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/NamedObjectContext.h) [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)

5. **The core still updates Player objects every world tick.** CMaNGOS has bot-aware map/cell activity reduction, but Player updates remain in the main map update path. Bot count alone is therefore a poor workload descriptor: 500 remote travelling bots, 500 human-visible questers and 500 bots concentrated in combat are materially different loads. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp)

6. **The Intel N100 “about 500 bots” reference is not an established benchmark.** A public administrator report identifies a BMAX B4 Plus with an N100, Windows 11 Pro, 16 GB single-channel DDR4-2666 and a 512 GB M.2 SSD. The same user said approximately 500 SPP Classic Vanilla bots were “doing okay,” while 1,000 led to prolonged 100% CPU and an unplayable server. No exact CMaNGOS/Playerbots revision, active/idle split, bot configuration, database version, tick histogram, temperature, clock trace or memory measurement was provided. Treat it as a useful reference point and test design prompt, not proof. [I08](https://www.reddit.com/r/wowservers/comments/1dk82zr/server_performance_hardware/) [I09](https://www.reddit.com/r/MiniPCs/comments/1eftys5/n100_performance_less_than_expected/) [H01](https://www.intel.com/content/www/us/en/products/sku/231803/intel-processor-n100-6m-cache-up-to-3-40-ghz/specifications.html)

7. **The Snapdragon target is plausible only with workload-aware fidelity.** Approximately 500 simultaneously present bots is technically credible as a target when most are remote/background bots using event wakeups and coarse simulation, with full fidelity reserved for human-visible, party, combat, dungeon and PvP bots. Five hundred simultaneously concentrated, fully tactical bots is not established as credible. Mobile sustained frequency, thermals, memory bandwidth, Android overhead, ARM compiler quality and device cooling must be measured directly; desktop aggregate benchmarks are insufficient. [H02](https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Snapdragon-8-Gen-2-Product-Brief.pdf)

8. **The best scalability gains are architectural, not “make every bot think more slowly.”** Shared scoped perception, event-driven dirty-state updates, deterministic staggered deadlines, hierarchical decision frequencies, route/path reuse, party-level reservations and data-oriented hot state can reduce repeated work while preserving visible behaviour. Inert logged-in characters must not be counted as fully simulated bots.

9. **The Snapdragon NPU has a narrow possible role, not a general AI role.** QNN/Qualcomm AI Engine Direct can target the Hexagon NPU from native code, and the Snapdragon 8 Gen 2 supports low-precision inference. A worthwhile candidate is occasional batched scoring of a compact tactical state vector for target priority, danger/position class or high-level intent. The NPU should not own legality, pathfinding, world queries, movement, database work or language generation. End-to-end extraction, batching, wake-up, synchronization, validation and thermal cost must beat both a deterministic CPU scorer and a tiny CPU neural policy. [H02](https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Snapdragon-8-Gen-2-Product-Brief.pdf) [H05](https://www.qualcomm.com/developer/software/qualcomm-ai-engine-direct-sdk) [H06](https://developers.google.com/edge/litert/next/qualcomm) [H07](https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html)

10. **Language models belong outside the game loop.** `PlayerbotLLMInterface` implements network/TLS and response-handling machinery for generated text and explicitly frames generation as asynchronous and intentionally delayed. A local compact model may add optional, infrequent social flavour, but should run in a separate worker or process, have a strict thermal/load budget and never influence combat, movement or correctness. On this device, it should be disabled whenever it competes with world-tick headroom. [C29](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLLMInterface.cpp)

## Recommended outcome by layer

| Layer | Recommendation | Why |
|---|---|---|
| CMaNGOS legality and execution | Retain and strengthen deterministic gates | Exact range, line of sight, cooldown, resources, threat ownership and command obedience must be reproducible and safe. |
| Existing Playerbots Actions | Retain most actions and class-specific spell knowledge | This is the highest-value accumulated domain knowledge. |
| Perception | Replace repeated per-bot queries with versioned scoped snapshots and event-driven dirty sets | Reduces duplicate object/group/threat/LOS work and creates a testable state interface. |
| Scheduling | Replace random/coarse gating with deterministic deadlines, event wakeups and workload classes | Makes quality predictable and reserves CPU for human-visible work. |
| Coordination | Add a party/raid blackboard with expiring reservations and explicit intent | Prevents duplicate heals, interrupts, dispels, CC and positional conflicts. |
| High-level behaviour | Use hierarchical utility and bounded task plans | Retains flexibility without unconstrained per-tick planning cost. |
| Tactical positioning | Add deterministic formation, hazard and line-of-sight solvers | Directly addresses visible movement and accidental-pull failures. |
| Learned component | Optional advisory scorer after deterministic candidate generation | Useful only if held-out behaviour and end-to-end cost beat a simple CPU model. |
| NPU | Optional batched accelerator for that tiny scorer only | It cannot remove world-query or pathfinding cost and may not amortize overhead. |
| LLM | Optional social subsystem outside world ticks | Dialogue value is separable from simulation correctness. |

# 2. Sources and exact public revisions examined

## 2.1 Pinned revisions

| Repository | Revision examined | Public date / note | Use in this report |
|---|---|---|---|
| `cmangos/playerbots` | `b4f6148799802f50535e5535d235b46bf024021c` [R01](https://github.com/cmangos/playerbots/commit/b4f6148799802f50535e5535d235b46bf024021c) | 30 July 2026; commit message “Fix warstomp useful in pve (#345)” | All Playerbots source-code findings use commit-specific links at this SHA. |
| `cmangos/mangos-classic` | `de8f72993b9e1faa1bf92dd5505f3daec5cea3ce` [R02](https://github.com/cmangos/mangos-classic/commit/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce) | 18 June 2026 | All CMaNGOS Classic source-code findings use commit-specific links at this SHA. |
| `cmangos/issues` | current rendered merge page abbreviated as `6b7ea32`; downloadable patch exposed full content commit `c5970a7babb6724bcbeeb19932b55785ab301c20` [R03](https://github.com/cmangos/issues/commit/c5970a7babb6724bcbeeb19932b55785ab301c20) [R04](https://github.com/cmangos/issues/commit/6b7ea32) | Retrieved 1 August 2026 | Used as an issue-tracker snapshot. The exact full merge SHA was not exposed by the rendered page, so this report records both identifiers rather than inventing a full hash. |

The starting repositories were the public repositories specified in the request. No private source, binary, database or runtime trace was available.

## 2.2 Evidence labels

| Label | Meaning | How it is used |
|---|---|---|
| **Verified** | Directly established by the pinned public source or primary official documentation | Statements such as function calls, default configuration values and data structures. |
| **Inference** | Reasoned consequence of verified control/data flow | For example, duplicated per-bot caches are likely to increase memory and query work. |
| **Profiling hypothesis** | Plausible hotspot or stall mechanism whose magnitude is unknown | Must be accepted or rejected by instrumentation on the target build. |
| **Community evidence** | Public report, issue, guide or demonstration | Recorded with project, expansion, date/relevance and confidence; not treated as code proof. |
| **User-provided reference** | Claim supplied in the problem or traceable only to uncontrolled reports | The N100 500-bot point remains in this category. |
| **Unknown** | Cannot be established without the private fork, its configuration, database or physical device | Listed explicitly in section 14. |

## 2.3 Coverage

The source audit covered the per-bot update path, four Engines, Queue, Actions, Triggers, Strategies, Multipliers, Values and caches; class-specific strategy creation; random-bot management; login and character generation; travel, pathfinding and movement actions; target, heal, threat, cure and crowd-control logic; dungeon and battleground code; human-command dispatch; PerformanceMonitor; and PlayerbotLLMInterface. Core integration was traced through CMaNGOS `Map.cpp` and `Player.cpp`. Key files are linked throughout and catalogued at the end of this report. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C03](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIBase.cpp) [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C05](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp) [C06](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Value.h) [C07](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/NamedObjectContext.h) [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp) [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C11](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PerformanceMonitor.cpp) [C12](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp) [C13](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLoginMgr.cpp) [C14](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotMgr.cpp) [C15](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotFactory.cpp) [C16](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotFactory.cpp) [C17](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/TravelMgr.cpp) [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp) [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp) [C24](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/ChooseTargetActions.cpp) [C25](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/generic/CombatStrategy.cpp) [C26](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp) [C27](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/BattleGroundTactics.cpp) [C28](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp) [C29](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLLMInterface.cpp) [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp)

Community research included current and historical CMaNGOS issues, CMaNGOS/SPP administrator reports, Reddit discussions, related AzerothCore Playerbots documentation, raid guides and demonstrations. Findings from other forks are explicitly marked as cross-project evidence and are not merged into the CMaNGOS Classic findings. [I01](https://github.com/cmangos/issues/issues/4104) [I03](https://github.com/cmangos/issues/issues/4064) [I04](https://github.com/cmangos/issues/issues/4016) [I05](https://github.com/cmangos/issues/issues/3886) [I07](https://github.com/cmangos/issues/issues/2186) [I10](https://www.reddit.com/r/wowservers/comments/1jh63c4/azerothcore_vs_cmangos_playerbots/) [I11](https://www.reddit.com/r/wowservers/comments/1kt0k8a/try_single_player_project_seriously/) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) [I14](https://github.com/mod-playerbots/mod-playerbots) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide) [I20](https://www.youtube.com/watch?v=CIxrmZ1V6_U) [I21](https://www.youtube.com/watch?v=uEjzLv9RRD4) [I23](https://www.youtube.com/watch?v=3W2dvB1pDIg) [I24](https://www.youtube.com/watch?v=Bca-RGbQAEw)

## 2.4 What the N100 evidence does and does not establish

| Attribute | Publicly reported | Missing for a controlled comparison |
|---|---|---|
| CPU | Intel N100, 4 cores / 4 threads, up to 3.4 GHz; official 6 W base-power specification [H01](https://www.intel.com/content/www/us/en/products/sku/231803/intel-processor-n100-6m-cache-up-to-3-40-ghz/specifications.html) | Sustained clock, cooling, package power and per-core utilization during the run |
| System | BMAX B4 Plus; Windows 11 Pro; 16 GB single-channel DDR4-2666; 512 GB M.2 SSD [I09](https://www.reddit.com/r/MiniPCs/comments/1eftys5/n100_performance_less_than_expected/) | BIOS power limits, background services, exact storage/database latency |
| Server | SPP Classics Vanilla; approximately 500 bots “doing okay”; 1,000 reportedly caused prolonged 100% CPU and became unplayable [I08](https://www.reddit.com/r/wowservers/comments/1dk82zr/server_performance_hardware/) [I09](https://www.reddit.com/r/MiniPCs/comments/1eftys5/n100_performance_less_than_expected/) | CMaNGOS and Playerbots SHAs, configuration, database version, compiler, active-versus-idle distribution, zone concentration |
| Metrics | Subjective playability and CPU saturation statement | World-tick median/p95/p99, AI subsystem time, RSS, path requests, DB waits, temperature and energy |
| Conclusion | Useful anecdotal reference and stress-test target | Not independently verifiable as a benchmark and not transferable directly to Snapdragon |

# 3. Current Playerbots architecture

## 3.1 Complete per-bot decision loop

![Figure 1. Per-bot decision pipeline at the pinned public revisions.](images/figure_1_per_bot_pipeline.png)

*Figure 1. Per-bot decision pipeline at the pinned public revisions.*

The loop begins with exact server state and packet-derived events. `PlayerbotAI` registers handlers for master packets, bot outgoing packets, world packets, group invitations, quest updates, loot, casts, movement and other events. It also polls state through named Values. The constructor creates a per-bot `AiObjectContext` and four Engines: combat, non-combat, dead and reaction. The reaction Engine is evaluated before the current-state Engine. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp)

Within an Engine, active Strategies contribute TriggerNodes, Multipliers and default actions for a particular state. On a decision pass, the Engine updates context, evaluates triggers, pushes triggered and default actions into a relevance queue, tests usefulness, applies Multipliers, may requeue an action if its score changes, expands prerequisites, checks possibility, executes the action, and adds continuers or alternatives depending on success. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp)

Action execution calls deterministic CMaNGOS systems: spells, targeting, threat, movement, PathFinder, MotionMaster, inventory, sessions and database-related lifecycle operations. Resulting world state and packets become subsequent inputs. The architecture therefore has a genuine feedback loop, but its planning horizon is mostly one decision plus a small prerequisite/alternative/continuer graph.

## 3.2 Exactly what kind of AI it implements

| Technique | Present? | Evidence and interpretation |
|---|---|---|
| Finite-state control | **Yes** | Four explicit bot states select combat, non-combat, dead or reaction Engines. This is a small mode/state machine. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C02](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h) |
| Reactive rule system | **Yes** | Triggers detect conditions and add actions with relevance values. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) |
| Strategy composition | **Yes** | Multiple class, role, environment and activity Strategies are composed for each state. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) |
| Utility AI | **Yes, in a practical form** | Candidate actions are ordered by relevance and modified by Multipliers; usefulness and possibility act as filters. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C05](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp) |
| Action graph | **Limited** | Prerequisites, alternatives and continuers produce a local graph around a candidate action. This is not open-ended search. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) |
| Behaviour tree | **No general BT found** | Strategy/trigger/action composition can resemble selectors and conditions, but the examined control structure is not a tree ticked from a root. |
| GOAP / HTN | **No general planner found** | There is no examined generic search over world-state operators or task decompositions in the per-tick tactical loop. |
| Shared multi-agent planning | **Partial, not general** | Bots query group members, role information and sometimes other bots’ target values, but no general reservation/intent blackboard was found. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) |
| Learned policy | **No correctness-critical learned policy found** | Public combat, movement and tactical selection are deterministic/rule/utility based. PlayerbotLLMInterface is separate text-generation infrastructure. [C29](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLLMInterface.cpp) |

Calling the system “scripted” is therefore incomplete. A more accurate description is: **a composable reactive utility system inside a finite-state mode controller, backed by deterministic game-specific actions and caches**.

## 3.3 AI update scheduling

`PlayerbotAIBase` maintains an internal delay and only performs a decision when the delay falls below its threshold. A normal yield uses the configured reaction delay; a minimal yield multiplies that delay by ten. At the pinned configuration defaults, `reactDelay` is 100 ms, `passiveDelay` is 4,000 ms, `maxWaitForMove` is 3,000 ms, and `iterationsPerTick` is 100. These are defaults in public source, not measured optimal settings for Snapdragon. [C03](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIBase.cpp) [C10](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIConfig.cpp)

`PlayerbotAI::UpdateAI(elapsed, minimal)` performs housekeeping, movement/loot checks, combat wakeups and reaction handling before invoking the current Engine. It includes cast time, the reaction delay and the world’s average diff when setting action delay. The packet-handling helper protects its queue with a mutex; handling uses `try_lock`, while producers take the lock. This is verified. Whether it creates material contention is a profiling hypothesis. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp)

CMaNGOS `Map.cpp` periodically identifies zones containing visible non-AFK real players and computes whether bot work should be reduced. It passes `!shouldUpdateBot` into `Player::UpdateAI(diff, minimal)`. However, pinned `Player.cpp` calls `m_playerbotAI->UpdateAI(diff)` and discards `minimal`. This is the most important source-level integration finding in the study. It does not prove a specific speedup, but it invalidates assumptions that the intended PlayerbotAI minimal-update path is working end to end. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp) [C02](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h)

The same map loop still calls `Player::Update` for every Player each tick. Cell/object visitation can be reduced away from humans, but the Player entity and session path remain. A high-population design must therefore reduce bot-AI and query work without assuming remote bots disappear from core cost. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp)

## 3.4 Engine, Queue, Action, Trigger, Strategy and Multiplier

The Engine is the orchestration centre. Its current cost model includes:

- scanning TriggerNodes for active Strategies;
- resetting trigger state after evaluation;
- pushing default actions on each decision pass;
- creating candidate action nodes;
- finding the highest relevance in the Queue;
- testing usefulness and possibility;
- applying every active Multiplier;
- expanding prerequisites, alternatives and continuers;
- executing at most the configured iteration limit.

The Queue implementation performs a linear duplicate scan on push and a linear maximum search on peek. The absolute queue sizes are not established in this report, so asymptotic complexity alone is not evidence of a bottleneck. It is, however, a clear target for queue-size and allocation instrumentation. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C05](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp)

Actions provide virtual interfaces for execution, possibility and usefulness, and can return prerequisite, alternative and continuer actions. This produces expressive fallback behaviour without a full planner. The trade-off is dynamic dispatch, string names and transient candidate objects in the hot path.

## 3.5 Values and caches

Values are a major abstraction boundary. They turn raw world state into named facts such as attackers, targets, health conditions, travel state and role information. `CalculatedValue` associates values with a refresh interval; `LazyCalculatedValue` calculates once and retains the result until reset. [C06](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Value.h)

Important source observations are:

1. Values and creators are addressed by strings, stored in ordered maps and often recovered through runtime casting. [C07](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/NamedObjectContext.h)
2. Each bot creates its own `AiObjectContext` containing action, trigger, strategy and value contexts. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)
3. The examined `AiObjectContext` has shared-value context integration commented out. [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)
4. Its general `Update()` body is commented out with a source note that it consumed approximately 8% CPU while doing nothing useful. [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)
5. `CalculatedValue` uses `time(0)` for expiration checks. Because this is second-resolution time, sub-second intervals deserve verification; the source appears to intend finer behaviour for short intervals, but the effective timing must be tested rather than assumed. [C06](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Value.h)

The likely result is duplicated per-bot facts and repeated named lookup overhead, especially when a party observes the same attackers, casts, hazards and nearby objects. That is an inference; heap and call-count profiling must establish the actual cost.

## 3.6 AiFactory and class-specific strategy composition

`AiFactory` selects a class-specific object context, derives role/spec information and composes Strategies. Combat composition includes class/spec behaviour, racials, PvP, dungeon logic, avoidance, pulling, positioning, fleeing, curing, crowd control, area-of-effect logic, pets, buffs and role-assist strategies. Non-combat composition includes class maintenance, food/drink, follow/wander, questing, loot, gathering, travel, group/guild/LFG/battleground activities, fishing, RPG and maintenance. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp)

This is a strength: behaviour is modular and content-rich. It is also a scaling and maintenance challenge because many Strategies can be active simultaneously, expanding the trigger and candidate set. A hierarchical intent layer could activate a smaller relevant subset without deleting class knowledge.

## 3.7 PlayerbotMgr and RandomPlayerbotMgr

`PlayerbotMgr` manages bots associated with a human master, session processing, packet fanout and lifecycle cleanup. `RandomPlayerbotMgr` manages world population, login pacing, random-bot timers, activity scaling and autonomous tasks. [C12](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp) [C14](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotMgr.cpp)

Verified population-related work includes scans over managed bots for session/teleport/logout handling, broad command dispatch that can inspect many bots before filtering, periodic manager work, database liveness checks, and some global ObjectMgr searches. There is also auction-house mirroring protected by a mutex. These operations may be cheap at small populations and bursty at large ones; they require per-operation count and wait-time measurement rather than blanket removal. [C12](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp) [C14](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotMgr.cpp)

Activity priority code distinguishes instances, combat, battlegrounds, proximity to humans and broader map/activity states. `HasPlayerNearby` loops real players known to the random-bot manager and checks map, distance and camera conditions. `AllowActivity` caches decisions for several seconds. This is an early temporal-LOD mechanism, but it is coarse and partly probabilistic. It should evolve into an explicit deadline scheduler backed by a spatial index and immediate event wakeups. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp)

## 3.8 Login and character-generation work

`PlayerbotLoginMgr` loads accounts/characters, fills login queues, can use asynchronous query holders and throttles holder dispatch when database ping is high. Loading and filtering large pools, creating sessions and inserting entities are separate costs; asynchronous query execution does not make the full login path free. [C13](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLoginMgr.cpp)

`PlayerbotFactory` and `RandomPlayerbotFactory` can create and randomize equipment, spells, skills, talents, quests, reputation, bags, money, professions, food, ammunition and consumables, followed by database saves. The README warns that initial bot generation takes time. This is a deliberately heavy transient workload and must be benchmarked separately from steady-state AI. [C15](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotFactory.cpp) [C16](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotFactory.cpp) [C30](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/README.md)

A credible 500-bot result must state whether characters were pre-generated and preloaded, how many logins were allowed per interval, whether asynchronous holders were enabled, and whether the measured period included creation, login, teleport or world insertion.

## 3.9 Travel, movement, navigation and unsticking

`TravelMgr` builds and loads quest/object/location relationships, trainable spell and mount data, route nodes and other world travel information. Some generation paths launch per-map asynchronous work and then wait; global partition coordination uses synchronization. Generated travel data can also write to the world database. Startup/precomputation and steady-state route use must therefore be measured separately. [C17](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/TravelMgr.cpp)

Movement Actions combine route-level travel with local movement. `MoveNear` samples candidate angles and checks line of sight. Long movement can use the TravelNodeMap; local movement constructs a core `PathFinder`. Away from humans, movement includes a reduced-fidelity path that can advance or teleport along a stored route when visibility constraints allow. [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp)

The code contains extensive special cases for following, hazards, transports, taxi, jumping and stuck recovery. The volume of special cases is evidence of a difficult domain, not proof of poor quality. Community and issue evidence nevertheless consistently identifies pathing, roads, town sticking, flight transitions and follow crashes as visible failure modes across versions and forks. [I01](https://github.com/cmangos/issues/issues/4104) [I05](https://github.com/cmangos/issues/issues/3886) [I07](https://github.com/cmangos/issues/issues/2186) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/)

## 3.10 Combat targeting, healing, threat, interrupts, dispels and crowd control

The combat layer is materially more capable than a fixed rotation script:

- Generic spell actions check spell availability, target, range, line of sight, castability, aura state and related legality. [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp)
- Health triggers estimate incoming damage, can pre-heal, detect area-heal conditions and cancel inefficient heals when the target is already healthy relative to the predicted heal. [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp)
- Generic triggers model resource thresholds, projected threat bands, aggro loss, outnumbering, interruptibility and role-assist conditions. [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp)
- Cure triggers select party members by dispel type. [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp)
- Crowd-control target selection filters current targets, raid icons, low-health enemies, damaged/dotted units and unsuitable spell targets. [C26](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp)
- Attackers are assembled from the bot, group, master, pets and possible-target Values, with threat, PvP, evade and distance checks. An optional `shareTargets` path can reuse a nearby bot’s cached attackers value. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp)

The limitations are chiefly coordination and representation. Individual bots decide from overlapping facts, but there is no general “interrupt assigned to bot X until time Y,” “heal reserved for target Z,” or “CC slot owned by mage A” structure in the examined code. A party blackboard would make those commitments explicit, debuggable and reusable.

## 3.11 Tank, healer and DPS coordination

Role inference and tank/DPS assist Strategies are present. Threat triggers avoid some inappropriate taunts and use projected threat bands. Healers can anticipate damage and cancel wasteful casts. DPS target selection can respect raid icons and assist targets. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp)

What is missing is a first-class group plan. Present coordination tends to emerge from shared targets, role checks, raid icons, master instructions and per-bot heuristics. Emergent coordination can work well in ordinary pulls, but it becomes brittle when two healers choose the same target, multiple interrupters spend cooldowns on one low-value cast, or several bots choose the same safe position.

## 3.12 Dungeons, bosses, questing and open-world activity

Dungeon Actions and raid-specific Strategies provide content adapters and encounter logic. Related forks demonstrate that extensive boss scripting can produce impressive results, including role assignment and hazard avoidance, but such guides also document transition gaps, composition requirements and cases where the human should back up the bots. Those findings are cross-project evidence, not proof about the pinned Classic build. [C28](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide)

Questing and open-world behaviour are broad: bots can acquire/complete quests, travel, loot, gather, maintain gear and participate in social/group activities. This breadth is the basis for the positive “world feels alive” reports. It also creates repetitive patterns when the high-level goal selector and movement repertoire are too deterministic. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [I11](https://www.reddit.com/r/wowservers/comments/1kt0k8a/try_single_player_project_seriously/) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/)

## 3.13 Battleground and PvP behaviour

`BattleGroundTactics.cpp` is a large body of imperative objective and movement logic. This is evidence that battleground behaviour is more than “attack nearest,” but also indicates a high maintenance burden and potential predictability: objective transitions and special cases are encoded explicitly. [C27](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/BattleGroundTactics.cpp)

A better architecture would retain deterministic objective legality and map knowledge while using a shared team objective blackboard, influence map and personality/risk variation. PvP reaction times must be intentionally delayed and based only on observable state, not server-private information.

## 3.14 Reactions to human instructions

Playerbots expose a large chat-command and external-event surface covering follow, stay, guard, attack, pull, formation/position, focus heal, revive, buff, flee, strategies, quest actions and diagnostics. This is powerful and positively perceived, but the string-heavy command vocabulary creates discoverability and configuration friction. Related projects recommend addons specifically to smooth control. [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) [I16](https://github.com/mod-playerbots/mod-playerbots/wiki) [I17](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Addons-and-Sub%E2%80%90Modules)

The future architecture should preserve command compatibility while translating commands into typed intents with ownership, priority, expiry and acknowledgement. A command should wake the relevant bot immediately and produce a clear reason if it cannot be satisfied.

## 3.15 PerformanceMonitor

`PerformanceMonitor` records nested operation names for total, trigger, value, action and random-bot work. It is useful as a first-pass hotspot inventory. It is not sufficient for the target decision because:

- timing is millisecond-granularity;
- nested operation stacks and strings add measurement overhead;
- a max-time aggregation path compares/assigns the minimum field, which appears to be a bug;
- a data lock is commented out;
- it does not directly produce world-tick p95/p99, allocation counts, path counts, database waits or device thermal data. [C11](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PerformanceMonitor.cpp)

Replace or augment it with monotonic high-resolution timing, numeric operation IDs, low-overhead per-tick ring buffers, sampled call traces and explicit counters. Existing scopes can be mapped to the new IDs so current instrumentation work is not discarded.

## 3.16 Playerbots–CMaNGOS interaction

![Figure 2. Principal interactions between Playerbots and CMaNGOS.](images/figure_2_integration.png)

*Figure 2. Principal interactions between Playerbots and CMaNGOS.*

Playerbots are deeply integrated rather than a stand-alone agent layer. They depend on CMaNGOS entity, spell, threat, movement, path, grid, session and database systems. Consequently, a Playerbots-only optimization can merely move cost into core queries. The benchmark plan must attribute both sides of every decision: state extraction, object search, path/LOS work, action execution and resulting core processing.

# 4. Behaviour strengths and weaknesses

## 4.1 Strengths worth preserving

### Mature class and spell knowledge

The strongest current asset is the amount of game-specific knowledge already encoded. Class/spec selection, role inference, spell legality, buffs, resources, pets, dispels, heals, threat and target conditions are distributed across factories, Strategies, Triggers, Values and Actions. A ground-up replacement that discards these Actions would spend years rediscovering edge cases already represented in public code. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp)

### Strong ordinary-combat competence

For ordinary pulls, the combination of assist targets, raid icons, threat checks, incoming-damage estimates, cure selection and crowd-control filters can produce competent party behaviour. The code is not limited to a hard-coded rotation list; it considers world state and action utility. This explains positive reports that bots can feel like usable party members or an “average pickup group” when content and configuration fit their capabilities. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/)

### Broad world simulation

Autonomous questing, travel, gathering, maintenance, grouping, guild activity and battleground participation make a sparse offline realm feel populated. Positive public reports consistently value encountering bots already questing, levelling a persistent guild, assembling a party on demand and replaying old content without a live population. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) [I13](https://www.reddit.com/r/wowservers/comments/12u8g3t/wow_spp_classics_bot_server_to_run_in_your_own/)

### Deterministic debuggability

Most behaviour is reproducible from configuration, state and random seeds. Actions and Triggers can be logged by name. This is valuable for a local server where correctness and repeatability matter more than fashionable AI. A redesign should improve observability rather than replace it with an opaque end-to-end model.

### Human control and recoverability

The chat command system allows a human to override poor autonomous choices, assign targets, change Strategies and reposition bots. This is a practical safety valve and a core part of the single-player-party experience. [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands)

## 4.2 Five largest behavioural limitations

### 1. No general party intent, reservation or commitment layer

This is the largest structural gap. A party needs shared decisions such as:

- which enemy is the pull target and which enemies must remain controlled;
- which tank owns each threat target;
- who will interrupt which cast, and when backup becomes eligible;
- who will dispel which aura;
- which healer owns a predicted damage spike;
- which formation or hazard-safe position each member occupies;
- when the group is recovering, moving, pulling, burning or disengaging.

The current architecture often infers these independently from shared state. That creates duplicated work and correlated mistakes. A blackboard with expiring reservations solves both behaviour and CPU problems by turning repeated local reasoning into one party decision.

### 2. Shallow tactical horizon

The action graph handles immediate prerequisites and fallbacks, but the general tactical loop does not search or maintain multi-step intent. It can answer “which useful action now?” better than “what sequence should the party commit to over the next several seconds?” This contributes to weak setup for interrupts, crowd control transitions, line-of-sight pulls, tank swaps and boss phases.

The answer is not unconstrained GOAP on every tick. It is a bounded hierarchy: low-frequency goal/phase selection, medium-frequency tactical intent and high-frequency reactions.

### 3. Navigation, line of sight, formation and hazard positioning are fragmented

Travel routes, local PathFinder calls, sampled nearby points, follow logic, hazard modifications and encounter special cases exist, but there is no single tactical placement service that jointly considers:

- navmesh reachability;
- line of sight to target and healer;
- pull radius and nearby neutral/hostile packs;
- tank-facing and melee/ranged envelopes;
- crowd-control separation;
- environmental hazards;
- formation slots and collision/crowding;
- future movement cost.

The result can be individually legal positions that are collectively poor. This limitation is source-inferred and strongly supported by public pathing/stuck complaints across versions and forks. [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp) [I01](https://github.com/cmangos/issues/issues/4104) [I05](https://github.com/cmangos/issues/issues/3886) [I07](https://github.com/cmangos/issues/issues/2186) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/)

### 4. Robotic timing, correlated choices and possible omniscience

Because bots access exact server state and use deterministic thresholds, they can react too quickly, select the same response repeatedly and appear to know facts a human could not observe. Examples to guard against include reacting at the same latency to every cast, switching instantly on hidden threat changes, using exact health/resource thresholds with no perception lag, or targeting through knowledge not available in line of sight.

Believability requires an explicit observation model: delayed/remembered facts, bounded reaction distributions, uncertainty for hidden state, and personality/risk profiles. This should be deterministic under a replay seed so tests remain reproducible.

### 5. High-level behaviour and commands are broad but brittle

The amount of functionality is impressive, yet much of it is exposed through many named Strategies, values and chat commands. Users face configuration and command complexity; complex encounters can depend on bespoke scripts or manual intervention. The next architecture should translate the existing command surface into typed intents and consolidate encounter mechanics into reusable primitives rather than adding one-off commands indefinitely. [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) [I16](https://github.com/mod-playerbots/mod-playerbots/wiki) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide)

## 4.3 Domain-by-domain assessment

| Domain | Current strengths | Principal limitations | Evidence status |
|---|---|---|---|
| Pulling / accidental aggro | Target validation, pull targets, difficulty filters, avoid-mob strategies | `AttackAnything` can proactively select a low-level NPC in a forward cone; movement/position decisions do not share a general pull-risk map | Source mechanism verified; frequency requires replay/profile. [C24](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/ChooseTargetActions.cpp) |
| Rotations and resource use | Class/spec strategies, resource thresholds, usefulness and spell legality | Rule interaction can be hard to reason about; no common rotation benchmark; repeated thresholds can be predictable | Source verified; quality mixed/unknown. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) |
| Healing | Incoming-damage prediction, pre-heal and wasteful-heal cancellation | No general multi-healer reservation, triage ownership or shared cast ledger | Source verified plus architectural inference. [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) |
| Threat / tanking | Threat bands, projected threat, role/assist logic and some taunt restraint | No explicit multi-tank target ownership or phase-level tank plan | Source verified plus inference. [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) |
| Interrupts | Interruptibility triggers and spell actions | No general interrupt rotation, cast-value ranking or reservation ledger found | Inference from examined files; verify all class-specific call sites. |
| Dispels | Cure triggers select targets by dispel type | No general dispel priority, harmful-versus-beneficial value model or reservation | Source verified plus inference. [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp) |
| Crowd control | Filters unsafe/dotted/low-health/current/icon targets | No party-wide CC ownership, refresh timing or break-risk budget | Source verified plus inference. [C26](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp) |
| Pets | Pet spell/action support and class strategies exist | No general pet positioning, pull-risk and party reservation model identified | Partial source coverage; profile and audit class files. [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) |
| Position / LOS | Range/LOS legality, local position sampling, pathfinding and hazard hooks | Fragmented solvers; repeated local path/LOS requests; group crowding and route quality | Verified mechanisms, community corroboration. [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) |
| Dungeon / boss | Dungeon actions and encounter-specific Strategies can encode mechanics | Bespoke scripts have limited generalization; phase transitions can require human backup in related forks | Direct code plus cross-project evidence. [C28](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide) |
| Questing / travel | Broad autonomous world loop, route graph and maintenance | Repetition, stuck states, road/town quality, first-generation/database work | Direct code plus community evidence. [C09](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) [C17](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/TravelMgr.cpp) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) |
| Battleground / PvP | Large objective-specific tactics implementation | Predictable imperative policies; limited team-level opponent modelling; risk of instant/omniscient reactions | Direct code; behaviour quality requires scenarios. [C27](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/BattleGroundTactics.cpp) |
| Human instructions | Extensive command and Strategy controls | Discoverability, string parsing, ambiguous ownership/expiry, need for addons | Direct docs and related-project evidence. [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) [I17](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Addons-and-Sub%E2%80%90Modules) |

## 4.4 Poor behaviour versus poor architecture

Not every poor outcome requires a new AI. Failures should be classified before changing behaviour:

1. **Core/data defect:** invalid coordinates, map data, spell data, database relations or navmesh errors.
2. **Perception defect:** stale/missing Value, wrong cache invalidation or hidden-state leakage.
3. **Legality defect:** action incorrectly considered possible or useful.
4. **Coordination defect:** individually valid actions conflict across bots.
5. **Planning defect:** no sustained intent or phase model.
6. **Scheduling defect:** correct decision is too late because the bot was not woken or budgeted.
7. **Execution defect:** movement/cast/session operation fails after a sound decision.
8. **Believability defect:** result is competent but visibly robotic or unfair.

The benchmark harness should record this category for every failure. Otherwise more rules will be added to compensate for path, data or scheduling defects.

# 5. Community perception and complaint evidence

## 5.1 Method and selection bias

Public issue trackers over-represent failures, setup forums over-represent configuration problems, and demonstrations often select successful scenes. This report therefore uses three evidence grades:

- **High confidence:** independently corroborated by current source plus multiple public reports, or by multiple projects with a common underlying mechanism.
- **Medium confidence:** credible direct report or issue but version/fork relevance is incomplete.
- **Low confidence:** isolated anecdote, promotional claim or unclear build.

AzerothCore Playerbots, SPP repacks, older CMaNGOS expansions and other derived systems are separated from pinned CMaNGOS Classic. Their reports are useful for identifying likely failure classes and test cases, not for asserting current implementation identity.

## 5.2 Complaint and perception taxonomy

| Taxonomy | Public evidence | Project / expansion / date | Relevance to pinned CMaNGOS Classic | Confidence / disposition |
|---|---|---|---|---|
| Stuck movement, poor roads and town routing | Users describe bots stuck in towns and weak road use; old CMaNGOS follow/pathing crash; flight-mount regression in WotLK [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) [I07](https://github.com/cmangos/issues/issues/2186) [I05](https://github.com/cmangos/issues/issues/3886) | AzerothCore WotLK 2026; CMaNGOS TBC 2020; CMaNGOS WotLK issue | Mechanism is relevant because current Classic also uses route/local path special cases, but exact bugs differ | **High** as a problem class; individual issues may be outdated/fork-specific |
| Invalid coordinates / movement crash | Current Classic issue reports a bot/pet at invalid coordinates and a crash with 500 bots [I01](https://github.com/cmangos/issues/issues/4104) | CMaNGOS Classic, 2026, exact pinned core SHA | Directly relevant; issue remains a data/path correctness case, not proof of general AI load | **High** severity, currently specific and awaiting replication |
| Line of sight and positioning | Raid guides and player reports require manual positioning or backup during transitions; code has many LOS/path checks [I10](https://www.reddit.com/r/wowservers/comments/1jh63c4/azerothcore_vs_cmangos_playerbots/) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide) | CMaNGOS anecdote; AzerothCore raid guide | Strongly relevant problem class; specific mechanics are expansion/fork-specific | **Medium-high** |
| Complex boss mechanics need scripting or human help | CMaNGOS comparison report says ordinary play is acceptable until raiding; related raid guide documents coded mechanics and transition limitations [I10](https://www.reddit.com/r/wowservers/comments/1jh63c4/azerothcore_vs_cmangos_playerbots/) [I19](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide) | Version unspecified CMaNGOS; AzerothCore WotLK/TBC content guide | General architectural relevance; do not transfer encounter coverage directly | **Medium-high** |
| Repetitive / lifeless world behaviour | SPP user reports bots become repetitive and the “world alive” effect fades [I11](https://www.reddit.com/r/wowservers/comments/1kt0k8a/try_single_player_project_seriously/) | SPP/CMaNGOS-derived Vanilla, 2025 | Directly relevant to deterministic world-goal/personality design; still anecdotal | **Medium** |
| Bots feel like controllable average players | Users describe bots as an “average noob pug,” sometimes better because they obey instructions [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) | AzerothCore WotLK, 2026 | Positive cross-project baseline, not evidence of current Classic parity | **Medium** |
| Unwanted pulls / aggro | Community complaint appears across bot systems; current code contains a proactive `AttackAnything` mechanism and fragmented movement risk | Mixed | Relevant test case, but public current-Classic frequency was not independently established | **Medium-low**; source mechanism exists |
| Weak command discoverability / configuration complexity | Related project maintains extensive command wiki, configuration guide and control addons [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) [I16](https://github.com/mod-playerbots/mod-playerbots/wiki) [I17](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Addons-and-Sub%E2%80%90Modules) | AzerothCore Playerbots, 2025–2026 | Command architecture is closely related; exact commands differ | **High** as UX class, cross-project |
| Questing limitations / troubleshooting | Dedicated questing limitation/troubleshooting video and setup guides; current code includes many quest/database paths [I24](https://www.youtube.com/watch?v=Bca-RGbQAEw) | AzerothCore video; CMaNGOS code | Useful test taxonomy; implementation-specific details not transferable | **Medium** |
| Battleground instability / packet pressure | CMaNGOS issue reports intermittent client crashes in BGs with many playerbot packets [I04](https://github.com/cmangos/issues/issues/4016) | CMaNGOS WotLK, open | Same subsystem class but different expansion; test packet concentration | **Medium-low** for Classic |
| Server crashes shortly after enabling bots | WotLK issue reports crashes 5–10 minutes after enabling bots [I03](https://github.com/cmangos/issues/issues/4064) | CMaNGOS WotLK, closed | Serious but expansion/build-specific; not a current Classic benchmark | **Low-medium** |
| Quest action crash | ConfirmQuestAction null dereference issue, closed [I02](https://github.com/cmangos/issues/issues/4096) | CMaNGOS Classic, 2026 | Directly relevant correctness example; reportedly fixed/closed | **High** historically; not an open architecture complaint |
| Stackable-item command failure | Old Classic issue on bot use of stackable items [I06](https://github.com/cmangos/issues/issues/2830) | CMaNGOS Classic, 2022, open | Direct feature relevance but likely old code path | **Low-medium**, potentially outdated |
| Login/generation takes a long time | README/setup guides warn about first generation; administrators discuss large default bot pools [C30](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/README.md) [I22](https://www.youtube.com/watch?v=zr-5cNwEs18) | CMaNGOS/SPP | Directly relevant; transient workload must be separated | **High** |
| CPU saturation at high population | N100 report says 1,000 bots caused prolonged 100% CPU and unplayable service; 500 was acceptable subjectively [I08](https://www.reddit.com/r/wowservers/comments/1dk82zr/server_performance_hardware/) [I09](https://www.reddit.com/r/MiniPCs/comments/1eftys5/n100_performance_less_than_expected/) | SPP Classics Vanilla, 2024 | Valuable reference but uncontrolled | **Medium** as anecdote; no tick proof |
| “Thousands of bots” performance claims | Related repository advertises excellent performance with thousands of bots; videos show large configured populations [I14](https://github.com/mod-playerbots/mod-playerbots) [I22](https://www.youtube.com/watch?v=zr-5cNwEs18) | AzerothCore fork / SPP | Promotional/demo evidence does not establish active fidelity, tick latency or hardware | **Low** as benchmark; useful for workload questions |
| Local LLM improves social flavour but is expensive | Demonstrations exist; community users report large local models can be too slow/resource-heavy, while others enjoy them [I20](https://www.youtube.com/watch?v=CIxrmZ1V6_U) [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) | CMaNGOS/AzerothCore-derived setups | Supports strict separation from simulation | **Medium** |

## 5.3 Frequent and independently corroborated findings

The most consistently supported problem classes are:

1. **Navigation and stuck behaviour.** It appears in current and historical issues, related-fork reports and questing guides. The exact defects vary, but the class is stable.
2. **Complex encounter dependence on scripts or human control.** Ordinary combat can be competent; mechanic transitions and positioning expose the lack of a general party plan.
3. **Command/configuration friction.** Large command guides and control addons are themselves evidence that power is not easily discoverable.
4. **Repetitive high-level behaviour.** Positive first impressions can decay when movement, goals and reactions repeat.
5. **Burst/stability problems around login, generation, battleground packets or concentrated pathing.** These are not one steady-state “AI CPU” problem and must be benchmarked separately.

## 5.4 Serious but uncommon or version-specific reports

Crashes involving invalid coordinates, quest null pointers, battleground packets and follow movement are serious. They should enter regression tests, but should not be generalized into “Playerbots always crash.” Expansion, issue status, data revision and exact stack matter. [I01](https://github.com/cmangos/issues/issues/4104) [I02](https://github.com/cmangos/issues/issues/4096) [I03](https://github.com/cmangos/issues/issues/4064) [I04](https://github.com/cmangos/issues/issues/4016) [I07](https://github.com/cmangos/issues/issues/2186)

## 5.5 Positive perceptions

| Positive perception | Evidence | Interpretation |
|---|---|---|
| The world feels populated and nostalgic | Users describe seeing bots questing, visiting merchants and levelling as transformative for an offline realm [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) | High-level autonomous activity is a core product feature, not decorative load. |
| Single-player party composition is enjoyable | Users compare it to party-based RPGs and enjoy building/gearing a team [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) | Human companions deserve the highest scheduling and coordination priority. |
| Bots obey commands and make old content accessible | Community reports and command documentation emphasize controllability [I12](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) [I15](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) | Preserve deterministic command override and acknowledgements. |
| Class behaviour can be impressive | Reports describe useful healer/follower behaviour and raid clears in related projects; code contains substantial class logic | Preserve actions/class knowledge while improving orchestration. |
| Large populations are visually compelling | Demonstrations show busy worlds with hundreds or thousands of configured bots [I22](https://www.youtube.com/watch?v=zr-5cNwEs18) | Population should be measured by active fidelity, not login count. |

## 5.6 What remains unsupported

No public evidence found in this study establishes, for the pinned CMaNGOS Classic revision on a controlled machine:

- a 500-bot world-tick p95/p99;
- memory per bot;
- active/idle/near-human/combat cost per bot;
- pathfinding calls per bot-second;
- database query and wait rate during steady state;
- thermal stability on Snapdragon 8 Gen 2;
- end-to-end NPU latency for a Playerbots state vector;
- a fair behaviour comparison between current CMaNGOS, AzerothCore and other forks at matched expansion/content/configuration.

# 6. CPU and scaling analysis

## 6.1 Source-proven scaling mechanisms

The following are verified implementation properties, not speculative benchmarks:

1. `Player::UpdateAI(diff, minimal)` drops `minimal` before calling PlayerbotAI at the pinned revisions. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp) [C02](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h)
2. Every Player still passes through core Player update work each map tick. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp)
3. Each bot owns an `AiObjectContext` with named Action, Trigger, Strategy and Value contexts. [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)
4. Shared-value context integration is commented out. [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)
5. Active Engine passes scan triggers, repopulate default candidates and iterate the candidate queue. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp)
6. Queue duplicate and maximum operations are linear in queue length. [C05](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp)
7. Named-object lookup uses strings/maps and runtime casts. [C07](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/NamedObjectContext.h)
8. Attackers and related Values traverse group members, pets, possible targets and ObjectMgr lookups. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp)
9. Local movement can construct PathFinder and perform LOS/position sampling. [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp)
10. Managers perform population/session scans, command fanout and periodic database-related operations. [C12](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp) [C14](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotMgr.cpp)
11. Login holders and character factories can perform large database and randomization workloads. [C13](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLoginMgr.cpp) [C15](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotFactory.cpp) [C16](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotFactory.cpp)
12. PerformanceMonitor does not provide sufficient high-resolution tick-tail or hardware data. [C11](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PerformanceMonitor.cpp)

## 6.2 Likely hotspots requiring profiling

| Hypothesis | Why plausible | Measurement that decides it |
|---|---|---|
| Trigger scan dominates active decisions | Many Strategies can contribute TriggerNodes; scan repeats per decision | Count active triggers, checks and nanoseconds per bot-state; sort by trigger family |
| Named Value lookup and cache duplication are significant | String/map/dynamic-cast path, per-bot contexts, shared values disabled | CPU samples in context lookup; values created per bot; cache hit/recompute counts; heap attribution |
| Candidate allocation and linear Queue cause tail spikes | Dynamic candidate graph and repeated linear scans | Candidate count distribution; allocations/frees; queue scan length; p99 action-selection time |
| Human-nearby detection scales poorly | Per-bot loop over real players without a shared spatial index | Distance checks per tick; compare against grid-index query |
| Target/attacker Values repeat group/object work | Each bot may inspect overlapping group and enemy sets | ObjectMgr lookups and unit validations per party event; shared-snapshot experiment |
| Path/LOS concentration dominates worst cases | PathFinder and LOS are expensive and can be synchronized by pulls/travel | Requests, nodes expanded, cache hit rate and time by map/cell; same-zone stress |
| Random map-level gating creates bursty work | A common random decision can wake many bots in a map together | Per-tick ready-bot histogram; compare deterministic staggering |
| Packet queue lock creates contention | Producers lock; consumer uses `try_lock` | Lock wait/failed try-lock counts and packet delay; likely low unless packet-heavy |
| Database ping/login holder work stalls or bursts | Periodic DB checks and large holder/entity insertion paths | Query count/wait, holder completion, session insertion time, world-tick attribution |
| Auction mirroring or global manager scans produce periodic stalls | Mutex and broad scans in manager code | Lock wait, scan count and duration by interval |

## 6.3 Scaling model

![Figure 3. Population-mix and concentration scaling model.](images/figure_3_scaling_model.png)

*Figure 3. Population-mix and concentration scaling model.*

A useful model separates population classes instead of multiplying one “cost per bot” by total logins:

`T_tick = T_core + T_fixed + N_bg*c_bg + N_travel*c_travel + N_world*c_world + N_near*c_near + N_party*c_party + N_combat*c_combat + T_coord + T_path + T_DB/login + T_burst`

Memory should be modelled as:

`M_total = M_core + N*M_bot + M_shared_spatial + ΣM_party + M_path_cache + M_login_holders + M_optional_model`

No numeric coefficients are asserted here. Each coefficient must be measured by controlled population deltas and replayed scenarios.

## 6.4 Meaningful workload classes

![Figure 5. Workload classes and graceful degradation.](images/figure_5_workload_classes.png)

*Figure 5. Workload classes and graceful degradation.*

| Class | Simulation obligation | Wakeups and decision hierarchy | Quality under pressure |
|---|---|---|---|
| Remote/background, near no humans | Maintain identity, long-term goal, inventory/economy abstractions and credible route/activity progression | Primarily event-driven; low-frequency high-level updates; no repeated tactical scans | May be deferred or coarsened; must not be counted as fully tactical |
| Travelling, unseen | Progress along route and respect transports/area transitions | Route-level deadlines; local PathFinder only near complexity or visibility | Coarsen route progress while preserving arrival semantics |
| Simple world activity | Quest, gather, vendor, rest, uncomplicated fights | Low-frequency goal planning; immediate combat/damage wake | Reduce high-level cadence, not reaction safety |
| Near a human | Plausible movement, animation, target and social behaviour | Shared local perception; more frequent tactical updates | Preserve visible quality |
| Human party companion | Commands, group state, role coordination and acknowledgement | Immediate command wake; strict coordination deadlines | Preserve unless necessary to protect world tick |
| Combat | Target, threat, heal, interrupt, movement and resource decisions | Event-driven reaction plus bounded tactical cadence | Preserve legality and reaction deadlines |
| Dungeon/raid | Combat plus mechanics, formation and party reservations | Highest priority group scheduler; shared encounter state | Preserve correctness; reduce unrelated background work first |
| Battleground/PvP | Combat plus objectives and opponent uncertainty | Team blackboard, influence map, believable reaction delay | Preserve visible fairness; never gain hidden-state access |

The table intentionally avoids claiming a final frequency. Prototype values can be tested, but each class needs deadline distributions derived from behaviour benchmarks and the actual world update interval.

## 6.5 Event-driven wakeups and deterministic staggering

The current system already receives many packets/events and has delayed updates. The redesign should make events first-class:

- damage, cast start/stop, aura change, target death, threat ownership change;
- command, group membership/role change and master movement;
- path completion/failure and stuck detector;
- entering human visibility or a shared encounter;
- database/login completion;
- thermal/tick-pressure signal.

Each event marks a compact set of facts dirty and schedules only relevant decision tiers. Deadlines should be deterministic from bot ID, group ID and replay seed, rather than a map-wide random gate. This prevents synchronized bursts while remaining reproducible.

## 6.6 Shared queries and route/path data

The largest safe sharing opportunities are facts that multiple bots observe identically:

- nearby hostile/friendly object sets by cell and visibility class;
- active enemy casts and interrupt windows;
- hazards and forbidden regions;
- party roles, health summaries, current targets and reservations;
- route segments and path corridors;
- encounter phase and mechanic timers;
- human-nearby zones and visibility transitions.

Sharing must be scoped and versioned. A global cache with broad locks could be worse than per-bot work. Recommended scopes are immutable per-tick map/cell snapshots, party/encounter blackboards and read-mostly route caches. Cache invalidation should use generation numbers, dirty event sets and bounded lifetimes, not string-based global resets.

## 6.7 Data-oriented hot state

The current named Value system is flexible and should remain for slow-path diagnostics and configuration. The hot tactical path should consume a typed snapshot with compact numeric identifiers:

- bot health/resource/status flags;
- target IDs and observable properties;
- party health/threat/role arrays;
- active casts and aura summaries;
- nearby hazard/position candidates;
- action cooldown/resource legality bitsets;
- reservation ownership and expiry;
- observation timestamps and confidence.

This reduces string hashing/comparison, map traversal, dynamic casts and repeated CMaNGOS calls. The snapshot is also the interface for replay tests and any optional learned scorer.

## 6.8 Login, generation and database pressure

Measure at least four independent phases:

1. **Cold generation:** account/character creation, randomization and database writes.
2. **Warm login storm:** pre-existing characters logging in and loading query holders.
3. **World insertion:** entity/session creation, teleports, grid activation and initial AI context creation.
4. **Steady state:** periodic manager timers, saves, DB pings and gameplay queries.

A 500-bot headline that begins after all bots are generated and settled is valid only if reported as a warm steady-state result. Startup time, maximum simultaneous login rate and worst world-tick stall during insertion remain separate required metrics.

## 6.9 Graceful degradation under tick or thermal pressure

The scheduler should observe world-tick debt and a device thermal/frequency signal. Degradation order should be explicit:

1. postpone optional LLM/social generation;
2. defer remote cosmetic/social actions;
3. lower remote high-level planning cadence;
4. coarsen unseen travel and maintenance;
5. reduce speculative path replanning and nonessential object scans;
6. preserve human-visible movement and command response;
7. preserve combat legality, hazard escape and group safety;
8. if deadlines cannot be met, reduce logged-in population or active-area density rather than silently making companions inert.

This produces honest scalability. A dashboard should report counts in each fidelity class so “500 bots” cannot hide 490 dormant entities.

## 6.10 Snapdragon versus desktop considerations

A desktop/mobile comparison must account for:

- sustained rather than burst frequency;
- number and arrangement of performance/efficiency cores;
- ARM64 versus x86-64 code generation and branch behaviour;
- memory bandwidth, latency and cache capacity;
- Android scheduler/background-service overhead;
- storage and database filesystem behaviour;
- thermal mass, cooling, charging state and enclosure;
- contention with the WoW client, GPU, display and NPU;
- compiler, standard library and build flags;
- native process/container/Termux/proot overhead if used.

The Snapdragon 8 Gen 2 product brief describes a heterogeneous Kryo CPU, Adreno GPU and Hexagon processor with low-precision AI support, but it does not establish game-server performance. [H02](https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Snapdragon-8-Gen-2-Product-Brief.pdf)

## 6.11 Credibility of the 500-bot target

The target is **technically credible but not yet demonstrated** under these conditions:

- bots are genuinely simulated, with a reported workload-class distribution;
- remote bots use coarse/event-driven simulation;
- bots near humans and in groups/combat retain full fidelity;
- the minimal-update integration defect and scheduling bursts are addressed;
- per-bot duplicate queries are reduced;
- login/generation is paced and measured separately;
- the device sustains clocks without severe thermal throttling;
- p95/p99 world-tick and human input responsiveness meet a chosen service level.

The target is **not presently credible as an unconditional claim** that 500 bots can all be in one active combat area or multiple raids at full tactical fidelity. That scenario is a worst-case concentration benchmark, not a normal population assumption.

## 6.12 How every cost term should be measured

| Cost term | Measurement method |
|---|---|
| Fixed Playerbots overhead | Run pinned core with Playerbots compiled/enabled but zero bots; compare matched build with module disabled where possible; attribute manager timers separately |
| Memory per bot | Warm baseline; add bots in controlled increments with identical class/level/context; use RSS/PSS plus heap allocation attribution; regress total memory against bot count |
| Idle/background CPU per bot | Replay a fixed remote-world scenario; divide incremental CPU by bot-seconds only after fixed cost is removed |
| Active nearby CPU per bot | Place bots in human-visible cells without combat; record AI, movement, object-query and packet cost |
| Combat CPU per bot | Script repeatable combat with fixed enemies and state traces; report by role/class and encounter density |
| Party coordination overhead | Compare independent bots versus same bots sharing a blackboard; report coordinator cost and removed duplicate work |
| Pathfinding cost | Count requests, path length/nodes, cache hit, LOS calls and time; separate route graph from local navmesh |
| Database/login cost | Query count, query wait, holder load, entity insertion, save cost and world-tick stalls by phase |
| Worst-case concentration | Same-zone, same-instance, mass-pull, battleground and synchronized path-failure scenarios |
| World-tick quality | Median, p95, p99, maximum and missed-deadline counts; correlate with subsystem traces |
| Energy/thermal | Perfetto/power rails where available, battery current, package temperature, CPU frequencies and throttling state over a sustained run |

# 7. Modern AI technique comparison

## 7.1 Decision principle

A technique is useful only if it solves an observed problem at acceptable runtime cost and is easier to validate than a simpler alternative. Playerbots already has exact structured world state and a large deterministic action library. It does not need computer vision, language understanding in the tactical loop or an end-to-end agent that rediscovers spell legality.

## 7.2 Deterministic architecture techniques

| Technique | Problem solved / integration point | Behaviour effect | Runtime CPU and memory | Complexity, debugging and failure modes | Recommendation |
|---|---|---|---|---|---|
| Hierarchical utility AI | Split world goal, tactical intent and immediate action; replace flat broad Strategy activation | High-level planning, tactics and believability | Low-to-moderate CPU with bounded candidate sets; small intent state | Scores can interact opaquely unless reason traces are mandatory | **Adopt as primary selector.** Natural evolution of current relevance system. |
| Behaviour trees | Organize reusable sequences/conditions and explicit fallback | Good for encounter phases, recovery and command flows | Predictable if trees are bounded; node state memory is small | Large trees can become “spaghetti,” repeat checks and hide priority interactions [A01](https://arxiv.org/abs/1709.00084) | **Use selectively**, especially for mechanic adapters and recovery, not as the sole scoring system. |
| Hierarchical state machines | Explicit modes such as travel, social, pull, combat, recover and dead | Clear transitions and scheduling tiers | Very low CPU/memory | State explosion if tactics are encoded as states | **Adopt for modes**, not detailed action choice. |
| GOAP | Search action sequences from goals and preconditions, as in practical game AI planning [A02](https://www.gamedevs.org/uploads/three-states-plan-ai-of-fear.pdf) | Better multi-step setup and adaptability | Potentially expensive and variable; memory for search frontier | Requires careful operator design; worst-case search spikes; plans invalidate in MMO combat | **Use only for low-frequency bounded plans** such as travel/quest preparation. Reject per-tick combat GOAP. |
| HTN | Decompose high-level tasks into domain methods | Excellent for quest/travel/maintenance workflows | Low when decomposition is deterministic; high for broad search | Domain authoring burden; incomplete methods fail rigidly | **Useful for slow-path world activities**, not the reaction loop. |
| Shared party blackboard | Centralize facts, intent, reservations and encounter state | Major coordination and reduced duplicate reasoning | Low CPU; memory proportional to party/encounter, not bot count | Stale reservations or central-policy bugs can affect whole group | **Adopt.** Highest behaviour-per-cost opportunity. |
| Role and resource reservations | Assign interrupt, heal, dispel, CC, pull, tank target and position with expiry | Prevents duplicated cooldowns/casts and conflicting movement | Very low | Dead owner or missed deadline needs deterministic takeover | **Adopt inside blackboard.** |
| Tactical influence map | Represent danger, aggro risk, objectives, healer/tank coverage | Positioning, PvP objective choice and believable avoidance | Moderate; update by dirty regions, not every bot | Bad weights create herd behaviour; grid resolution trade-off | **Adopt scoped maps** for encounter/cell, shared across bots. |
| Formation and positioning solver | Jointly assign reachable positions under LOS/range/hazard constraints | Direct improvement to movement, pulls and group readability | Moderate during replans; small candidate matrices | May oscillate without hysteresis; infeasible layouts need fallback | **Adopt deterministic solver** with reservations and hysteresis. |
| Personality/risk profiles | Stable variation in thresholds, goals, delays and preferred formations | Believability and less correlated behaviour | Negligible | Variation can reduce competence; must stay within safety envelope | **Adopt as bounded parameters**, seeded for replay. |
| Deterministic reaction delays | Replace instant threshold response with observable-state delay distributions | Fairer PvP and human-like timing | Negligible | Too much jitter misses mechanics; hidden-state leaks remain possible | **Adopt**, role/mechanic bounded and replay-seeded. |

## 7.3 Performance architecture techniques

| Technique | Where it integrates | CPU/memory effect | Failure mode | Recommendation |
|---|---|---|---|---|
| Event-driven perception | Packet/world hooks mark typed facts dirty | Avoids polling unchanged facts; adds small event queues/version fields | Missed event creates stale state | **Adopt with periodic low-rate validation.** |
| Shared scoped perception caches | Map cell, party and encounter snapshots | Removes duplicate object/group/cast/hazard queries; memory shared | Lock contention or over-broad invalidation | **Adopt immutable/versioned snapshots.** |
| Temporal level of detail | Scheduler assigns decision tiers by visibility, association and danger | Main population-scaling lever | Bots become inert if categories are dishonest or wakeups fail | **Adopt with public class counts and deadline tests.** |
| Adaptive decision frequencies | Increase only when events/uncertainty require it | Reduces idle work | Late response after category transition | **Adopt with immediate wakeups.** |
| Deterministic staggering | Spread deadlines by stable IDs/seed | Reduces synchronized tick spikes | Can align with periodic events if poorly hashed | **Adopt and inspect ready-set histograms.** |
| Batching similar decisions | Evaluate common typed state arrays together | Better cache locality and NPU amortization | Waiting for batch increases latency | **Use for medium/low-frequency scoring**, not urgent safety actions. |
| Precomputed tactical information | Spell legality tables, route corridors, hazard templates | Moves static work out of tick | Stale after data/config changes | **Adopt with revision-keyed caches.** |
| Data-oriented layouts | Compact arrays/bitsets for tactical hot state | Fewer allocations, branch misses and string lookups | Migration complexity and duplicated sources of truth | **Adopt behind a snapshot boundary.** |
| Reduce virtual dispatch/allocations | Fixed candidate storage and numeric action IDs | Improves hot-loop locality | Premature optimization if candidates are small | **Profile, then implement in active tiers.** |
| Human-visible prioritization | Scheduler reserves deadlines for nearby/party/combat bots | Preserves perceived quality | Remote world may progress unevenly | **Adopt with fairness aging and transparent metrics.** |

## 7.4 Learned and adaptive techniques

| Technique | Possible use | Data requirements | Runtime cost / determinism | Failure modes | Verdict |
|---|---|---|---|---|---|
| Contextual bandit | Tune among safe tactic variants or personality choices | Logged context, action and bounded reward | Low; online exploration changes behaviour | Exploration can waste cooldowns or learn from biased rewards | **Postpone.** Offline evaluation first; never explore legality-critical actions live. |
| Imitation learning | Learn scoring from human or strong scripted traces | Large aligned state/action traces; observation masking | Small distilled policy possible; deterministic at inference | Distribution shift and compounding errors; DAgger addresses induced-state mismatch but requires interactive data collection [A03](https://proceedings.mlr.press/v15/ross11a.html) | **Useful in development**, not required for first architecture. |
| Offline reinforcement learning | Learn from fixed gameplay logs without live exploration | Diverse logged trajectories, reward definition and coverage | Training expensive; inference can be small | Extrapolation outside dataset; conservative methods reduce but do not remove risk [A05](https://proceedings.neurips.cc/paper/2020/hash/0d2b2061826a5df3221116a5085a6052-Abstract.html) | **Research option only** after a reliable trace corpus. |
| RL during development, then distillation | Train in accelerated scenarios, distil to small policy/tree | Simulator/reset harness and many episodes | Runtime can be tiny; training large | Reward hacking, sim-to-build mismatch, opaque corner cases | **Potentially valuable for narrow tactical scoring**, gated by deterministic tests. |
| Policy distillation | Compress an ensemble/teacher into a small policy [A04](https://arxiv.org/abs/1511.06295) | Teacher outputs across broad state coverage | Low runtime; deterministic | Distils teacher mistakes and may lose rare safety behaviour | **Use only behind deterministic legality/safety.** |
| Distilled decision tree / lookup table | Convert learned or tuned policy into inspectable branches | State/action dataset | Very low CPU/memory; reproducible | Trees grow large; discontinuities and overfit | **Preferred learned endpoint** when quality matches a neural policy. |
| Tiny quantized neural policy | Score safe candidates from a compact state vector | Label/reward data and quantization calibration | Low on CPU when tiny; can batch on NPU; integer inference is practical [A06](https://arxiv.org/abs/1712.05877) | Data extraction may dominate; opaque errors; accelerator fallback differences | **Optional tactical scorer**, only after CPU deterministic baseline. |
| Hybrid learned scoring + deterministic gate | Candidate actions generated and validated deterministically; model only ranks them | Moderate trace dataset | Bounded output and easy CPU fallback | Model can rank badly but cannot execute illegal action | **Only learned architecture recommended for runtime.** |
| End-to-end neural agent | Choose arbitrary combat/movement actions from raw server state | Enormous data/simulator effort | High integration and validation cost | Safety, reproducibility, hidden-state cheating and debugging failures | **Reject.** It discards known structure and offers poor risk/cost. |

## 7.5 Explicitly rejected uses

The following should not be pursued for this target:

- neural pathfinding without a concrete graph formulation that outperforms A*/navmesh end to end;
- neural database/world-state querying;
- a model deciding spell legality, cooldown, inventory validity or command authorization;
- high-frequency language generation;
- per-bot large language models or agentic tool loops;
- unconstrained GOAP/HTN search in the combat reaction path;
- online reinforcement-learning exploration in a live dungeon, raid or PvP match;
- learned perception from pixels when exact structured state is already available;
- counting background characters as “500 intelligent bots” while suppressing their simulation without disclosure.

# 8. Radical redesign alternatives

## 8.1 Alternative A: improve the existing architecture

### Design

Preserve the four Engines and trigger/strategy/action model, but:

- forward and validate the minimal-update flag;
- replace random activity gating with deterministic staggered deadlines;
- add typed hot snapshots and numeric IDs;
- introduce scoped shared Values;
- preallocate candidate storage and reduce Queue scans;
- add party reservation Values;
- improve reaction timing and personality parameters;
- expand replay tests and profiler precision.

### Advantages

This has the lowest migration risk and maximum compatibility. It can remove substantial repeated work without changing most class logic. It is the correct near-term path even if a larger redesign follows.

### Ceiling

A flat set of Strategies and triggers remains hard to reason about as behaviours grow. Party plans, phase transitions and high-level intent would still be layered onto an architecture optimized for immediate action selection.

## 8.2 Alternative B: hybrid hierarchical utility plus blackboard — preferred

### Design

Retain deterministic Actions and much class knowledge, but introduce:

1. an event-driven typed perception/snapshot layer;
2. a deadline scheduler and workload classes;
3. a hierarchical mode/intention controller;
4. a shared party/encounter blackboard with reservations;
5. a bounded hierarchical utility scorer;
6. deterministic formation/hazard/LOS solvers;
7. optional learned ranking for a small safe candidate set.

### Advantages

This directly addresses the largest behavioural and scaling limitations while preserving mature integration. It gives each decision a reason trace: observed facts, current intent, reservations, candidate utilities, legality rejection and final action.

### Risks

The main risk is running old and new orchestration simultaneously for too long. Migration should use an adapter where existing Actions are invoked from the new selector, with scenario-by-scenario replacement of old trigger composition.

## 8.3 Alternative C: substantial high-level redesign

Several substantial redesigns are possible.

### Behaviour-tree / HFSM orchestration

A hierarchical state machine plus behaviour trees can make command, travel, recovery and encounter flows explicit. It improves readability and deterministic testing. However, a behaviour tree alone does not solve shared perception, party reservations, tactical scoring or path concentration. Large trees can repeat conditions and become difficult to prioritize. [A01](https://arxiv.org/abs/1709.00084)

### Planner-heavy GOAP / HTN

A planner can create multi-step plans and reduce hand-wired transitions. F.E.A.R. demonstrated that practical planning can manage combinations of behaviours that become unwieldy in finite-state logic. [A02](https://www.gamedevs.org/uploads/three-states-plan-ai-of-fear.pdf) Yet Playerbots combat has frequent invalidation, many actors and strict latency. Planner use should therefore be bounded to slow-path goals or small phase plans; a planner-heavy combat core is too variable for the target hardware.

### Learned high-level policy

A compact learned high-level intent policy could eventually choose between retreat, control, burst, recover, reposition and objective play. It still requires deterministic state masking, safety, party commitments and a CPU fallback. It is an option inside Alternative B, not a reason to discard the architecture.

## 8.4 Decision matrix

Scores are expert judgement from 1 (poor) to 5 (strong), not measured performance. For **implementation effort** and **risk**, 5 means low effort/low risk. Totals are unweighted out of 55; behaviour, CPU and risk gates still override total score.

| Candidate | Behaviour quality | Believability | CPU efficiency | Population scaling | Memory | NPU usefulness | Implementation effort | Debug/test | CMaNGOS compatibility | Offline | Low risk | Total /55 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A. Optimized existing trigger/strategy system | 3 | 3 | 4 | 4 | 4 | 1 | 4 | 4 | 5 | 5 | 4 | **41** |
| B. Hierarchical utility + blackboard + scheduler | 5 | 5 | 4 | 5 | 4 | 3 | 3 | 4 | 5 | 5 | 4 | **47** |
| C. Behaviour-tree/HFSM orchestration | 4 | 4 | 4 | 4 | 4 | 2 | 2 | 4 | 4 | 5 | 3 | **38** |
| D. GOAP/HTN-heavy tactical planner | 4 | 4 | 2 | 2 | 3 | 2 | 2 | 2 | 3 | 5 | 2 | **31** |
| E. End-to-end learned policy | 3 | 3 | 2 | 2 | 3 | 4 | 1 | 1 | 2 | 5 | 1 | **27** |

Alternative B wins because it improves coordination, scheduling and repeated computation together. Alternative A is the correct CPU-only fallback and migration stage. Behaviour trees and bounded task plans remain useful tools inside B rather than competing whole-system ideologies.

# 9. Snapdragon 8 Gen 2 NPU feasibility

## 9.1 Hardware capability versus useful workload

The Snapdragon 8 Gen 2 product brief lists a Hexagon processor with fused AI accelerator architecture, tensor/vector/scalar components, mixed INT8/INT16 and support for INT4, INT8, INT16 and FP16. This establishes that low-precision inference hardware exists. It does not establish that a tiny Playerbots policy will be faster end to end than optimized CPU code. [H02](https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Snapdragon-8-Gen-2-Product-Brief.pdf)

The Playerbots workload is dominated by structured state acquisition, branching logic, game-engine calls, pathfinding and database/session work. Most of that is unsuitable for an NPU. The only plausible NPU workload is a dense, fixed-shape numerical scorer whose inputs have already been extracted for deterministic AI.

## 9.2 Access paths from a native Android server

| Route | Native access | Current status and constraints | Suitability |
|---|---|---|---|
| Android NNAPI C API | Native C API from NDK, API 27+ [H04](https://developer.android.com/ndk/guides/neuralnetworks) | Deprecated in Android 15; driver selection and CPU fallback can be opaque; migration guidance points developers toward newer runtimes [H03](https://developer.android.com/ndk/guides/neuralnetworks/migration-guide) | **Not preferred for new deployment.** Useful only as compatibility experiment on a fixed device/OS. |
| Qualcomm AI Engine Direct / QNN | Lower-level C-like APIs target Kryo CPU, Adreno GPU or Hexagon NPU; can delegate from LiteRT or ONNX Runtime [H05](https://www.qualcomm.com/developer/software/qualcomm-ai-engine-direct-sdk) | Requires Qualcomm SDK/runtime integration and review of product licence/redistribution terms | **Best control path** for a fixed Snapdragon device if licensing/deployment is acceptable. |
| LiteRT QNN `CompiledModel` | Native integration through LiteRT; supports AOT and on-device compilation; Android build guidance targets API 34 and supports NDK API 28 [H06](https://developers.google.com/edge/litert/next/qualcomm) | Operator support and model compilation workflow must match the device; adds LiteRT integration | **Strong prototype path**, especially for a small static model. |
| ONNX Runtime QNN EP | C++ API; HTP backend targets the NPU; quantized models, context binaries and backend/performance options are documented [H07](https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html) | Android builds require QNN SDK integration; verify no unsupported node silently falls back to CPU | **Strong research path** if ONNX tooling is preferred. |

A native C++ game-server process can call a native QNN/LiteRT/ONNX Runtime API directly. JNI is needed only when Java/Kotlin owns lifecycle or when the chosen wrapper is Java-facing. IPC is optional and may be desirable for crash isolation and thermal control, but it adds serialization and scheduling latency.

## 9.3 Model and deployment constraints

A sensible model would have:

- fixed or a small set of static batch shapes;
- compact input vectors built from the typed tactical snapshot;
- INT8 activations/weights where supported;
- only operators fully supported by the HTP path;
- precompiled/context-binary caching where available;
- deterministic output interpretation and a model-version hash;
- a CPU implementation with identical quantization/scaling;
- no dynamic control flow or variable-length object lists inside the model.

QNN/ONNX documentation emphasizes quantized HTP workloads, backend configuration, graph finalization and CPU fallback controls. The benchmark must explicitly disable or detect fallback; otherwise “NPU” timing may include CPU-executed nodes. [H07](https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html)

Qualcomm’s public SDK page states that the SDK is governed by a product licence agreement. Redistribution of runtime libraries and model tooling must be checked against the exact downloaded SDK terms. This report cannot establish private licence terms from the public overview. [H05](https://www.qualcomm.com/developer/software/qualcomm-ai-engine-direct-sdk)

## 9.4 Overheads that can erase accelerator benefit

For a tiny policy, matrix execution may be the smallest part of latency. Measure:

1. state extraction from Playerbots/CMaNGOS structures;
2. quantization and tensor packing;
3. queueing until a batch/deadline;
4. accelerator wake-up/RPC cost;
5. model execution;
6. output transfer and synchronization;
7. result dequantization;
8. staleness/version check;
9. deterministic legality/safety validation;
10. action/reservation application;
11. CPU fallback when the NPU is busy, unavailable or misses a deadline.

A per-bot policy invoked at high frequency is unlikely to amortize this path. The plausible design batches eligible bots at a medium or low tactical cadence and never delays urgent reactions waiting for a batch.

## 9.5 Candidate NPU tasks

| Task | Input/output | Frequency and batching | Why it may fit | Deterministic alternative |
|---|---|---|---|---|
| Tactical action scoring | Compact bot/party/target vector → scores for already-legal candidates | Medium cadence; batch across bots | Dense fixed-shape ranking; no direct engine calls inside model | Hand-tuned hierarchical utility, linear model or decision tree |
| Target prioritization | Observable target features → priority score/class | On target/cast changes; batch party/BG bots | Many similar rows; bounded output | Weighted target utility and reservations |
| Positioning classification | Candidate-position features → safe role/class score | Only when replanning; batch candidates | Classifies LOS, hazard, role suitability after deterministic reachability | Deterministic weighted assignment/Hungarian or greedy solver |
| Danger estimation | Local compact features → danger/risk bucket | Low/medium cadence | May learn nonlinear combinations of crowd, health and cooldowns | Piecewise utility/influence map |
| High-level intent | Party/encounter summary → retreat/control/burst/recover/objective scores | Low cadence | Large amortization window; limited action set | HFSM plus utility thresholds |
| Optional social-response classification | Text/intent features → select a canned response/personality state | Infrequent | Could be tiny, but CPU is already sufficient | Rules/embeddings/lookup; likely no NPU need |

## 9.6 Tasks that should remain off the NPU

- local or route pathfinding;
- navmesh queries and LOS ray tests;
- ObjectMgr, grid or database searches;
- inventory, spell and target legality;
- command authorization and ownership;
- hard encounter mechanics and safety constraints;
- high-frequency language generation;
- any task whose state-preparation cost exceeds the CPU decision it replaces.

## 9.7 Asynchronous design and stale results

The NPU worker should consume immutable snapshot batches tagged with bot ID, encounter ID and generation number. Results have a deadline. The world thread applies a result only when:

- the generation is still current;
- the intended action remains in the deterministic legal candidate set;
- reservation ownership is valid;
- the result arrived before its deadline.

Otherwise it is discarded and the CPU fallback acts. This prevents the accelerator from blocking world ticks or applying decisions to changed combat state.

## 9.8 Thermal, battery and interference

The device may run both the server and the WoW client. NPU use can reduce CPU work for a sufficiently large batch, but it also consumes shared power/thermal headroom and memory bandwidth. It may indirectly lower CPU/GPU frequency or compete with graphics and display workloads. Benchmark with the actual client rendering and with screen brightness/charging/cooling controlled. Report sustained frequencies and temperatures, not only short inference latency.

## 9.9 End-to-end NPU benchmark

Compare four implementations using the same snapshot and candidate set:

1. current deterministic Playerbots decision;
2. improved CPU-only hierarchical utility decision;
3. tiny quantized neural policy on CPU;
4. the identical quantized policy on the NPU.

For batch sizes 1, 8, 16, 32, 64 and 128 where memory permits, report cold-load and warm-run results for:

- extraction time;
- packing/quantization time;
- queue wait;
- accelerator wake/RPC;
- model execution;
- synchronization/copy;
- deterministic validation/application;
- complete end-to-end latency;
- missed/stale result rate;
- CPU time saved on the world thread;
- world-tick p50/p95/p99;
- power, temperature and sustained CPU/GPU frequency;
- behaviour score on held-out traces.

**NPU acceptance gate:** use it only if end-to-end world-thread cost and sustained thermal behaviour are better than both the improved deterministic CPU scorer and the tiny CPU neural policy, while behaviour is at least as good and fallback is seamless. Accelerator kernel time alone is not an acceptance metric.

## 9.10 Language models are a separate optional subsystem

The public `PlayerbotLLMInterface` is not a tactical policy. It contains text/encoding and JSON sanitation, request construction, DNS/socket/TLS handling, send/receive logic and response parsing. The generation path includes blocking network operations internally and a sleep-based receive loop, while the source commentary describes generation as asynchronous and intentionally delayed. A bounded global generation count limits concurrency. [C29](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLLMInterface.cpp)

This makes the correct architectural boundary clear:

- the world thread emits a compact social event into a queue;
- a separate worker or process selects a canned response or invokes a local model;
- the response has no authority over combat, movement, target selection, inventory or commands;
- the response is discarded when stale, the bot is busy, or thermal/tick pressure is high;
- all model prompts and outputs are optional flavour, not correctness state.

A compact local model may have value for rare dialogue, paraphrasing and personality-consistent social replies. Cloud inference is excluded by the requirement. On Snapdragon, even a compact model competes for RAM, memory bandwidth and thermal headroom with the server and client. The default recommendation is therefore a deterministic response bank/personality state machine. A local model should be enabled only after a sustained test shows no world-tick or client regression. The public interface implementation was examined, but a complete call-site frequency map could not be established from the available public search results and must be verified in the actual build.

# 10. Recommended architecture

## 10.1 Overview

![Figure 4. Recommended event-driven hierarchical utility architecture.](images/figure_4_recommended_architecture.png)

*Figure 4. Recommended event-driven hierarchical utility architecture.*

The recommended architecture is a layered hybrid in which learning is optional and deterministic systems retain authority.

## 10.2 Layer 1: event-driven perception and typed snapshots

Create a read-only tactical snapshot per bot decision from shared versioned sources. Events mark fields dirty; a low-rate validation pass detects missed invalidations. The snapshot contains only observable information and records observation age/confidence. It becomes the common interface for:

- current deterministic utility;
- replay tests;
- a decision tree or small neural scorer;
- logs explaining why an action was selected;
- cross-version behaviour comparison.

Slow-path named Values can remain for configuration, diagnostics and uncommon activities. Hot combat state should use numeric IDs, arrays and bitsets.

## 10.3 Layer 2: deadline scheduler and temporal level of detail

Replace probabilistic activity gating with ready queues keyed by:

- workload class;
- next deadline;
- event urgency;
- human visibility/association;
- encounter/group priority;
- fairness age;
- estimated cost.

Every tick receives an AI budget derived from world-tick headroom. Work runs until the budget is consumed, except hard safety deadlines that must run or trigger explicit population/fidelity reduction. The scheduler publishes counts and missed deadlines by class.

The first implementation must forward `minimal` correctly so existing behaviour can be measured before the new scheduler replaces it. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp)

## 10.4 Layer 3: hierarchical mode and intent

Use a small HFSM for durable modes:

- dead/recover;
- travel;
- social/maintenance;
- quest/activity;
- regroup/recover resources;
- prepare pull;
- combat;
- flee/disengage;
- dungeon/raid mechanic;
- battleground objective.

Within a mode, low-frequency intent chooses goals; medium-frequency tactics choose role commitments; immediate reactions handle interrupts, hazard escape, lifesaving casts and commands. This avoids running quest, social and maintenance Strategies through the same candidate machinery during urgent combat.

## 10.5 Layer 4: party and encounter blackboard

A blackboard should include:

| Field group | Examples |
|---|---|
| Identity/version | party ID, encounter ID, phase generation, update timestamp |
| Human intent | leader command, target marker, stay/follow/formation, command priority and expiry |
| Roles | primary/secondary tank, healers, interrupt order, dispel capabilities, CC capabilities |
| Target plan | pull target, kill order, protected CC targets, no-AOE flag, retreat target |
| Reservations | action type, target, owner, start, expiry, backup order, expected effect |
| Threat plan | tank ownership, taunt transfer, threat ceiling for DPS, kite/flee assignment |
| Healing plan | predicted damage events, assigned healer, incoming heal ledger, emergency override |
| Cast control | enemy cast value, assigned interrupt, backup deadline, immunity/DR knowledge that is observable/configured |
| Position plan | formation slots, hazard regions, LOS anchors, melee/ranged envelopes, path corridor |
| Recovery | drink/eat/resurrect/loot readiness and next-pull gate |
| Reason trace | why plan changed, rejected commitments and command conflicts |

Reservations expire automatically, are invalidated by death/LOS/range/cooldown changes and have deterministic backup rules. They are advisory until the final legality gate.

## 10.6 Layer 5: hierarchical utility

Utility scoring operates on a small candidate set derived from current intent. A score should be decomposable:

`U(action) = goal_value + tactical_value + urgency + role_fit + coordination_value - risk - resource_cost - movement_cost - repetition_penalty`

Each term is logged. Hard illegality does not become a large negative score; it removes the candidate. Hysteresis prevents oscillation between near-equal actions. Personality can perturb soft terms within bounded ranges but cannot override safety or commands.

## 10.7 Layer 6: tactical positioning and formation

The position service should generate a small deterministic set of reachable candidates, then solve assignments using shared costs:

- navmesh reachability and path length;
- LOS to intended target and healer;
- range envelope for role/spell;
- hazard/influence cost;
- accidental-pull exposure;
- tank facing and enemy cleave cone;
- distance to assigned formation slot;
- crowding/collision and movement churn;
- future phase/route cost.

Use hysteresis and minimum commitment time to stop jitter. Replan only on relevant events: hazard creation, target movement, LOS loss, phase change, path failure or human command.

## 10.8 Layer 7: deterministic legality and safety

The following responsibilities must remain deterministic:

- spell/item existence, cooldown and resource checks;
- target validity, visibility, range and LOS;
- movement reachability and forbidden terrain;
- command authorization and explicit human overrides;
- threat/tank hard constraints and protected CC targets;
- encounter mechanics that cause immediate failure;
- reservation ownership and expiry;
- observation masking and anti-omniscience rules;
- model output bounds and stale-result rejection.

## 10.9 Optional learned scorer

A learned component is justified only for ranking among legal candidates when deterministic utility has a documented quality ceiling. Preferred deployment order is:

1. tuneable deterministic utility;
2. linear model or compact decision tree;
3. tiny quantized neural policy on CPU;
4. identical policy on NPU if end-to-end superior.

The model never receives hidden state that the deterministic observation layer would mask. Training traces include state, candidates, chosen action, result, human correction and reason labels. Development-time RL or imitation may create a teacher, but the runtime endpoint should be distilled and bounded.

## 10.10 CPU-only fallback architecture

The CPU-only fallback is not the old system untouched. It is the same event/snapshot/scheduler/blackboard architecture with deterministic hierarchical utility and no neural inference. This should be considered the baseline product architecture because it is portable, reproducible and likely sufficient.

## 10.11 What to retain, rework and replace

| Disposition | Public components / responsibility |
|---|---|
| **Retain** | Most existing Actions; class/spec spell knowledge; deterministic spell/target legality; CMaNGOS adapters; packet hooks; route graph data; character factory/lifecycle concepts; command compatibility; useful encounter scripts as adapters |
| **Rework** | Engine orchestration, trigger activation, named Value hot path, activity priorities, shared target/perception, manager scans, login pacing, PerformanceMonitor, reaction timing, command parsing into typed intents |
| **Replace** | Random/coarse scheduling as the main population mechanism; per-bot repeated perception for shared facts; implicit party coordination; flat broad candidate selection in high-load tiers; unbounded bespoke positioning fixes |
| **Keep outside** | LLM/social generation, analytics export and training pipelines |

## 10.12 Believability without deliberate stupidity

Believability should come from limited observation and human-like timing, not random bad actions. Use:

- observation timestamps and decay;
- line-of-sight and awareness constraints;
- reaction-delay distributions by role, personality and mechanic urgency;
- seeded variation in target/risk preferences;
- cooldown/communication delays for party plan changes;
- short-term memory of seen enemies rather than exact hidden tracking;
- repetition penalties and alternative equivalent actions;
- occasional social/cosmetic variation only when CPU headroom exists.

A bot should fail because it had limited information, a plausible delayed reaction or a tactical mistake within its profile—not because the scheduler silently skipped all thinking.

# 11. Behaviour and performance benchmark plan

## 11.1 Benchmark principles

Every alternative AI must be tested from the same observable state, with the same CMaNGOS data, spell legality and random seed. Tests should separate competence, believability and resource cost. A system does not pass by achieving higher DPS through hidden state, instant reaction or excessive path/object queries.

The harness needs two modes:

1. **Deterministic scenario mode:** scripted actors, fixed geometry, fixed latency/seed and resettable initial state.
2. **Replay/state-trace mode:** recorded observable snapshots and candidate sets are replayed through alternative selectors without running the whole world. Full-world validation then confirms that replay predictions transfer to execution.

Every trace should include public build SHA, database revision, config hash, class/spec/equipment, map, workload class and observation mask.

## 11.2 Instrumentation required before behaviour comparison

Replace or augment PerformanceMonitor with:

- monotonic nanosecond timestamps;
- numeric subsystem IDs and a source map;
- world-tick start/end and over-budget marker;
- per-bot and per-party decision deadlines;
- trigger checks, Value hits/recomputes and candidate counts;
- CMaNGOS object, group, threat, LOS and path calls initiated by AI;
- PathFinder request count, result, path size and duration;
- allocations/frees and bytes by Playerbots subsystem;
- packet-queue delay and lock wait/failure counts;
- database query count, queue wait and execution time;
- login holder, world insertion and save duration;
- CPU affinity/frequency, thermal status and process energy signals;
- RSS/PSS and heap snapshots;
- reason traces for selected/rejected actions.

Sampling and counters should be cheap enough to leave enabled in development. Full traces can be activated for a subset of bots or ticks.

## 11.3 Behaviour scenario catalogue

| Scenario | Setup | Competence metrics | Believability / fairness checks |
|---|---|---|---|
| Class rotation baseline | Stationary target dummy; fixed level, gear, buffs and duration for each class/spec archetype | Damage/healing, resource waste, downtime, illegal/failed casts, action distribution | No impossible pre-cast knowledge; stable but not identical timing across personalities |
| Target selection | Multiple enemies with different threat, health, cast value, CC and raid markers | Correct primary target, switches, protected-target violations | Uses only visible/communicated information; avoids frame-perfect synchronized switches |
| Threat control | Tank plus DPS; scripted threat spikes and target changes | Threat violations, taunt correctness, target ownership, avoidable deaths | DPS backs off with plausible delay; no exact hidden threshold exploitation |
| Multi-healer triage | Five-person party with predictable and random burst patterns | Survival, overhealing, duplicate heals, cancelled casts, mana efficiency | Healers communicate/reserve rather than reacting simultaneously |
| Interrupt rotation | Two or more interrupters; low- and high-value enemy casts; cooldown overlaps | Missed high-value interrupts, duplicate interrupts, wasted cooldowns, backup success | Reaction-time distribution and cast visibility constraints |
| Dispels | Mixed harmful auras, low/high priority effects and false positives | Precision, recall, time to dispel, wasted dispels | Does not dispel before aura is observable; role-based latency |
| Crowd control | Multi-pack with marked and unmarked targets, DoTs and break risk | Correct CC, overlap, refresh, break rate, protected-target damage | Reservations and plausible communication delay |
| Pull safety | Corridor/room with patrols, neutral packs and LOS pull option | Unintended pulls, encounter size, recovery success, path/LOS cost | Avoids omniscient patrol timing outside observation |
| Position / LOS | Pillars, corners, melee/ranged/healer roles | LOS failures, movement time, cast interruption, unreachable choices | Natural repositioning and hysteresis; no jitter or instant teleport when visible |
| Hazard avoidance | Deterministic moving/static hazard fields | Exposure time, avoidable damage/deaths, path requests | Reaction delay within role/mechanic envelope; no pre-avoidance before cue |
| Formation and crowding | Narrow and open spaces, 5/10/20/40 actors | Slot conflicts, collision/crowding, LOS coverage, pull exposure | Stable formation with bounded variation |
| Boss phase transition | Scripted phase signals, adds, target immunity and role swap | Phase success, assignment uptake, missed mechanics, recovery | Plan changes after observable cue; no future-phase knowledge |
| Human follow | Walk/run/jump/turn, doors, transports and sudden direction changes | Distance error, stuck time, path failures, accidental pulls | Smooth lag and spacing; respects stay/formation intent |
| Human commands | Follow, stay, attack, pull, focus heal, retreat and strategy changes | Acknowledgement, application latency, conflict resolution, failure reason | Immediate wake without impossible execution; clear acknowledgement |
| Travel / unsticking | Route segments with town geometry, flight/taxi transitions and known traps | Completion rate, travel time, stuck seconds, recovery attempts, path calls | Hidden reduced-fidelity movement only when not observable |
| Quest completion | Fixed quest chain with pickup, kill, item, object and turn-in steps | Completion, invalid action attempts, DB/object queries, recovery from missing target | No direct use of undiscovered/hidden object state beyond configured world knowledge |
| Battleground objective | Controlled teams, flags/nodes, respawn and opponent uncertainty | Objective score, deaths, target choice, coordination, path pressure | No exact unseen-opponent tracking; varied but coherent strategy |
| PvP duel/skirmish | Mirrored gear/spec, seeded opponent policies | Win rate, cooldown/resource use, positioning and target switches | Reaction latency and hidden-state A/B tests |
| Login storm | Pre-generated characters log in at controlled rates | World-tick tail, holder/query time, insertion failures, memory peak | Not a behaviour score; verifies graceful pacing |
| Concentrated combat | Large bot sets in one cell/instance with synchronized events | p95/p99 tick, deadline misses, path/LOS/query bursts | Visible bots retain quality; scheduler reports degraded classes honestly |

## 11.4 Metrics

### Competence

- encounter success rate;
- avoidable deaths and damage;
- threat violations and inappropriate taunts;
- missed high-value interrupts and duplicate interrupt rate;
- dispel precision/recall and time to dispel;
- overhealing, duplicate incoming heals and mana waste;
- crowd-control overlap, break rate and refresh gaps;
- unintended pulls and maximum unintended encounter size;
- positioning/LOS errors and hazard exposure;
- time stuck, recovery attempts and route completion;
- command acknowledgement and execution latency;
- quest completion and invalid interaction rate;
- battleground objective contribution, not only kills.

### Believability

- reaction-time distribution by event and personality;
- action-sequence entropy, repeated n-grams and autocorrelation;
- simultaneous identical choices across bots;
- target-switch and movement hysteresis;
- observable-state compliance;
- hidden-state leakage score;
- path/formation smoothness and stop-start frequency;
- rate of command acknowledgement and understandable refusal;
- social/cosmetic repetition, measured separately from combat.

### Performance

- CPU time by Playerbots and called CMaNGOS subsystem;
- end-to-end decision latency and missed deadlines;
- trigger checks, Value lookups/recomputes and candidate counts;
- object/group/threat searches;
- path/LOS requests and cache hit rate;
- allocations and memory per bot/party/map;
- database queries/waits and login insertion cost;
- world-tick median, p95, p99 and maximum;
- process RSS/PSS, device temperature, CPU frequencies, energy and throttling.

## 11.5 Anti-omniscience tests

Create paired scenarios where observable state is identical but hidden state differs. Examples:

- an unseen enemy changes target behind a wall;
- a patrol path differs outside line of sight;
- an opponent cooldown is changed without a visible cue;
- a stealthed unit is present in only one branch;
- a boss phase timer differs before the public transition signal.

The bot’s action distribution must remain the same until an observable event occurs. Logs should show the observation used. Direct CMaNGOS pointers can remain available to deterministic legality after a candidate is chosen, but the scorer must not consume hidden facts.

## 11.6 Reaction-time benchmark

For each event type, define:

- earliest plausible response;
- target distribution by role/personality;
- maximum safe deadline for critical mechanics;
- exception policy for immediate self-preservation;
- seed and observation timestamp.

Measure cast start to interrupt, damage to defensive/heal, hazard cue to movement, command receipt to acknowledgement and command to first compliant action. Competence and believability should be shown on the same chart; a zero-latency policy should not win by cheating.

## 11.7 Replay design

A replay record should contain:

- typed observable snapshot;
- active intent and party blackboard;
- legal candidate IDs and deterministic costs;
- selected action and reason terms;
- subsequent outcome windows;
- source build/config/data hashes;
- random/personality seed.

Alternative selectors run against identical records. For multi-step policies, use a deterministic simulator or re-run the full scenario because one changed action alters future state. Replays are most useful for unit-level score/legality comparisons and regression detection; full-world runs remain the final authority.

## 11.8 Population and concentration matrix

A complete performance report should vary both total population and active concentration. At minimum, test population levels appropriate to device capacity, including the target 500, across these mixes:

| Mix | Description | Purpose |
|---|---|---|
| Dispersed background | Most bots remote, no humans nearby | Establish honest background cost |
| Travelling | Many bots advancing along routes | Route/cache and movement pressure |
| Human-visible world | Bots distributed around one or more humans | Perception, movement and packet quality |
| Party companions | Several human-led groups | Command and blackboard cost |
| Same-zone combat | Many independent fights in one zone | Grid/object/path concentration |
| One dungeon/raid | 5/10/20/40 tightly coordinated actors | Worst party coordination and mechanic load |
| Battleground | Objective movement, respawn and packet bursts | PvP and packet concentration |
| Login storm | Controlled additions per interval | Transient DB/session/world insertion |

Report the actual counts in every class for every sample. A result without this distribution is not comparable.

## 11.9 Acceptance criteria framework

Do not choose arbitrary percentage improvements before baseline. Use falsifiable gates:

- **Correctness:** no increase in illegal actions, protected-CC damage, command violations or crash rate.
- **Behaviour:** predefined scenario metrics improve or remain within a non-inferiority bound established from repeated baseline runs.
- **Latency:** urgent events complete before their declared decision deadline; p99 world tick meets the selected realm service level.
- **CPU:** matched-fidelity Playerbots CPU and core-query CPU do not increase unless a measured behaviour gain justifies it.
- **Memory:** shared state reaches break-even at the measured population and does not create unbounded caches.
- **Thermal:** sustained run does not progressively miss deadlines as the device throttles.
- **Reproducibility:** same build, trace and seed produce the same reasoned decision.

# 12. Three initial prototypes

## Prototype 1 — measurement, minimal-update repair and deterministic scheduler

### Falsifiable hypothesis

Forwarding the existing minimal flag, instrumenting the complete update path, replacing synchronized/probabilistic readiness with deterministic deadlines, and sharing human-nearby classification will reduce Playerbots/world-tick tail cost at matched visible behaviour.

### Behaviour being improved

Responsiveness under population load, reliable wakeup when a human approaches, and avoidance of background work stealing time from human party/combat bots.

### Public source areas likely to change

`Map.cpp`, `Player.cpp`, `PlayerbotAI.h/.cpp`, `PlayerbotAIBase.cpp`, activity-priority code, `PlayerbotAIConfig.cpp`, `RandomPlayerbotMgr.cpp` and `PerformanceMonitor.cpp`. [C31](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) [C32](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp) [C01](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) [C02](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h) [C03](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIBase.cpp) [C10](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIConfig.cpp) [C11](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PerformanceMonitor.cpp) [C12](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp)

### Minimal design

1. Forward `minimal` without changing policy; prove it reaches PlayerbotAI.
2. Add numeric high-resolution scopes and per-tick ready/updated bot counts.
3. Record workload class and reason for each update/skip.
4. Replace map-wide random readiness with stable staggered deadlines for an experiment branch.
5. Add immediate wake events for combat, command, human visibility and path failure.
6. Build a shared map/cell index for “human nearby” and compare against the per-bot loop.
7. Keep the old scheduler as an A/B switch.

### Representative scenarios

- 0, 50, 100, 250 and 500 pre-generated bots where the device permits;
- dispersed background versus same-zone concentration;
- human teleports into an inactive bot area;
- command sent to a delayed companion;
- synchronized combat start;
- login storm tested separately;
- sustained thermal run with the WoW client active.

### CPU, memory and latency budgets

- **CPU budget:** scheduler/instrumentation overhead must be lower than the work it removes at target population; matched-fidelity total Playerbots plus called-core CPU must not increase.
- **Memory budget:** shared human-zone/deadline state must remain `O(cells + bots)` with bounded queues; no per-tick heap growth.
- **Latency budget:** combat, command and human-visibility wakeups must be eligible by the next world tick and acted on by the normal reaction deadline; background deadlines may slip only with an explicit counter.

### Success criteria

- verified end-to-end minimal flag;
- lower or equal p95/p99 tick at matched active-class counts;
- no increase in command or combat deadline misses;
- flatter per-tick ready-bot histogram;
- no visible freeze when a human enters a background area;
- profiling overhead quantified and bounded.

### Rejection criteria

Reject the new scheduler if it lowers average CPU but increases p99 stalls, misses urgent wakeups, or makes human-visible bots noticeably inert. If forwarding `minimal` produces no material change, retain the correctness fix but do not claim it as a performance win.

### Simpler alternative

Increase `reactDelay`, reduce bot count or increase passive delays. This is the control experiment. It is acceptable only if behaviour benchmarks show no visible degradation; otherwise it is not an architectural solution.

## Prototype 2 — party tactical blackboard and reservations

### Falsifiable hypothesis

A shared party blackboard with expiring reservations for heals, interrupts, dispels, crowd control, target ownership and position will reduce duplicated actions and improve encounter success without increasing world-tick tail cost.

### Behaviour being improved

Multi-healer triage, interrupt rotation, dispel precision, CC stability, tank/DPS target ownership, pull discipline and formation.

### Public source areas likely to change

`AttackersValue.cpp`, health/generic/cure Triggers, crowd-control target Values, target-selection Actions, combat Strategies, generic spell Actions, dungeon Actions and AiObjectContext integration. [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) [C21](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) [C22](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) [C23](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp) [C24](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/ChooseTargetActions.cpp) [C25](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/generic/CombatStrategy.cpp) [C26](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp) [C19](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) [C28](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp) [C08](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp)

### Minimal design

1. Create a typed per-party blackboard with generation and event log.
2. Add one reservation type at a time: interrupt, heal, dispel, CC, target and position.
3. Reservations have owner, target, expected effect, start, expiry, backup eligibility and cancellation reason.
4. Existing Actions remain unchanged; their usefulness/selection consults reservations.
5. A deterministic coordinator computes commitments from shared snapshots.
6. Record every reservation and takeover for replay.

### Representative scenarios

- two healers and scripted burst damage;
- three interrupt-capable bots and overlapping high/low-value casts;
- mixed dispellable debuffs;
- marked CC pack with DoT/AOE risk;
- tank target ownership and taunt transfer;
- narrow-room formation with a human leader;
- reservation owner death, LOS loss and cooldown failure.

### CPU, memory and latency budgets

- **CPU budget:** coordinator cost plus blackboard access must be no greater than the duplicated per-bot query and failed-cast work it replaces at the tested party size.
- **Memory budget:** bounded per party/encounter; reservations expire and logs use a fixed ring buffer.
- **Latency budget:** urgent interrupt/heal reservations are created within the relevant event deadline; backup takeover occurs before the action window closes.

### Success criteria

- fewer duplicate interrupts/heals/dispels;
- fewer missed high-value casts and protected-CC breaks;
- lower overheal and threat violations without reduced survival;
- no p99 regression at matched party size;
- deterministic reason trace for assignment and backup;
- human commands override or constrain the plan predictably.

### Rejection criteria

Reject or simplify any reservation type that creates central bottlenecks, stale locks, worse emergency response or no measurable improvement over static priority ordering.

### Simpler alternative

Assign fixed role priority and deterministic cooldown staggering without a general blackboard. Use it as the comparison. If it performs equally across held-out scenarios, retain the simpler scheme for that action type.

## Prototype 3 — tactical scorer bake-off: deterministic, CPU neural and NPU

### Falsifiable hypothesis

A compact scorer can improve target/action/position ranking on held-out scenarios, and batched NPU execution may reduce end-to-end world-thread cost versus the same quantized model on CPU. If a deterministic tree/utility model matches quality or total NPU latency is worse, machine learning/NPU should be rejected for runtime.

### Behaviour being improved

Target priority, danger estimation, reposition-versus-cast decisions and low-frequency tactical intent. Legality, path reachability and safety remain deterministic.

### Public source areas likely to change

Typed snapshot/candidate interfaces around Engine relevance/Multipliers, target Values, positioning candidate scoring and a separate optional QNN/LiteRT/ONNX worker. Existing Actions and CMaNGOS legality code remain unchanged. [C04](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) [C20](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) [C18](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp) [H05](https://www.qualcomm.com/developer/software/qualcomm-ai-engine-direct-sdk) [H06](https://developers.google.com/edge/litert/next/qualcomm) [H07](https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html)

### Minimal design

1. Select one narrow task, preferably target priority or danger class.
2. Define a fixed observable input vector and safe candidate set.
3. Build four scorers: current logic, improved deterministic utility/tree, tiny INT8 model on CPU, same model on NPU.
4. Train only from deterministic scenario traces and held-out maps/encounters; include counterfactual hidden-state pairs.
5. Batch medium/low-urgency requests; urgent reactions use CPU fallback.
6. Tag results by generation/deadline and discard stale output.
7. Measure cold load, warm load and sustained thermal runs.

### Representative scenarios

- multi-target packs with cast/threat/CC trade-offs;
- hazard and LOS position candidates;
- PvP target switches under observable uncertainty;
- high-level retreat/control/burst choices;
- batch sizes 1, 8, 16, 32, 64 and 128 where feasible;
- simultaneous client rendering and server load.

### CPU, memory and latency budgets

- **CPU budget:** complete state extraction + scoring + validation must use less world-thread CPU than the deterministic baseline it replaces, or deliver a behaviour improvement large enough to justify the measured cost.
- **Memory budget:** model, runtime and tensors must remain bounded and must not force bot or path caches out of useful memory; report runtime-library overhead separately.
- **Latency budget:** result must arrive before the tactical deadline; queueing and synchronization count. Stale results are failures, not successful fast inference.

### Success criteria

- improvement on held-out competence/believability metrics with no safety violations;
- deterministic observation masking passes hidden-state tests;
- CPU fallback produces compatible results;
- NPU end-to-end latency/energy improves over the same CPU model in sustained load;
- world-tick p99 and client performance do not regress.

### Rejection criteria

Reject the neural model if a linear/tree/utility scorer matches it, if training data do not cover failures, if model explanations are inadequate, or if quality relies on hidden state. Reject NPU deployment if batching delay, RPC, copies, runtime memory or thermal interference erase the kernel advantage.

### Simpler alternative

A tuned weighted utility or distilled decision tree. This is the preferred result when quality is equal because it is easier to debug, portable and deterministic.

# 13. Longer-term roadmap

## Phase 0 — reproducible baseline and observability

- freeze public/private build SHAs, database revisions, compiler flags and configuration;
- add world-tick and subsystem tracing;
- classify every bot by fidelity/workload class;
- capture 30-minute and multi-hour sustained device runs;
- reproduce the N100 reference only if the exact SPP/core build can be obtained publicly;
- build deterministic scenario reset and snapshot replay.

**Gate:** no architectural performance claim before tick-tail, active mix and thermal traces exist.

## Phase 1 — quick deterministic corrections

- forward `minimal` and add regression test;
- repair PerformanceMonitor aggregation/precision or replace it;
- make readiness deterministic and staggered;
- immediate event wakeups;
- cap and pace login/world insertion;
- remove obvious broad scans where a shared index already exists;
- add reaction-delay/observation masking for high-value PvP/combat events;
- fix current source/data correctness defects as they are reproduced.

**Gate:** behaviour non-inferiority with lower/equal matched-fidelity tick cost.

## Phase 2 — shared perception and scheduler

- typed tactical snapshots;
- shared map/cell human and object summaries;
- shared cast/hazard/encounter facts;
- workload-class deadlines and thermal/tick-pressure control;
- route/path cache instrumentation and reuse;
- data-oriented candidate storage for active tiers.

**Gate:** target population can be profiled honestly with class counts and no human-visible degradation.

## Phase 3 — party blackboard and coordination

- interrupt and heal reservations first;
- dispel, CC and target ownership;
- tank/taunt plan;
- typed human intent and acknowledgements;
- reason traces and replay;
- party-level resource/recovery gate.

**Gate:** statistically robust improvement in coordination scenarios with no tail regression.

## Phase 4 — positioning, navigation and reusable mechanic primitives

- shared tactical influence/hazard map;
- formation slots and assignment solver;
- pull-risk and patrol exposure model;
- LOS anchor and reposition service;
- path-failure memory and unstuck state machine;
- reusable encounter primitives: spread, stack, soak, interrupt rotation, add assignment, phase transition, line-of-sight, kite.

**Gate:** lower stuck time, unintended pulls and mechanic failures across unseen scenarios, not only scripted bosses.

## Phase 5 — high-level task planning and believability

- bounded HTN for quest/travel/maintenance;
- hierarchical utility for goals/intents;
- stable personality/risk profiles;
- repetition penalties and goal diversity;
- economy/social abstractions only when they have measurable player value.

**Gate:** improved long-session diversity without additional world-tick pressure.

## Phase 6 — optional learned scoring and NPU

- collect high-quality traces from the deterministic architecture;
- train linear/tree baseline, imitation policy and optional offline-RL teacher;
- distil to a tiny bounded scorer;
- CPU bake-off, then NPU bake-off;
- ship only with a feature flag, CPU fallback and model/version diagnostics.

**Gate:** held-out behaviour gain plus sustained end-to-end device benefit. Otherwise stop.

## Phase 7 — optional local dialogue

- fixed response bank/personality state first;
- only then consider a compact local model in a separate process;
- strict queue, token, memory, temperature and “world under load” disable policy;
- never connect output to combat, movement or commands without deterministic parsing/authorization.

**Gate:** no measurable impact on world-tick/client performance and clear user value.

## Ideas to reject or postpone

| Idea | Decision | Reason |
|---|---|---|
| End-to-end RL bot controller | Reject | Poor safety, observability, data burden and integration fit |
| Per-bot LLM cognition | Reject | Resource use is disproportionate and unrelated to correct simulation |
| Neural pathfinding | Reject until a concrete formulation wins | Existing graph/navmesh structure is better suited to deterministic algorithms |
| Planner on every combat tick | Reject | Variable search cost and frequent invalidation conflict with tick deadlines |
| Online bandit exploration in raids/PvP | Reject | Live exploration can intentionally take bad actions |
| NPU before CPU snapshot redesign | Postpone | Data preparation and world queries dominate; no clean model interface yet |
| More boss-specific scripts as primary strategy | Limit | Necessary adapters in the short term, but poor generalization |
| Raising delays globally to hit bot-count headline | Reject as sole solution | Makes visible bots slow and hides workload rather than optimizing it |
| Large global cache with locks | Reject | Risks contention and stale invalidation; use scoped immutable snapshots |

# 14. Unknowns requiring the private fork or physical device

The following cannot be established from the public study:

1. **Private fork divergence.** Whether the private build already forwards `minimal`, changes Engine scheduling, modifies caches, adds patches or differs in configuration.
2. **Android execution environment.** Native app, Termux, chroot/proot, container, custom ROM, Android version, SELinux constraints and process priority.
3. **Device model and cooling.** OEM implementation, RAM size/type, thermal policy, enclosure, fan/cooler, charging mode and ambient temperature.
4. **Build toolchain.** Compiler version, optimization/LTO/PGO flags, ARM target features, allocator, standard library and database client.
5. **Database.** MariaDB/MySQL version, storage location, filesystem, buffer settings, schema/data revisions and query latency.
6. **Core timing.** World update interval, map threading model/config, network/session settings and other modules/scripts.
7. **Actual workload mix.** How many of 500 bots are remote, travelling, human-visible, grouped, in combat, in instances or PvP.
8. **Memory footprint.** Per-bot contexts, sessions, inventory, maps, path caches, login holders and database buffers on the private build.
9. **Navigation data.** Navmesh completeness, route cache state, world data defects and known stuck locations.
10. **Sustained performance.** CPU frequencies, thermal throttling, energy, p95/p99 tick and client/server contention over hours.
11. **NPU runtime availability.** Device QNN libraries, supported runtime version, Android compatibility, operator support and exact redistribution licence.
12. **Training data.** Availability of human gameplay traces, bot reason logs, deterministic resets and permission to record/use them.
13. **LLM call sites/configuration.** The public interface was examined, but a complete runtime call-frequency map and private configuration require the actual build.
14. **N100 reproduction.** Exact SPP release, commits, configuration, active distribution and measurements were not published.
15. **Human quality target.** The acceptable tick service level, reaction-time envelope and desired balance between competence and fallibility must be chosen for this realm.

# Direct answers

## What are the five largest behavioural limitations?

1. No general party/raid intent, reservation and commitment system.
2. Shallow reactive tactical horizon without durable multi-step intent.
3. Fragmented navigation, LOS, pull-risk, formation and hazard positioning.
4. Robotic/correlated reactions and risk of using server knowledge more precisely than a human could.
5. Broad but brittle high-level behaviour, commands and bespoke encounter scripts.

## What architectural change could produce the largest improvement?

Add a **shared party blackboard with expiring reservations inside an event-driven hierarchical utility architecture**, controlled by a deterministic deadline scheduler. This single change family improves coordination, removes duplicate reasoning, creates durable intent and makes human-visible work schedulable.

## What prevents the present system from scaling efficiently?

The largest obstacles are the dropped minimal-update flag at the pinned core/module boundary; per-bot repeated trigger, Value and object/group work; string/map/runtime-cast hot paths; lack of shared perception and party state; path/LOS concentration; manager-wide scans; login/database bursts; and probabilistic/coarse scheduling that can synchronize work. Their exact ranking requires profiling.

## Is the NPU useful, and for precisely which decisions?

Possibly, but only for **batched, medium/low-frequency scoring of compact observable state**: tactical action ranking, target priority, position/danger class or high-level intent. It is not useful for pathfinding, database/world queries, legality, hard mechanics, movement execution or frequent language generation. It should ship only if complete end-to-end QNN/LiteRT/ONNX timing and thermal data beat the improved CPU system.

## Is the high-population target technically credible on Snapdragon 8 Gen 2?

Approximately 500 simultaneously present bots is a credible research target when most are remote/background bots with honest reduced fidelity and when human-visible, party and combat bots are prioritized. It is unproven on the stated device, and 500 simultaneously concentrated full-fidelity combat bots should not be assumed feasible. Sustained physical-device profiling is decisive.

## What should be prototyped first?

Prototype 1: **repair and measure the update path**—forward `minimal`, install high-resolution per-tick instrumentation, classify bot workloads, implement deterministic staggering/event wakeups and compare against the current scheduler. It establishes whether later blackboard or NPU work has a trustworthy performance foundation.

# Reference catalogue

The catalogue below contains the principal direct sources used. Source-code links are permanent and include the examined commit hash.

| ID | Source | Direct link |
|---|---|---|
| A01 | Behavior Trees in Robotics and AI: An Introduction | [Open source](https://arxiv.org/abs/1709.00084) |
| A02 | Three States and a Plan: The AI of F.E.A.R. | [Open source](https://www.gamedevs.org/uploads/three-states-plan-ai-of-fear.pdf) |
| A03 | DAgger: A Reduction of Imitation Learning and Structured Prediction to No-Regret Online Learning | [Open source](https://proceedings.mlr.press/v15/ross11a.html) |
| A04 | Policy Distillation | [Open source](https://arxiv.org/abs/1511.06295) |
| A05 | Conservative Q-Learning for Offline Reinforcement Learning | [Open source](https://proceedings.neurips.cc/paper/2020/hash/0d2b2061826a5df3221116a5085a6052-Abstract.html) |
| A06 | Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference | [Open source](https://arxiv.org/abs/1712.05877) |
| C01 | PlayerbotAI.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.cpp) |
| C02 | PlayerbotAI.h | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAI.h) |
| C03 | PlayerbotAIBase.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIBase.cpp) |
| C04 | Engine.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Engine.cpp) |
| C05 | Queue.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Queue.cpp) |
| C06 | Value.h | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/Value.h) |
| C07 | NamedObjectContext.h | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/NamedObjectContext.h) |
| C08 | AiObjectContext.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/AiObjectContext.cpp) |
| C09 | AiFactory.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/AiFactory.cpp) |
| C10 | PlayerbotAIConfig.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotAIConfig.cpp) |
| C11 | PerformanceMonitor.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PerformanceMonitor.cpp) |
| C12 | RandomPlayerbotMgr.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotMgr.cpp) |
| C13 | PlayerbotLoginMgr.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLoginMgr.cpp) |
| C14 | PlayerbotMgr.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotMgr.cpp) |
| C15 | PlayerbotFactory.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotFactory.cpp) |
| C16 | RandomPlayerbotFactory.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/RandomPlayerbotFactory.cpp) |
| C17 | TravelMgr.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/TravelMgr.cpp) |
| C18 | MovementActions.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/MovementActions.cpp) |
| C19 | GenericSpellActions.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/GenericSpellActions.cpp) |
| C20 | AttackersValue.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/AttackersValue.cpp) |
| C21 | HealthTriggers.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/HealthTriggers.cpp) |
| C22 | GenericTriggers.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/GenericTriggers.cpp) |
| C23 | CureTriggers.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/triggers/CureTriggers.cpp) |
| C24 | ChooseTargetActions.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/ChooseTargetActions.cpp) |
| C25 | CombatStrategy.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/generic/CombatStrategy.cpp) |
| C26 | CcTargetValue.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/values/CcTargetValue.cpp) |
| C27 | BattleGroundTactics.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/BattleGroundTactics.cpp) |
| C28 | DungeonActions.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/strategy/actions/DungeonActions.cpp) |
| C29 | PlayerbotLLMInterface.cpp | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/playerbot/PlayerbotLLMInterface.cpp) |
| C30 | Playerbots README at pinned commit | [Open source](https://github.com/cmangos/playerbots/blob/b4f6148799802f50535e5535d235b46bf024021c/README.md) |
| C31 | CMaNGOS Classic Map.cpp | [Open source](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Maps/Map.cpp) |
| C32 | CMaNGOS Classic Player.cpp | [Open source](https://github.com/cmangos/mangos-classic/blob/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce/src/game/Entities/Player.cpp) |
| H01 | Intel Processor N100 official specifications | [Open source](https://www.intel.com/content/www/us/en/products/sku/231803/intel-processor-n100-6m-cache-up-to-3-40-ghz/specifications.html) |
| H02 | Qualcomm Snapdragon 8 Gen 2 product brief | [Open source](https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/documents/Snapdragon-8-Gen-2-Product-Brief.pdf) |
| H03 | Android NNAPI migration guide | [Open source](https://developer.android.com/ndk/guides/neuralnetworks/migration-guide) |
| H04 | Android Neural Networks API native guide | [Open source](https://developer.android.com/ndk/guides/neuralnetworks) |
| H05 | Qualcomm AI Engine Direct SDK overview | [Open source](https://www.qualcomm.com/developer/software/qualcomm-ai-engine-direct-sdk) |
| H06 | LiteRT Qualcomm NPU / QNN CompiledModel documentation | [Open source](https://developers.google.com/edge/litert/next/qualcomm) |
| H07 | ONNX Runtime QNN Execution Provider documentation | [Open source](https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html) |
| I01 | CMaNGOS issue #4104: bot invalid coordinates / crash, Classic, 500 bots | [Open source](https://github.com/cmangos/issues/issues/4104) |
| I02 | CMaNGOS issue #4096: ConfirmQuestAction null dereference | [Open source](https://github.com/cmangos/issues/issues/4096) |
| I03 | CMaNGOS issue #4064: server crashes with PlayerBots on (WotLK) | [Open source](https://github.com/cmangos/issues/issues/4064) |
| I04 | CMaNGOS issue #4016: client crashes in battlegrounds with playerbots | [Open source](https://github.com/cmangos/issues/issues/4016) |
| I05 | CMaNGOS issue #3886: bots stuck mounted after flight path | [Open source](https://github.com/cmangos/issues/issues/3886) |
| I06 | CMaNGOS issue #2830: Classic bots and stackable items | [Open source](https://github.com/cmangos/issues/issues/2830) |
| I07 | CMaNGOS issue #2186: follow movement/pathing crash | [Open source](https://github.com/cmangos/issues/issues/2186) |
| I08 | Reddit: server performance / hardware, including N100 and SPP anecdotes | [Open source](https://www.reddit.com/r/wowservers/comments/1dk82zr/server_performance_hardware/) |
| I09 | Reddit: N100 performance less than expected; detailed BMAX and bot-load report | [Open source](https://www.reddit.com/r/MiniPCs/comments/1eftys5/n100_performance_less_than_expected/) |
| I10 | Reddit: AzerothCore vs CMaNGOS Playerbots | [Open source](https://www.reddit.com/r/wowservers/comments/1jh63c4/azerothcore_vs_cmangos_playerbots/) |
| I11 | Reddit: Try Single Player Project; repetitive-bot observation | [Open source](https://www.reddit.com/r/wowservers/comments/1kt0k8a/try_single_player_project_seriously/) |
| I12 | Reddit: Playing AzerothCore with playerbots feels like... | [Open source](https://www.reddit.com/r/wowservers/comments/1utb02m/playing_azerothcore_with_playerbots_feels_like/) |
| I13 | Reddit: SPP Classics bot server at home | [Open source](https://www.reddit.com/r/wowservers/comments/12u8g3t/wow_spp_classics_bot_server_to_run_in_your_own/) |
| I14 | AzerothCore mod-playerbots repository | [Open source](https://github.com/mod-playerbots/mod-playerbots) |
| I15 | AzerothCore mod-playerbots command wiki | [Open source](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Commands) |
| I16 | AzerothCore mod-playerbots wiki home and configuration guidance | [Open source](https://github.com/mod-playerbots/mod-playerbots/wiki) |
| I17 | AzerothCore mod-playerbots addons and sub-modules | [Open source](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Addons-and-Sub%E2%80%90Modules) |
| I18 | AzerothCore mod-playerbots installation guide | [Open source](https://github.com/mod-playerbots/mod-playerbots/wiki/Installation-Guide) |
| I19 | AzerothCore mod-playerbots raid strategy guide | [Open source](https://github.com/mod-playerbots/mod-playerbots/wiki/Playerbot-Raid-Strategy-Guide) |
| I20 | YouTube: CMaNGOS Vanilla 1.12.1 and local LLM demonstration | [Open source](https://www.youtube.com/watch?v=CIxrmZ1V6_U) |
| I21 | YouTube: CMaNGOS Vanilla Playerbots multibox / Uldaman demonstration | [Open source](https://www.youtube.com/watch?v=uEjzLv9RRD4) |
| I22 | YouTube: SPP Vanilla with 3,000 bots demonstration | [Open source](https://www.youtube.com/watch?v=zr-5cNwEs18) |
| I23 | YouTube: AzerothCore Playerbots raid-group guide | [Open source](https://www.youtube.com/watch?v=3W2dvB1pDIg) |
| I24 | YouTube: AzerothCore Playerbots questing limitations and troubleshooting | [Open source](https://www.youtube.com/watch?v=Bca-RGbQAEw) |
| I25 | YouTube: Playerbots versus NPC bots discussion | [Open source](https://www.youtube.com/watch?v=fIKG_emdyVk) |
| R01 | CMaNGOS Playerbots commit b4f6148799802f50535e5535d235b46bf024021c (30 July 2026) | [Open source](https://github.com/cmangos/playerbots/commit/b4f6148799802f50535e5535d235b46bf024021c) |
| R02 | CMaNGOS Classic commit de8f72993b9e1faa1bf92dd5505f3daec5cea3ce (18 June 2026) | [Open source](https://github.com/cmangos/mangos-classic/commit/de8f72993b9e1faa1bf92dd5505f3daec5cea3ce) |
| R03 | CMaNGOS issues content commit c5970a7babb6724bcbeeb19932b55785ab301c20 | [Open source](https://github.com/cmangos/issues/commit/c5970a7babb6724bcbeeb19932b55785ab301c20) |
| R04 | CMaNGOS issues current merge page (abbreviated 6b7ea32) | [Open source](https://github.com/cmangos/issues/commit/6b7ea32) |
