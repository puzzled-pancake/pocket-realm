CMaNGOS Playerbots Architecture Study - source package
Research date: 1 August 2026

Primary pinned public revisions:
- cmangos/playerbots: b4f6148799802f50535e5535d235b46bf024021c
- cmangos/mangos-classic: de8f72993b9e1faa1bf92dd5505f3daec5cea3ce
- cmangos/issues: current rendered merge abbreviated 6b7ea32; downloadable patch content commit c5970a7babb6724bcbeeb19932b55785ab301c20

Contents:
- Markdown report with direct source links
- Five report figures as PNG files
- sources.json machine-readable source catalogue
- SHA256SUMS.txt integrity hashes

The study uses public material only. It does not claim access to a private repository or private runtime measurements.
