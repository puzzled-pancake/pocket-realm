# Pocket Realm Pad API matrix

This matrix defines the supported implementation surface for the 1.12.1 alpha. An API being listed here does not replace actual testing in client build 5875.

## Allowed Vanilla-era API used by the prototype

| Area | API / object | Use |
|---|---|---|
| Addon lifecycle | `CreateFrame`, `RegisterEvent`, `SetScript`, global `event`, `arg1`, `this` | Event and update dispatch |
| Bindings | `Bindings.xml`, `runOnUp`, `keystate`, `GetBindingKey`, `GetBindingText` | Semantic key-down/key-up commands and labels |
| Modifiers | `IsShiftKeyDown`, `IsControlKeyDown`, `IsAltKeyDown` | Four action layers and self-cast |
| Actions | `HasAction`, `UseAction`, `GetActionTexture`, `GetActionCount`, `GetActionCooldown`, `IsUsableAction`, `IsCurrentAction`, `IsAutoRepeatAction`, `IsEquippedAction`, `ActionHasRange`, `IsActionInRange`, `GetBonusBarOffset` | Vanilla action-slot presentation and activation |
| Targeting | `TargetNearestEnemy`, `TargetNearestFriend`, `TargetUnit`, `TargetLastEnemy`, `AssistUnit`, `Unit*` queries, `GetNumRaidMembers` | Nearest and deterministic group targeting |
| Bags | `GetContainerNumSlots`, `GetContainerItemInfo`, `GetContainerItemLink`, `UseContainerItem`, `PickupContainerItem`, `CursorHasItem` | Controller inventory |
| Panels | `ToggleCharacter`, `ToggleSpellBook`, `ToggleQuestLog`, `ToggleWorldMap`, `ToggleGameMenu`, `ToggleFriendsFrame` | Quick menu |
| Chat | `ChatFrame_OpenChat`, `ChatFrameEditBox` | IME/keyboard entry handoff |
| Tooltips | `GameTooltip:SetAction`, `GameTooltip:SetBagItem` | Action and inventory descriptions |
| Frames | `IsVisible`, `IsShown`, `IsEnabled`, `GetCenter`, `GetScript`, `SetPoint`, `GetPoint`, `SetBackdrop`, `StatusBar` | Explicit UI focus and overlays |
| Time/sound | `GetTime`, `PlaySound` | Hold timing, merchant confirmation, feedback |
| Lua 5.0 style | `table.getn`, `math.mod`, globals, `pcall` | 1.12-compatible implementation style |

## Explicitly excluded modern API families

| Modern capability | Why excluded | Vanilla substitute or product boundary |
|---|---|---|
| Native gamepad state (`GetGamePadState`, gamepad CVars and button tokens) | Not in the 1.12 client | Winlator emits keyboard/mouse; addon receives bindings only |
| Secure state drivers and secure handler snippets | Later secure-state architecture is not a portable 1.12 baseline | Binding scripts call ordinary 1.12 functions from hardware events; context is tracked in Lua |
| `SetOverrideBinding*` and modern binding ownership | Not used as a compatibility assumption | User-visible `Bindings.xml` commands; no hidden key takeover |
| Modern action APIs (`GetActionInfo` variants, action mixins, `C_ActionBar`) | Not available | Fixed Vanilla action slots 1-48 and bonus-slot formula |
| Soft targeting and interact CVars | Not available | `TargetNearest*`, group unit IDs, Winlator mouse/right-click |
| Nameplate enumeration and modern unit tooltip mounting | Not available | A compact target card sourced from the current `target` unit |
| `C_` namespaces, `Enum`, mixins, callback registries | Not available | Plain global functions and tables |
| `hooksecurefunc`, `InCombatLockdown`, modern protected-frame model | Not a 1.12 design dependency | Explicit adapters and ordinary FrameXML click scripts |
| Timers such as `C_Timer` | Not available | Bounded `OnUpdate` elapsed accumulators and `GetTime` |
| Modern bag API (`C_Container`) | Not available | `GetContainer*`, `UseContainerItem`, `PickupContainerItem` |
| Modern cursor/navigation framework | Not available | Explicit frame-name adapters and geometric directional selection |
| Addon-to-Android IPC | WoW addon sandbox has no Android bridge | Android installs/generates files only while client is stopped; runtime input is keyboard/mouse |

## Frame adapter contract

Each adapter may declare only:

- A stable panel identity and user-facing title.
- A bounded list/range of known global FrameXML control names.
- Optional scroll-bar names.
- Optional accept/alternate callbacks.
- A deterministic back/close operation.

The focus engine must never iterate `_G`, inspect arbitrary addon frames, execute text from frame labels, or call a function named by untrusted data.

## Security and failure rules

1. No arbitrary macro text, slash text, file path, or function name enters an action from external input.
2. No physical-controller information is accepted by the addon; translated keys are ordinary WoW bindings.
3. A UI-context key-down is captured and consumed on key-up even if the panel changes during the press.
4. A world action key-down captures the exact action slot and self-cast state used on key-up.
5. `ReleaseAll` clears all pending captures without activating them.
6. Safe mode hides/disables semantic overlays without editing action slots, bags, or Blizzard settings.
7. Unknown or missing frames are skipped, not guessed.
8. The Android launcher owns installation/update hashes; addon code never downloads or executes content.
