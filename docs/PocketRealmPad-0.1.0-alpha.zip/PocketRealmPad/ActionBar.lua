-- Compact four-layer action bar for Vanilla action slots.
-- Layer 1: slots 1-12, or the active bonus/stance bar.
-- Layer 2: Shift + slots 13-24.
-- Layer 3: Control + slots 25-36.
-- Layer 4: Shift+Control + slots 37-48.
-- Alt is reserved as a self-cast modifier.

PRP_ActionBar = {
    initialized = false,
    buttons = {},
    held = {},
    currentLayer = 1,
    updateElapsed = 0,
}

function PRP_ActionBar:GetLayer()
    local shift = IsShiftKeyDown and IsShiftKeyDown()
    local control = IsControlKeyDown and IsControlKeyDown()
    if shift and control then
        return 4
    elseif control then
        return 3
    elseif shift then
        return 2
    end
    return 1
end

function PRP_ActionBar:GetLayerName(layer)
    if layer == 2 then
        return "SHIFT"
    elseif layer == 3 then
        return "CTRL"
    elseif layer == 4 then
        return "SHIFT + CTRL"
    end
    if BonusActionBarFrame and BonusActionBarFrame:IsShown() then
        return "BONUS / STANCE"
    end
    return "BASE"
end

function PRP_ActionBar:GetBonusSlot(index)
    local offset = 0
    if GetBonusBarOffset then
        offset = GetBonusBarOffset() or 0
    end
    if offset == 0 and BonusActionBarFrame and BonusActionBarFrame.lastBonusBar then
        offset = BonusActionBarFrame.lastBonusBar
    end
    return index + ((6 + offset - 1) * 12)
end

function PRP_ActionBar:GetSlot(index, layer)
    if layer == 1 then
        if BonusActionBarFrame and BonusActionBarFrame:IsShown() then
            return self:GetBonusSlot(index)
        end
        return index
    end
    return index + ((layer - 1) * 12)
end

function PRP_ActionBar:CreateButton(index)
    local button = CreateFrame("CheckButton", "PocketRealmPadAction" .. index, self.frame)
    local icon
    local cooldown
    local count
    local hotkey
    local slotText
    local border
    local normal

    button.prpIndex = index
    button:SetWidth(PocketRealmPadDB.bar.buttonSize)
    button:SetHeight(PocketRealmPadDB.bar.buttonSize)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    button:SetCheckedTexture("Interface\\Buttons\\CheckButtonHilight", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    button.icon = icon

    normal = button:GetNormalTexture()
    if normal then
        normal:SetWidth(PocketRealmPadDB.bar.buttonSize * 1.72)
        normal:SetHeight(PocketRealmPadDB.bar.buttonSize * 1.72)
        normal:ClearAllPoints()
        normal:SetPoint("CENTER", button, "CENTER", 0, -1)
    end

    cooldown = CreateFrame("Model", "PocketRealmPadAction" .. index .. "Cooldown", button, "CooldownFrameTemplate")
    cooldown:SetAllPoints(button)
    cooldown:SetFrameLevel(button:GetFrameLevel() + 1)
    button.cooldown = cooldown

    count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    count:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 2)
    button.count = count

    hotkey = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
    hotkey:SetPoint("TOPRIGHT", button, "TOPRIGHT", -2, -2)
    hotkey:SetJustifyH("RIGHT")
    button.hotkey = hotkey

    slotText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    slotText:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 2, 2)
    slotText:SetJustifyH("LEFT")
    button.slotText = slotText

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetWidth(PocketRealmPadDB.bar.buttonSize * 1.70)
    border:SetHeight(PocketRealmPadDB.bar.buttonSize * 1.70)
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    border:Hide()
    button.border = border

    button:SetScript("OnEnter", PRP_ActionButton_OnEnter)
    button:SetScript("OnLeave", PRP_ActionButton_OnLeave)
    button:SetScript("OnClick", PRP_ActionButton_OnClick)

    self.buttons[index] = button
    return button
end

function PRP_ActionBar:Layout()
    local columns = PocketRealmPadDB.bar.columns or 6
    local spacing = PocketRealmPadDB.bar.spacing or 3
    local size = PocketRealmPadDB.bar.buttonSize or 40
    local rows = math.floor((12 + columns - 1) / columns)
    local width = (columns * size) + ((columns - 1) * spacing) + 20
    local height = (rows * size) + ((rows - 1) * spacing) + 42
    local index
    local column
    local row
    local button

    self.frame:SetWidth(width)
    self.frame:SetHeight(height)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.frame:SetAlpha(PocketRealmPadDB.bar.alpha or 1)
    PRP_SetFramePosition(self.frame, PocketRealmPadDB.bar)

    for index = 1, 12 do
        button = self.buttons[index]
        column = math.mod(index - 1, columns)
        row = math.floor((index - 1) / columns)
        button:ClearAllPoints()
        button:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 10 + (column * (size + spacing)), -29 - (row * (size + spacing)))
    end
end

function PRP_ActionBar:Initialize()
    local index
    if self.initialized then
        return
    end

    self.frame = PRP_UI:CreatePanel("PocketRealmPadActionBar", 280, 120, "HIGH")
    self.frame:SetMovable(true)
    self.frame:EnableMouse(true)
    self.frame:RegisterForDrag("LeftButton")
    self.frame:SetScript("OnDragStart", PRP_ActionBar_OnDragStart)
    self.frame:SetScript("OnDragStop", PRP_ActionBar_OnDragStop)

    self.layerText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalSmall", "BASE")
    self.layerText:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 12, -10)

    self.selfText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "ALT = SELF CAST")
    self.selfText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -12, -10)

    for index = 1, 12 do
        self:CreateButton(index)
    end

    self:Layout()
    self.currentLayer = self:GetLayer()
    self:UpdateAll(true)

    if PocketRealmPadDB.bar.shown == 1 and PocketRealmPadDB.safeMode ~= 1 then
        self.frame:Show()
    else
        self.frame:Hide()
    end
    self.initialized = true
end

function PRP_ActionBar:UpdateButton(index)
    local button = self.buttons[index]
    local layer = self.currentLayer
    local slot = self:GetSlot(index, layer)
    local texture
    local count
    local start
    local duration
    local enable
    local usable
    local notEnoughMana
    local range
    local keyText
    local label

    if not button then
        return
    end

    button.prpSlot = slot
    texture = GetActionTexture and GetActionTexture(slot) or nil
    if texture then
        button.icon:SetTexture(texture)
        button.icon:Show()
        button:SetAlpha(1)
    else
        button.icon:SetTexture(nil)
        button.icon:Hide()
        button:SetAlpha(0.58)
    end

    count = 0
    if IsConsumableAction and IsConsumableAction(slot) and GetActionCount then
        count = GetActionCount(slot) or 0
    end
    if count and count > 1 then
        button.count:SetText(count)
    else
        button.count:SetText("")
    end

    if GetActionCooldown then
        start, duration, enable = GetActionCooldown(slot)
        if start and duration then
            CooldownFrame_SetTimer(button.cooldown, start, duration, enable)
        else
            button.cooldown:Hide()
        end
    end

    usable = true
    notEnoughMana = false
    if IsUsableAction then
        usable, notEnoughMana = IsUsableAction(slot)
    end
    if usable then
        button.icon:SetVertexColor(1, 1, 1)
    elseif notEnoughMana then
        button.icon:SetVertexColor(0.45, 0.45, 1)
    else
        button.icon:SetVertexColor(0.38, 0.38, 0.38)
    end

    if IsCurrentAction and (IsCurrentAction(slot) or (IsAutoRepeatAction and IsAutoRepeatAction(slot))) then
        button:SetChecked(1)
    elseif not self.held[index] then
        button:SetChecked(0)
    end

    if IsEquippedAction and IsEquippedAction(slot) then
        button.border:SetVertexColor(0, 1, 0, 0.55)
        button.border:Show()
    else
        button.border:Hide()
    end

    keyText = PRP_GetBindingLabel("PRP_ACTION" .. index)
    if keyText == "" then
        label = PocketRealmPadDB.buttonLabels[index]
        keyText = label or tostring(index)
    end
    button.hotkey:SetText(keyText)
    button.hotkey:SetTextColor(0.70, 0.70, 0.70)

    if texture and ActionHasRange and ActionHasRange(slot) and IsActionInRange then
        range = IsActionInRange(slot)
        if range == 0 or range == false then
            button.hotkey:SetTextColor(1, 0.15, 0.15)
        end
    end

    button.slotText:SetText(tostring(slot))
end

function PRP_ActionBar:UpdateAll(force)
    local layer
    local index
    if not self.initialized and not force then
        return
    end
    layer = self:GetLayer()
    self.currentLayer = layer
    if self.layerText then
        self.layerText:SetText(self:GetLayerName(layer) .. "  |cff888888PAGE " .. layer .. "|r")
    end
    for index = 1, 12 do
        self:UpdateButton(index)
    end
end

function PRP_ActionBar:OnKey(index, state)
    local held
    local slot
    local selfCast
    local button
    if not self.initialized or not PRP:IsEnabled() then
        return
    end
    button = self.buttons[index]
    if state == "down" then
        slot = self:GetSlot(index, self:GetLayer())
        selfCast = IsAltKeyDown and IsAltKeyDown() and 1 or nil
        self.held[index] = { slot = slot, selfCast = selfCast }
        if button then
            button:SetButtonState("PUSHED")
            button:SetChecked(1)
        end
        return
    end

    held = self.held[index]
    if held then
        slot = held.slot
        selfCast = held.selfCast
    else
        slot = self:GetSlot(index, self:GetLayer())
        selfCast = IsAltKeyDown and IsAltKeyDown() and 1 or nil
    end
    self.held[index] = nil
    if button then
        button:SetButtonState("NORMAL")
    end
    if HasAction and HasAction(slot) and UseAction then
        UseAction(slot, 0, selfCast)
    end
    self:UpdateButton(index)
end

function PRP_ActionBar:ReleaseAll()
    local index
    local button
    for index = 1, 12 do
        self.held[index] = nil
        button = self.buttons[index]
        if button then
            button:SetButtonState("NORMAL")
            button:SetChecked(0)
        end
    end
    self:UpdateAll(true)
end

function PRP_ActionBar:OnEvent(eventName, firstArg)
    if eventName == "ACTIONBAR_SLOT_CHANGED" then
        self:UpdateAll(true)
    else
        self:UpdateAll(true)
    end
end

function PRP_ActionBar:OnUpdate(elapsed)
    local layer
    self.updateElapsed = self.updateElapsed + elapsed
    if self.updateElapsed < 0.08 then
        return
    end
    self.updateElapsed = 0
    layer = self:GetLayer()
    if layer ~= self.currentLayer then
        self.currentLayer = layer
        self:UpdateAll(true)
    else
        self:UpdateAll(false)
    end
end

function PRP_ActionButton_OnEnter()
    local button = this
    local slot = button and button.prpSlot
    if not button or not slot or not GameTooltip or not GameTooltip.SetAction then
        return
    end
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    GameTooltip:SetAction(slot)
    GameTooltip:Show()
end

function PRP_ActionButton_OnLeave()
    if GameTooltip then
        GameTooltip:Hide()
    end
end

function PRP_ActionButton_OnClick()
    local button = this
    local slot = button and button.prpSlot
    local selfCast
    if not slot or not HasAction or not HasAction(slot) then
        return
    end
    selfCast = nil
    if arg1 == "RightButton" then
        selfCast = 1
    end
    UseAction(slot, 0, selfCast)
    PRP_ActionBar:UpdateButton(button.prpIndex)
end

function PRP_ActionBar_OnDragStart()
    if PocketRealmPadDB.bar.locked == 1 then
        return
    end
    this:StartMoving()
end

function PRP_ActionBar_OnDragStop()
    this:StopMovingOrSizing()
    PRP_SaveFramePosition(this, PocketRealmPadDB.bar)
end
