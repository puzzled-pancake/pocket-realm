-- Explicit adapters for known Blizzard 1.12 UI panels.
-- Frames are named individually or through bounded, known template ranges.

PRP_Adapters = {}

function PRP_Adapters:Add(nodes, frameName, fallbackLabel, accept, alternate)
    local frame = PRP_GetFrame(frameName)
    local count
    if not frame or not PRP_IsVisible(frame) or not PRP_IsEnabled(frame) then
        return
    end
    count = PRP_TableLength(nodes) + 1
    nodes[count] = {
        frame = frame,
        label = PRP_GetFrameLabel(frame, fallbackLabel or frameName),
        accept = accept,
        alternate = alternate,
    }
end

function PRP_Adapters:AddRange(nodes, prefix, suffix, first, last, labelPrefix)
    local index
    local name
    for index = first, last do
        name = prefix .. index .. (suffix or "")
        self:Add(nodes, name, (labelPrefix or "Item") .. " " .. index)
    end
end

function PRP_Adapters:BackByName(frameName, mouseButton)
    local frame = PRP_GetFrame(frameName)
    if frame and PRP_IsVisible(frame) then
        return PRP_InvokeFrame(frame, mouseButton or "LeftButton")
    end
    return false
end

function PRP_Adapters:GetPopupAdapter()
    local index
    local frame
    for index = 1, 4 do
        frame = PRP_GetFrame("StaticPopup" .. index)
        if PRP_IsVisible(frame) then
            return {
                id = "static-popup-" .. index,
                title = "Confirmation",
                popupIndex = index,
                Collect = function(adapter, nodes)
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "Button1", "Confirm")
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "Button2", "Cancel")
                    PRP_Adapters:Add(nodes, "StaticPopup" .. adapter.popupIndex .. "CloseButton", "Close")
                end,
                Back = function(adapter)
                    if PRP_Adapters:BackByName("StaticPopup" .. adapter.popupIndex .. "Button2") then
                        return true
                    end
                    return PRP_Adapters:BackByName("StaticPopup" .. adapter.popupIndex .. "CloseButton")
                end,
            }
        end
    end
    return nil
end

PRP_Adapters.quest = {
    id = "quest",
    title = "Quest",
    scrollBars = {
        "QuestGreetingScrollFrameScrollBar",
        "QuestDetailScrollFrameScrollBar",
        "QuestProgressScrollFrameScrollBar",
        "QuestRewardScrollFrameScrollBar",
    },
}

function PRP_Adapters.quest:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "QuestTitleButton", "", 1, 10, "Quest")
    PRP_Adapters:AddRange(nodes, "QuestRewardItem", "", 1, 10, "Reward")
    PRP_Adapters:Add(nodes, "QuestFrameAcceptButton", "Accept quest")
    PRP_Adapters:Add(nodes, "QuestFrameDeclineButton", "Decline quest")
    PRP_Adapters:Add(nodes, "QuestFrameCompleteButton", "Continue")
    PRP_Adapters:Add(nodes, "QuestFrameCompleteQuestButton", "Complete quest")
    PRP_Adapters:Add(nodes, "QuestFrameGoodbyeButton", "Goodbye")
    PRP_Adapters:Add(nodes, "QuestFrameCancelButton", "Cancel")
    PRP_Adapters:Add(nodes, "QuestFrameCloseButton", "Close")
end

function PRP_Adapters.quest:Back()
    if PRP_Adapters:BackByName("QuestFrameGoodbyeButton") then
        return true
    end
    if PRP_Adapters:BackByName("QuestFrameCancelButton") then
        return true
    end
    if PRP_Adapters:BackByName("QuestFrameDeclineButton") then
        return true
    end
    return PRP_Adapters:BackByName("QuestFrameCloseButton")
end

PRP_Adapters.gossip = {
    id = "gossip",
    title = "Gossip",
    scrollBars = { "GossipGreetingScrollFrameScrollBar" },
}

function PRP_Adapters.gossip:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "GossipTitleButton", "", 1, 32, "Gossip option")
    PRP_Adapters:Add(nodes, "GossipFrameCloseButton", "Close")
end

function PRP_Adapters.gossip:Back()
    return PRP_Adapters:BackByName("GossipFrameCloseButton")
end

PRP_Adapters.loot = {
    id = "loot",
    title = "Loot",
}

function PRP_Adapters.loot:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "LootButton", "", 1, 4, "Loot")
    PRP_Adapters:Add(nodes, "LootFrameUpButton", "Previous loot page")
    PRP_Adapters:Add(nodes, "LootFrameDownButton", "Next loot page")
    PRP_Adapters:Add(nodes, "LootCloseButton", "Close loot")
end

function PRP_Adapters.loot:Back()
    return PRP_Adapters:BackByName("LootCloseButton")
end

PRP_Adapters.merchant = {
    id = "merchant",
    title = "Merchant",
}

function PRP_Adapters.merchant:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "MerchantItem", "ItemButton", 1, 12, "Merchant item")
    PRP_Adapters:Add(nodes, "MerchantBuyBackItemItemButton", "Buy back item")
    PRP_Adapters:Add(nodes, "MerchantPrevPageButton", "Previous merchant page")
    PRP_Adapters:Add(nodes, "MerchantNextPageButton", "Next merchant page")
    PRP_Adapters:Add(nodes, "MerchantRepairItemButton", "Repair one item")
    PRP_Adapters:Add(nodes, "MerchantRepairAllButton", "Repair all items")
    PRP_Adapters:Add(nodes, "MerchantFrameCloseButton", "Close merchant")
end

function PRP_Adapters.merchant:Back()
    return PRP_Adapters:BackByName("MerchantFrameCloseButton")
end

PRP_Adapters.gameMenu = {
    id = "game-menu",
    title = "Game menu",
}

function PRP_Adapters.gameMenu:Collect(nodes)
    PRP_Adapters:Add(nodes, "GameMenuButtonOptions", "Video options")
    PRP_Adapters:Add(nodes, "GameMenuButtonSoundOptions", "Sound options")
    PRP_Adapters:Add(nodes, "GameMenuButtonUIOptions", "Interface options")
    PRP_Adapters:Add(nodes, "GameMenuButtonKeybindings", "Key bindings")
    PRP_Adapters:Add(nodes, "GameMenuButtonMacros", "Macros")
    PRP_Adapters:Add(nodes, "GameMenuButtonLogout", "Log out")
    PRP_Adapters:Add(nodes, "GameMenuButtonQuit", "Exit game")
    PRP_Adapters:Add(nodes, "GameMenuButtonContinue", "Return to game")
end

function PRP_Adapters.gameMenu:Back()
    return PRP_Adapters:BackByName("GameMenuButtonContinue")
end

PRP_Adapters.spellBook = {
    id = "spellbook",
    title = "Spellbook",
}

function PRP_Adapters.spellBook:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "SpellButton", "", 1, 12, "Spell")
    PRP_Adapters:AddRange(nodes, "SpellBookSkillLineTab", "", 1, 8, "Spell tab")
    PRP_Adapters:Add(nodes, "SpellBookPrevPageButton", "Previous spell page")
    PRP_Adapters:Add(nodes, "SpellBookNextPageButton", "Next spell page")
    PRP_Adapters:Add(nodes, "SpellBookCloseButton", "Close spellbook")
end

function PRP_Adapters.spellBook:Back()
    return PRP_Adapters:BackByName("SpellBookCloseButton")
end

PRP_Adapters.character = {
    id = "character",
    title = "Character",
}

function PRP_Adapters.character:Collect(nodes)
    local slots = {
        "CharacterHeadSlot", "CharacterNeckSlot", "CharacterShoulderSlot", "CharacterBackSlot",
        "CharacterChestSlot", "CharacterShirtSlot", "CharacterTabardSlot", "CharacterWristSlot",
        "CharacterHandsSlot", "CharacterWaistSlot", "CharacterLegsSlot", "CharacterFeetSlot",
        "CharacterFinger0Slot", "CharacterFinger1Slot", "CharacterTrinket0Slot", "CharacterTrinket1Slot",
        "CharacterMainHandSlot", "CharacterSecondaryHandSlot", "CharacterRangedSlot", "CharacterAmmoSlot",
    }
    local index
    for index = 1, PRP_TableLength(slots) do
        PRP_Adapters:Add(nodes, slots[index], slots[index])
    end
    PRP_Adapters:AddRange(nodes, "CharacterFrameTab", "", 1, 5, "Character tab")
    PRP_Adapters:Add(nodes, "CharacterFrameCloseButton", "Close character")
end

function PRP_Adapters.character:Back()
    return PRP_Adapters:BackByName("CharacterFrameCloseButton")
end

PRP_Adapters.questLog = {
    id = "quest-log",
    title = "Quest log",
    scrollBars = { "QuestLogListScrollFrameScrollBar", "QuestLogDetailScrollFrameScrollBar" },
}

function PRP_Adapters.questLog:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "QuestLogTitle", "", 1, 20, "Quest")
    PRP_Adapters:Add(nodes, "QuestLogFrameTrackButton", "Track quest")
    PRP_Adapters:Add(nodes, "QuestLogFrameAbandonButton", "Abandon quest")
    PRP_Adapters:Add(nodes, "QuestLogFramePushQuestButton", "Share quest")
    PRP_Adapters:Add(nodes, "QuestLogFrameCancelButton", "Close quest log")
    PRP_Adapters:Add(nodes, "QuestLogFrameCloseButton", "Close quest log")
end

function PRP_Adapters.questLog:Back()
    if PRP_Adapters:BackByName("QuestLogFrameCancelButton") then
        return true
    end
    return PRP_Adapters:BackByName("QuestLogFrameCloseButton")
end

PRP_Adapters.friends = {
    id = "social",
    title = "Social",
    scrollBars = { "FriendsListScrollFrameScrollBar", "WhoListScrollFrameScrollBar", "GuildListScrollFrameScrollBar" },
}

function PRP_Adapters.friends:Collect(nodes)
    PRP_Adapters:AddRange(nodes, "FriendsFrameTab", "", 1, 4, "Social tab")
    PRP_Adapters:AddRange(nodes, "FriendsFrameFriendButton", "", 1, 12, "Friend")
    PRP_Adapters:AddRange(nodes, "WhoFrameButton", "", 1, 17, "Who result")
    PRP_Adapters:Add(nodes, "FriendsFrameAddFriendButton", "Add friend")
    PRP_Adapters:Add(nodes, "FriendsFrameSendMessageButton", "Send message")
    PRP_Adapters:Add(nodes, "FriendsFrameCloseButton", "Close social")
end

function PRP_Adapters.friends:Back()
    return PRP_Adapters:BackByName("FriendsFrameCloseButton")
end

PRP_Adapters.worldMap = {
    id = "world-map",
    title = "World map",
}

function PRP_Adapters.worldMap:Collect(nodes)
    PRP_Adapters:Add(nodes, "WorldMapZoomOutButton", "Zoom out")
    PRP_Adapters:Add(nodes, "WorldMapFrameCloseButton", "Close map")
end

function PRP_Adapters.worldMap:Back()
    if PRP_Adapters:BackByName("WorldMapFrameCloseButton") then
        return true
    end
    if ToggleWorldMap then
        ToggleWorldMap()
        return true
    end
    return false
end

function PRP_Adapters:GetActive()
    local popup = self:GetPopupAdapter()
    if popup then
        return popup
    end
    if PRP_IsVisible(PRP_GetFrame("QuestFrame")) then
        return self.quest
    end
    if PRP_IsVisible(PRP_GetFrame("GossipFrame")) then
        return self.gossip
    end
    if PRP_IsVisible(PRP_GetFrame("LootFrame")) then
        return self.loot
    end
    if PRP_IsVisible(PRP_GetFrame("MerchantFrame")) then
        return self.merchant
    end
    if PRP_IsVisible(PRP_GetFrame("GameMenuFrame")) then
        return self.gameMenu
    end
    if PRP_IsVisible(PRP_GetFrame("SpellBookFrame")) then
        return self.spellBook
    end
    if PRP_IsVisible(PRP_GetFrame("CharacterFrame")) then
        return self.character
    end
    if PRP_IsVisible(PRP_GetFrame("QuestLogFrame")) then
        return self.questLog
    end
    if PRP_IsVisible(PRP_GetFrame("FriendsFrame")) then
        return self.friends
    end
    if PRP_IsVisible(PRP_GetFrame("WorldMapFrame")) then
        return self.worldMap
    end
    return nil
end
