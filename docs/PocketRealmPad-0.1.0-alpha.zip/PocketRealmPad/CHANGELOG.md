# Changelog

## 0.1.0-alpha - 2026-08-03

- Added Interface 11200 addon manifest and semantic bindings.
- Added 12-button, four-layer Vanilla action presentation over slots 1-48.
- Added bonus/stance base-slot translation and Alt self-cast capture.
- Added strict context router with UI key-up suppression.
- Added target card, nearest enemy/friend commands, and deterministic group-unit cycling.
- Added explicit directional focus adapters for common 1.12 panels.
- Added paged controller inventory with double-confirm merchant selling.
- Added eight-entry digital radial quick menu.
- Added normal chat edit-box handoff, safe mode, status UI, toasts, and slash recovery commands.
- Added static API/syntax checks and 53 host mock-runtime assertions.
