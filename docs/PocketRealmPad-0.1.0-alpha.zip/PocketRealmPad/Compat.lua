-- Compatibility helpers restricted to the WoW 1.12-era Lua and frame API.

function PRP_TableLength(value)
    if type(value) ~= "table" then
        return 0
    end
    return table.getn(value)
end

function PRP_Clamp(value, minimum, maximum)
    if value < minimum then
        return minimum
    end
    if value > maximum then
        return maximum
    end
    return value
end

function PRP_Round(value)
    return math.floor(value + 0.5)
end

function PRP_CopyTable(source)
    local result = {}
    local key, value
    if type(source) ~= "table" then
        return result
    end
    for key, value in pairs(source) do
        if type(value) == "table" then
            result[key] = PRP_CopyTable(value)
        else
            result[key] = value
        end
    end
    return result
end

function PRP_MergeDefaults(destination, defaults)
    local key, value
    if type(destination) ~= "table" then
        destination = {}
    end
    if type(defaults) ~= "table" then
        return destination
    end
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            destination[key] = PRP_MergeDefaults(destination[key], value)
        elseif destination[key] == nil then
            destination[key] = value
        end
    end
    return destination
end

function PRP_GetFrame(name)
    if not name then
        return nil
    end
    return getglobal(name)
end

function PRP_IsVisible(frame)
    if not frame then
        return false
    end
    if frame.IsVisible then
        return frame:IsVisible() and true or false
    end
    if frame.IsShown then
        return frame:IsShown() and true or false
    end
    return false
end

function PRP_IsEnabled(frame)
    local enabled
    if not frame then
        return false
    end
    if not frame.IsEnabled then
        return true
    end
    enabled = frame:IsEnabled()
    if enabled == nil or enabled == false or enabled == 0 then
        return false
    end
    return true
end

function PRP_GetFrameLabel(frame, fallback)
    local text
    local name
    local label
    if not frame then
        return fallback or ""
    end
    if frame.GetText then
        text = frame:GetText()
        if text and text ~= "" then
            return text
        end
    end
    name = frame.GetName and frame:GetName() or nil
    if name then
        label = getglobal(name .. "Text")
        if label and label.GetText then
            text = label:GetText()
            if text and text ~= "" then
                return text
            end
        end
        label = getglobal(name .. "Name")
        if label and label.GetText then
            text = label:GetText()
            if text and text ~= "" then
                return text
            end
        end
    end
    return fallback or name or "Control"
end

function PRP_InvokeFrame(frame, mouseButton)
    local script
    local oldThis
    local oldArg1
    local ok
    local err
    if not PRP_IsVisible(frame) or not PRP_IsEnabled(frame) then
        return false, "not-visible-or-enabled"
    end
    if not frame.GetScript then
        return false, "no-script-api"
    end
    script = frame:GetScript("OnClick")
    if not script then
        return false, "no-onclick"
    end
    oldThis = this
    oldArg1 = arg1
    this = frame
    arg1 = mouseButton or "LeftButton"
    ok, err = pcall(script)
    this = oldThis
    arg1 = oldArg1
    if not ok then
        if PRP and PRP.Debug then
            PRP:Debug("OnClick failed: " .. tostring(err))
        end
        return false, err
    end
    return true
end

function PRP_GetBindingLabel(bindingName)
    local key1
    local key2
    local text
    if not bindingName or not GetBindingKey then
        return ""
    end
    key1, key2 = GetBindingKey(bindingName)
    if key1 then
        if GetBindingText then
            text = GetBindingText(key1, "KEY_", 1)
            if text and text ~= "" then
                return text
            end
        end
        return key1
    end
    if key2 then
        return key2
    end
    return ""
end

function PRP_UnitExists(unit)
    if not unit then
        return false
    end
    if UnitExists then
        return UnitExists(unit) and true or false
    end
    return UnitName(unit) ~= nil
end

function PRP_FrameCenter(frame)
    local x
    local y
    if not frame or not frame.GetCenter then
        return nil, nil
    end
    x, y = frame:GetCenter()
    if not x or not y then
        return nil, nil
    end
    return x, y
end

function PRP_SetFramePosition(frame, settings)
    local point
    local relativePoint
    local x
    local y
    if not frame or type(settings) ~= "table" then
        return
    end
    point = settings.point or "CENTER"
    relativePoint = settings.relativePoint or point
    x = settings.x or 0
    y = settings.y or 0
    frame:ClearAllPoints()
    frame:SetPoint(point, UIParent, relativePoint, x, y)
end

function PRP_SaveFramePosition(frame, settings)
    local point
    local relativeTo
    local relativePoint
    local x
    local y
    if not frame or type(settings) ~= "table" or not frame.GetPoint then
        return
    end
    point, relativeTo, relativePoint, x, y = frame:GetPoint(1)
    if point then
        settings.point = point
        settings.relativePoint = relativePoint or point
        settings.x = x or 0
        settings.y = y or 0
    end
end

function PRP_ScrollBarStep(scrollBar, delta)
    local minimum
    local maximum
    local value
    if not scrollBar or not scrollBar.GetMinMaxValues or not scrollBar.GetValue then
        return false
    end
    minimum, maximum = scrollBar:GetMinMaxValues()
    value = scrollBar:GetValue()
    if not minimum or not maximum or not value then
        return false
    end
    value = PRP_Clamp(value + delta, minimum, maximum)
    scrollBar:SetValue(value)
    return true
end

function PRP_ChatEditActive()
    if ChatFrameEditBox and PRP_IsVisible(ChatFrameEditBox) then
        return true
    end
    return false
end

function PRP_ColorFromQuality(quality)
    local color
    if quality and ITEM_QUALITY_COLORS then
        color = ITEM_QUALITY_COLORS[quality]
        if color then
            return color.r or 1, color.g or 1, color.b or 1
        end
    end
    return 0.45, 0.45, 0.45
end
