-- Pocket Realm Pad core lifecycle.

PRP = PRP or {}
PRP.name = "PocketRealmPad"
PRP.version = "0.1.0-alpha"
PRP.initialized = false
PRP.elapsed = 0
PRP.mode = "LOADING"

function PRP:Print(message)
    local text = "|cff79b7ffPocket Realm Pad:|r " .. tostring(message)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage(text)
    end
end

function PRP:Debug(message)
    if not PocketRealmPadDB or PocketRealmPadDB.debug ~= 1 then
        return
    end
    self:Print("DEBUG " .. tostring(message))
end

function PRP:SetMode(mode)
    if self.mode == mode then
        return
    end
    self.mode = mode
    if PRP_UI and PRP_UI.SetMode then
        PRP_UI:SetMode(mode)
    end
end

function PRP:IsEnabled()
    if not PocketRealmPadDB then
        return false
    end
    return PocketRealmPadDB.enabled == 1
end

function PRP:IsSafeMode()
    if not PocketRealmPadDB then
        return true
    end
    return PocketRealmPadDB.safeMode == 1
end

function PRP:InitializeSavedVariables()
    if type(PocketRealmPadDB) ~= "table" then
        PocketRealmPadDB = {}
    end
    PocketRealmPadDB = PRP_MergeDefaults(PocketRealmPadDB, PRP_DEFAULTS)
end

function PRP:Initialize()
    if self.initialized then
        return
    end
    self:InitializeSavedVariables()

    if PRP_UI and PRP_UI.Initialize then
        PRP_UI:Initialize()
    end
    if PRP_ActionBar and PRP_ActionBar.Initialize then
        PRP_ActionBar:Initialize()
    end
    if PRP_Targeting and PRP_Targeting.Initialize then
        PRP_Targeting:Initialize()
    end
    if PRP_Inventory and PRP_Inventory.Initialize then
        PRP_Inventory:Initialize()
    end
    if PRP_QuickMenu and PRP_QuickMenu.Initialize then
        PRP_QuickMenu:Initialize()
    end
    if PRP_Focus and PRP_Focus.Initialize then
        PRP_Focus:Initialize()
    end
    if PRP_Router and PRP_Router.Initialize then
        PRP_Router:Initialize()
    end
    if PRP_Slash and PRP_Slash.Initialize then
        PRP_Slash:Initialize()
    end

    self.initialized = true
    if self:IsEnabled() then
        self:SetMode("WORLD")
    else
        self:SetMode("DISABLED")
    end
    self:Print("loaded; profile " .. tostring(PocketRealmPadDB.mappingProfile) .. ". Type /prp status.")
end

function PRP:ReleaseAllInputs()
    if PRP_Router and PRP_Router.ReleaseAll then
        PRP_Router:ReleaseAll()
    elseif PRP_ActionBar and PRP_ActionBar.ReleaseAll then
        PRP_ActionBar:ReleaseAll()
    end
end

function PRP:RefreshAll()
    if PRP_ActionBar and PRP_ActionBar.UpdateAll then
        PRP_ActionBar:UpdateAll(true)
    end
    if PRP_Targeting and PRP_Targeting.Update then
        PRP_Targeting:Update(true)
    end
    if PRP_Inventory and PRP_Inventory.IsShown and PRP_Inventory:IsShown() then
        PRP_Inventory:Rebuild(true)
    end
    if PRP_Focus and PRP_Focus.Detect then
        PRP_Focus:Detect(true)
    end
end

function PRP:OnEvent(eventName, firstArg)
    if eventName == "ADDON_LOADED" then
        if firstArg == self.name then
            self:Initialize()
        end
        return
    end

    if not self.initialized then
        return
    end

    if eventName == "PLAYER_ENTERING_WORLD" then
        self:ReleaseAllInputs()
        self:RefreshAll()
    elseif eventName == "PLAYER_LEAVING_WORLD" then
        self:ReleaseAllInputs()
    elseif eventName == "UPDATE_BINDINGS" then
        if PRP_ActionBar then
            PRP_ActionBar:UpdateAll(true)
        end
    elseif eventName == "ACTIONBAR_SLOT_CHANGED"
        or eventName == "ACTIONBAR_UPDATE_USABLE"
        or eventName == "ACTIONBAR_UPDATE_COOLDOWN"
        or eventName == "ACTIONBAR_UPDATE_STATE"
        or eventName == "UPDATE_BONUS_ACTIONBAR"
        or eventName == "PLAYER_AURAS_CHANGED"
        or eventName == "PLAYER_TARGET_CHANGED" then
        if PRP_ActionBar then
            PRP_ActionBar:OnEvent(eventName, firstArg)
        end
    end

    if PRP_Targeting then
        PRP_Targeting:OnEvent(eventName, firstArg)
    end
    if PRP_Inventory then
        PRP_Inventory:OnEvent(eventName, firstArg)
    end
    if PRP_Focus then
        PRP_Focus:OnEvent(eventName, firstArg)
    end
end

function PRP:OnUpdate(elapsed)
    if not self.initialized then
        return
    end
    if PRP_UI and PRP_UI.OnUpdate then
        PRP_UI:OnUpdate(elapsed)
    end
    if PRP_ActionBar and PRP_ActionBar.OnUpdate then
        PRP_ActionBar:OnUpdate(elapsed)
    end
    if PRP_Targeting and PRP_Targeting.OnUpdate then
        PRP_Targeting:OnUpdate(elapsed)
    end
    if PRP_Inventory and PRP_Inventory.OnUpdate then
        PRP_Inventory:OnUpdate(elapsed)
    end
    if PRP_QuickMenu and PRP_QuickMenu.OnUpdate then
        PRP_QuickMenu:OnUpdate(elapsed)
    end
    if PRP_Focus and PRP_Focus.OnUpdate then
        PRP_Focus:OnUpdate(elapsed)
    end
end

function PRP_OnEvent()
    PRP:OnEvent(event, arg1)
end

function PRP_OnUpdate()
    PRP:OnUpdate(arg1 or 0)
end

PRP_EventFrame = CreateFrame("Frame", "PocketRealmPadEventFrame", UIParent)
PRP_EventFrame:RegisterEvent("ADDON_LOADED")
PRP_EventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
PRP_EventFrame:RegisterEvent("PLAYER_LEAVING_WORLD")
PRP_EventFrame:RegisterEvent("UPDATE_BINDINGS")
PRP_EventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_USABLE")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
PRP_EventFrame:RegisterEvent("ACTIONBAR_UPDATE_STATE")
PRP_EventFrame:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
PRP_EventFrame:RegisterEvent("PLAYER_AURAS_CHANGED")
PRP_EventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
PRP_EventFrame:RegisterEvent("UNIT_HEALTH")
PRP_EventFrame:RegisterEvent("UNIT_MAXHEALTH")
PRP_EventFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")
PRP_EventFrame:RegisterEvent("RAID_ROSTER_UPDATE")
PRP_EventFrame:RegisterEvent("BAG_UPDATE")
PRP_EventFrame:RegisterEvent("MERCHANT_SHOW")
PRP_EventFrame:RegisterEvent("MERCHANT_CLOSED")
PRP_EventFrame:RegisterEvent("GOSSIP_SHOW")
PRP_EventFrame:RegisterEvent("GOSSIP_CLOSED")
PRP_EventFrame:RegisterEvent("QUEST_GREETING")
PRP_EventFrame:RegisterEvent("QUEST_DETAIL")
PRP_EventFrame:RegisterEvent("QUEST_PROGRESS")
PRP_EventFrame:RegisterEvent("QUEST_COMPLETE")
PRP_EventFrame:RegisterEvent("QUEST_FINISHED")
PRP_EventFrame:RegisterEvent("LOOT_OPENED")
PRP_EventFrame:RegisterEvent("LOOT_CLOSED")
PRP_EventFrame:SetScript("OnEvent", PRP_OnEvent)
PRP_EventFrame:SetScript("OnUpdate", PRP_OnUpdate)
