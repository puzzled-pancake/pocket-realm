# Android product integration contract

## Repository placement

Place the project-owned addon source under the product repository's `addons/PocketRealmPad/` directory. Build tooling copies it to the app-managed client's `Interface/AddOns/PocketRealmPad/` directory. The user-selected source client remains read-only and unchanged.

## Installation generation

The launcher should treat the addon as a versioned, manifest-owned generation:

```json
{
  "id": "pocket-realm-pad",
  "version": "0.1.0-alpha",
  "interface": 11200,
  "clientBuild": 5875,
  "sourceKind": "project-owned",
  "enabledInSafeMode": false,
  "filesManifestSha256": "<generated>",
  "mappingProfile": "winlator-keyboard-v1"
}
```

Installation steps while the client is stopped:

1. Verify the APK-owned addon source manifest.
2. Validate the active managed client is build 5875.
3. Stage the addon under a temporary generation directory.
4. Hash every staged file.
5. Atomically replace only the project-owned addon directory.
6. Preserve user addons and user-created SavedVariables.
7. Record the installed addon version in the managed-client manifest.

## Runtime ownership

- The Android input layer owns physical controller state and mouse synthesis.
- WoW owns key bindings, action slots, bags, unit selection, panels, and SavedVariables.
- Pocket Realm Pad owns only its frames and semantic routing.
- The Android launcher must not edit addon files, bindings, or SavedVariables while WoW is running.

## Safe-mode launch

The product's deterministic client safe mode should either disable the addon from the AddOns list or set `PocketRealmPadDB.safeMode = 1` before launch while the client is stopped. Disabling the addon is the stronger diagnostic because it isolates all addon code.

## Compatibility and update rules

- Pin the addon version to the Android app/runtime compatibility manifest.
- A code update is delivered only through the signed APK/product update path.
- Do not download mutable Lua code into the managed client.
- Preserve one prior addon generation until the updated client reaches a defined successful milestone.
- Any change to bindings, action-slot interpretation, SavedVariables schema, or frame adapters requires an explicit compatibility-class entry and migration test.

## Diagnostics

The Android support bundle may include:

- Addon version and file-manifest digest.
- `PocketRealmPadDB` with no account credentials or chat content.
- Selected Winlator input-profile ID.
- WoW resolution and UI scale.
- A user-triggered `/prp status` capture.
- Addon error text from the client log, if available.

It must not include proprietary client files or arbitrary user addon contents.
