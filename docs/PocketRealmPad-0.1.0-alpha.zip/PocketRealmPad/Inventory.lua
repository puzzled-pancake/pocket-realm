-- Controller-first inventory browser for the five Vanilla bag containers.
-- The panel never owns item data. It is a view over bag 0 and bags 1-4 and
-- routes only to the ordinary 1.12 container API.

PRP_Inventory = {
    initialized = false,
    entries = {},
    cells = {},
    selected = 1,
    page = 1,
    pageSize = 20,
    rebuildPending = false,
    elapsed = 0,
    pendingSaleKey = nil,
    pendingSaleUntil = 0,
}

function PRP_Inventory:Initialize()
    local columns
    local rows
    local index
    local cell
    local column
    local row
    local size = 42
    local spacing = 4
    local width
    local height

    if self.initialized then
        return
    end

    columns = PocketRealmPadDB.inventory.columns or 5
    rows = PocketRealmPadDB.inventory.rows or 4
    self.pageSize = columns * rows
    width = 28 + (columns * size) + ((columns - 1) * spacing)
    height = 80 + (rows * size) + ((rows - 1) * spacing)

    self.frame = PRP_UI:CreatePanel("PocketRealmPadInventory", width, height, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.frame:Hide()

    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Controller inventory")
    self.title:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14, -12)

    self.pageText = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "Page 1 / 1")
    self.pageText:SetPoint("TOPRIGHT", self.frame, "TOPRIGHT", -14, -17)

    self.hint = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "A use/equip   B close   X pick up")
    self.hint:SetPoint("BOTTOMLEFT", self.frame, "BOTTOMLEFT", 14, 12)
    self.hint:SetWidth(width - 28)
    self.hint:SetJustifyH("LEFT")

    for index = 1, self.pageSize do
        cell = self:CreateCell(index, size)
        column = math.mod(index - 1, columns)
        row = math.floor((index - 1) / columns)
        cell:SetPoint("TOPLEFT", self.frame, "TOPLEFT", 14 + (column * (size + spacing)), -46 - (row * (size + spacing)))
        self.cells[index] = cell
    end

    self.initialized = true
    self:Rebuild(true)
end

function PRP_Inventory:CreateCell(index, size)
    local button = CreateFrame("Button", "PocketRealmPadInventoryCell" .. index, self.frame)
    local icon
    local count
    local bagText
    local border

    button.prpCellIndex = index
    button:SetWidth(size)
    button:SetHeight(size)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -3, 3)
    button.icon = icon

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetWidth(size * 1.72)
    border:SetHeight(size * 1.72)
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    button.border = border

    count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    count:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -2, 2)
    button.count = count

    bagText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    bagText:SetPoint("TOPLEFT", button, "TOPLEFT", 3, -3)
    bagText:SetJustifyH("LEFT")
    button.bagText = bagText

    button:SetScript("OnEnter", PRP_InventoryCell_OnEnter)
    button:SetScript("OnLeave", PRP_InventoryCell_OnLeave)
    button:SetScript("OnClick", PRP_InventoryCell_OnClick)
    return button
end

function PRP_Inventory:IsShown()
    return self.frame and PRP_IsVisible(self.frame)
end

function PRP_Inventory:BuildEntries()
    local entries = {}
    local count = 0
    local bag
    local slot
    local slots

    for bag = 0, 4 do
        slots = GetContainerNumSlots and GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            count = count + 1
            entries[count] = { bag = bag, slot = slot }
        end
    end
    self.entries = entries
end

function PRP_Inventory:GetPageCount()
    local total = PRP_TableLength(self.entries)
    local pages
    if total < 1 then
        return 1
    end
    pages = math.floor((total + self.pageSize - 1) / self.pageSize)
    if pages < 1 then
        pages = 1
    end
    return pages
end

function PRP_Inventory:NormalizeSelection()
    local total = PRP_TableLength(self.entries)
    if total < 1 then
        self.selected = 1
        self.page = 1
        return
    end
    if self.selected < 1 then
        self.selected = 1
    elseif self.selected > total then
        self.selected = total
    end
    self.page = math.floor((self.selected - 1) / self.pageSize) + 1
end

function PRP_Inventory:GetCellGlobalIndex(cellIndex)
    return ((self.page - 1) * self.pageSize) + cellIndex
end

function PRP_Inventory:GetEntryForCell(cellIndex)
    return self.entries[self:GetCellGlobalIndex(cellIndex)]
end

function PRP_Inventory:GetSelectedEntry()
    return self.entries[self.selected]
end

function PRP_Inventory:GetEntryKey(entry)
    if not entry then
        return nil
    end
    return tostring(entry.bag) .. ":" .. tostring(entry.slot)
end

function PRP_Inventory:UpdateCell(cellIndex)
    local cell = self.cells[cellIndex]
    local globalIndex = self:GetCellGlobalIndex(cellIndex)
    local entry = self.entries[globalIndex]
    local texture
    local itemCount
    local locked
    local quality
    local r
    local g
    local b

    if not cell then
        return
    end
    cell.prpGlobalIndex = globalIndex
    cell.prpEntry = entry

    if not entry then
        cell.icon:SetTexture(nil)
        cell.icon:Hide()
        cell.count:SetText("")
        cell.bagText:SetText("")
        cell.border:SetVertexColor(0.25, 0.25, 0.25, 0.35)
        cell:SetAlpha(0.25)
        return
    end

    texture, itemCount, locked, quality = GetContainerItemInfo(entry.bag, entry.slot)
    if texture then
        cell.icon:SetTexture(texture)
        cell.icon:Show()
        cell:SetAlpha(locked and 0.45 or 1)
    else
        cell.icon:SetTexture("Interface\\Buttons\\UI-EmptySlot")
        cell.icon:Show()
        cell:SetAlpha(0.55)
    end

    if itemCount and itemCount > 1 then
        cell.count:SetText(itemCount)
    else
        cell.count:SetText("")
    end
    cell.bagText:SetText(tostring(entry.bag) .. ":" .. tostring(entry.slot))

    if globalIndex == self.selected then
        cell.border:SetVertexColor(1, 0.82, 0, 1)
        cell.border:Show()
    elseif texture then
        r, g, b = PRP_ColorFromQuality(quality)
        cell.border:SetVertexColor(r, g, b, 0.65)
        cell.border:Show()
    else
        cell.border:SetVertexColor(0.25, 0.25, 0.25, 0.35)
        cell.border:Show()
    end
end

function PRP_Inventory:UpdateHint()
    local entry = self:GetSelectedEntry()
    local link
    local text
    if not entry then
        self.hint:SetText("No bag slots available   B close")
        return
    end
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil
    if PRP_IsVisible(MerchantFrame) and link then
        text = "A twice to sell   X pick up   B close"
    elseif link then
        text = "A use/equip   X pick up   B close"
    elseif CursorHasItem and CursorHasItem() then
        text = "A place item here   X place item here   B close"
    else
        text = "Empty slot   X pick up/place   B close"
    end
    self.hint:SetText(text)
end

function PRP_Inventory:UpdateVisual()
    local index
    local pages = self:GetPageCount()
    for index = 1, self.pageSize do
        self:UpdateCell(index)
    end
    self.pageText:SetText("Page " .. tostring(self.page) .. " / " .. tostring(pages))
    self:UpdateHint()

    if self:IsShown() then
        PRP:SetMode("INVENTORY")
        PRP_UI:SetPrompt("A use/equip   B close   X pick up   D-pad browse")
        PRP_UI:ClearFocus()
    end
end

function PRP_Inventory:Rebuild(force)
    if not self.initialized then
        return
    end
    self:BuildEntries()
    self:NormalizeSelection()
    self:UpdateVisual()
    self.rebuildPending = false
end

function PRP_Inventory:Show()
    if not self.initialized or PocketRealmPadDB.safeMode == 1 then
        return false
    end
    if PRP_QuickMenu and PRP_QuickMenu:IsShown() then
        PRP_QuickMenu:Hide()
    end
    self.pendingSaleKey = nil
    self.frame:Show()
    self:Rebuild(true)
    PRP:SetMode("INVENTORY")
    return true
end

function PRP_Inventory:Hide()
    if not self.frame then
        return
    end
    self.pendingSaleKey = nil
    self.frame:Hide()
    if GameTooltip then
        GameTooltip:Hide()
    end
    PRP_UI:SetPrompt("")
    if PRP_Focus then
        PRP_Focus:Detect(true)
    else
        PRP:SetMode("WORLD")
    end
end

function PRP_Inventory:Toggle()
    if self:IsShown() then
        self:Hide()
    else
        self:Show()
    end
end

function PRP_Inventory:SetSelected(index)
    local total = PRP_TableLength(self.entries)
    if total < 1 then
        self.selected = 1
        self.page = 1
        self:UpdateVisual()
        return false
    end
    while index < 1 do
        index = index + total
    end
    while index > total do
        index = index - total
    end
    self.selected = index
    self:NormalizeSelection()
    self:UpdateVisual()
    if PlaySound then
        PlaySound("igMainMenuOptionCheckBoxOn")
    end
    return true
end

function PRP_Inventory:Navigate(direction)
    local columns = PocketRealmPadDB.inventory.columns or 5
    local nextIndex = self.selected
    if direction == "LEFT" then
        nextIndex = nextIndex - 1
    elseif direction == "RIGHT" then
        nextIndex = nextIndex + 1
    elseif direction == "UP" then
        nextIndex = nextIndex - columns
    elseif direction == "DOWN" then
        nextIndex = nextIndex + columns
    else
        return false
    end
    return self:SetSelected(nextIndex)
end

function PRP_Inventory:Accept()
    local entry = self:GetSelectedEntry()
    local link
    local key
    local now
    local confirmSeconds

    if not entry then
        return false
    end
    link = GetContainerItemLink and GetContainerItemLink(entry.bag, entry.slot) or nil

    if not link then
        if CursorHasItem and CursorHasItem() and PickupContainerItem then
            PickupContainerItem(entry.bag, entry.slot)
            self.rebuildPending = true
            return true
        end
        PRP_UI:ShowToast("Empty bag slot")
        return false
    end

    if PRP_IsVisible(MerchantFrame) then
        key = self:GetEntryKey(entry)
        now = GetTime and GetTime() or 0
        confirmSeconds = PocketRealmPadDB.inventory.sellConfirmSeconds or 1.75
        if self.pendingSaleKey == key and now <= self.pendingSaleUntil then
            self.pendingSaleKey = nil
            self.pendingSaleUntil = 0
            UseContainerItem(entry.bag, entry.slot)
            PRP_UI:ShowToast("Sold selected item")
            self.rebuildPending = true
            return true
        end
        self.pendingSaleKey = key
        self.pendingSaleUntil = now + confirmSeconds
        PRP_UI:ShowToast("Press A again to sell")
        return true
    end

    self.pendingSaleKey = nil
    if UseContainerItem then
        UseContainerItem(entry.bag, entry.slot)
        self.rebuildPending = true
        return true
    end
    return false
end

function PRP_Inventory:Alternate()
    local entry = self:GetSelectedEntry()
    if not entry or not PickupContainerItem then
        return false
    end
    self.pendingSaleKey = nil
    PickupContainerItem(entry.bag, entry.slot)
    self.rebuildPending = true
    return true
end

function PRP_Inventory:Back()
    self:Hide()
    return true
end

function PRP_Inventory:OnEvent(eventName, firstArg)
    if eventName == "BAG_UPDATE" then
        self.rebuildPending = true
    elseif eventName == "MERCHANT_SHOW" or eventName == "MERCHANT_CLOSED" then
        self.pendingSaleKey = nil
        if self:IsShown() then
            self:UpdateHint()
        end
    end
end

function PRP_Inventory:OnUpdate(elapsed)
    local now
    self.elapsed = self.elapsed + elapsed
    if self.pendingSaleKey then
        now = GetTime and GetTime() or 0
        if now > self.pendingSaleUntil then
            self.pendingSaleKey = nil
            self.pendingSaleUntil = 0
            if self:IsShown() then
                self:UpdateHint()
            end
        end
    end
    if self.rebuildPending and self.elapsed >= 0.08 then
        self.elapsed = 0
        self:Rebuild(false)
    elseif self.elapsed >= 0.25 then
        self.elapsed = 0
    end
end

function PRP_InventoryCell_OnEnter()
    local cell = this
    local entry = cell and cell.prpEntry
    if not entry or not GameTooltip or not GameTooltip.SetBagItem then
        return
    end
    GameTooltip:SetOwner(cell, "ANCHOR_RIGHT")
    GameTooltip:SetBagItem(entry.bag, entry.slot)
    GameTooltip:Show()
end

function PRP_InventoryCell_OnLeave()
    if GameTooltip then
        GameTooltip:Hide()
    end
end

function PRP_InventoryCell_OnClick()
    local cell = this
    local index = cell and cell.prpGlobalIndex
    if not index then
        return
    end
    PRP_Inventory:SetSelected(index)
    if arg1 == "RightButton" then
        PRP_Inventory:Alternate()
    else
        PRP_Inventory:Accept()
    end
end
