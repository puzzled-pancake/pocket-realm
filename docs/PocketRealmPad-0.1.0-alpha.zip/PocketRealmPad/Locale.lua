-- Pocket Realm Pad
-- Original clean-room code. WoW 1.12.1 / Interface 11200.

BINDING_HEADER_POCKETREALMPAD = "Pocket Realm Pad"

BINDING_NAME_PRP_ACTION1 = "Semantic action 1 / UI accept"
BINDING_NAME_PRP_ACTION2 = "Semantic action 2 / UI back"
BINDING_NAME_PRP_ACTION3 = "Semantic action 3 / UI alternate"
BINDING_NAME_PRP_ACTION4 = "Semantic action 4 / quick menu"
BINDING_NAME_PRP_ACTION5 = "Semantic action 5"
BINDING_NAME_PRP_ACTION6 = "Semantic action 6"
BINDING_NAME_PRP_ACTION7 = "Semantic action 7"
BINDING_NAME_PRP_ACTION8 = "Semantic action 8"
BINDING_NAME_PRP_ACTION9 = "Semantic action 9"
BINDING_NAME_PRP_ACTION10 = "Semantic action 10"
BINDING_NAME_PRP_ACTION11 = "Semantic action 11"
BINDING_NAME_PRP_ACTION12 = "Semantic action 12"

BINDING_NAME_PRP_NAV_UP = "Navigate up / next enemy"
BINDING_NAME_PRP_NAV_DOWN = "Navigate down / previous enemy"
BINDING_NAME_PRP_NAV_LEFT = "Navigate left / previous group unit"
BINDING_NAME_PRP_NAV_RIGHT = "Navigate right / next group unit"

BINDING_NAME_PRP_QUICK_MENU = "Quick menu (hold or tap)"
BINDING_NAME_PRP_INVENTORY = "Controller inventory"
BINDING_NAME_PRP_CHAT = "Open chat"
BINDING_NAME_PRP_CHAT_SLASH = "Open slash command"

BINDING_NAME_PRP_TARGET_NEXT_ENEMY = "Target next enemy"
BINDING_NAME_PRP_TARGET_PREV_ENEMY = "Target previous enemy"
BINDING_NAME_PRP_TARGET_NEXT_FRIEND = "Target next friend"
BINDING_NAME_PRP_TARGET_PREV_FRIEND = "Target previous friend"
BINDING_NAME_PRP_TARGET_GROUP_NEXT = "Target next group unit"
BINDING_NAME_PRP_TARGET_GROUP_PREV = "Target previous group unit"
BINDING_NAME_PRP_TARGET_LAST_HOSTILE = "Target last hostile"
BINDING_NAME_PRP_ASSIST_TARGET = "Assist current target"
