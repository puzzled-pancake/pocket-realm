-- Product-owned defaults. The Android launcher may replace this file only while
-- the client is stopped, and only inside the managed client copy.

PRP_PROFILE_ID = "winlator-keyboard-v1"

PRP_DEFAULTS = {
    enabled = 1,
    safeMode = 0,
    debug = 0,
    scale = 1.00,
    mappingProfile = PRP_PROFILE_ID,

    bar = {
        shown = 1,
        locked = 1,
        point = "BOTTOM",
        relativePoint = "BOTTOM",
        x = 0,
        y = 84,
        alpha = 0.95,
        columns = 6,
        buttonSize = 40,
        spacing = 3,
    },

    target = {
        shown = 1,
        point = "TOP",
        relativePoint = "TOP",
        x = 0,
        y = -48,
    },

    focus = {
        enabled = 1,
        scanInterval = 0.12,
        wrap = 1,
        scrollStep = 40,
    },

    inventory = {
        columns = 5,
        rows = 4,
        sellConfirmSeconds = 1.75,
    },

    quickMenu = {
        holdThreshold = 0.20,
        radius = 106,
    },

    buttonLabels = {
        "1", "2", "3", "4", "5", "6",
        "7", "8", "9", "10", "11", "12",
    },
}
