-- Digital radial quick menu. The physical controller is translated to ordinary
-- key events by Winlator; this module only supplies deterministic UI semantics.

PRP_QuickMenu = {
    initialized = false,
    entries = {},
    buttons = {},
    selected = 1,
    pressed = false,
    pressStarted = 0,
    pressWasOpen = false,
    movedWhilePressed = false,
    latched = false,
}

function PRP_QuickMenu:Initialize()
    local radius
    local index
    local entry
    local button
    local angle
    local x
    local y

    if self.initialized then
        return
    end

    self.entries = {
        { id = "character", label = "Character", icon = "Interface\\Icons\\INV_Misc_Head_Dragon_01", action = "CHARACTER" },
        { id = "spellbook", label = "Spellbook", icon = "Interface\\Icons\\INV_Misc_Book_09", action = "SPELLBOOK" },
        { id = "quests", label = "Quest log", icon = "Interface\\Icons\\INV_Misc_Note_01", action = "QUESTS" },
        { id = "map", label = "World map", icon = "Interface\\Icons\\INV_Misc_Map_01", action = "MAP" },
        { id = "menu", label = "Game menu", icon = "Interface\\Icons\\INV_Misc_Gear_01", action = "MENU" },
        { id = "social", label = "Social", icon = "Interface\\Icons\\INV_Misc_GroupNeedMore", action = "SOCIAL" },
        { id = "chat", label = "Chat", icon = "Interface\\Icons\\INV_Letter_15", action = "CHAT" },
        { id = "bags", label = "Inventory", icon = "Interface\\Icons\\INV_Misc_Bag_08", action = "BAGS" },
    }

    self.frame = PRP_UI:CreatePanel("PocketRealmPadQuickMenu", 330, 330, "DIALOG")
    self.frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    self.frame:SetScale(PocketRealmPadDB.scale or 1)
    self.frame:Hide()

    self.title = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontNormalLarge", "Quick menu")
    self.title:SetPoint("CENTER", self.frame, "CENTER", 0, 18)

    self.subtitle = PRP_UI:CreateLabel(self.frame, "OVERLAY", "GameFontHighlightSmall", "Tap to latch, hold + D-pad to choose")
    self.subtitle:SetPoint("CENTER", self.frame, "CENTER", 0, -4)
    self.subtitle:SetWidth(170)
    self.subtitle:SetJustifyH("CENTER")

    radius = PocketRealmPadDB.quickMenu.radius or 106
    for index = 1, PRP_TableLength(self.entries) do
        entry = self.entries[index]
        button = self:CreateButton(index, entry)
        angle = math.rad(90 - ((index - 1) * 45))
        x = math.cos(angle) * radius
        y = math.sin(angle) * radius
        button:SetPoint("CENTER", self.frame, "CENTER", x, y)
        self.buttons[index] = button
    end

    self.initialized = true
    self:UpdateVisual()
end

function PRP_QuickMenu:CreateButton(index, entry)
    local button = CreateFrame("Button", "PocketRealmPadQuickMenuButton" .. index, self.frame)
    local icon
    local label
    local border

    button.prpIndex = index
    button:SetWidth(64)
    button:SetHeight(64)
    button:RegisterForClicks("LeftButtonUp")
    button:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2")
    button:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress")
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")

    icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetPoint("TOPLEFT", button, "TOPLEFT", 5, -5)
    icon:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -5, 5)
    icon:SetTexture(entry.icon)
    button.icon = icon

    border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    border:SetWidth(100)
    border:SetHeight(100)
    border:SetPoint("CENTER", button, "CENTER", 0, 0)
    border:SetBlendMode("ADD")
    button.border = border

    label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmallOutline")
    label:SetPoint("TOP", button, "BOTTOM", 0, -1)
    label:SetWidth(90)
    label:SetJustifyH("CENTER")
    label:SetText(entry.label)
    button.label = label

    button:SetScript("OnEnter", PRP_QuickMenuButton_OnEnter)
    button:SetScript("OnClick", PRP_QuickMenuButton_OnClick)
    return button
end

function PRP_QuickMenu:IsShown()
    return self.frame and PRP_IsVisible(self.frame)
end

function PRP_QuickMenu:Show()
    if not self.initialized or PocketRealmPadDB.safeMode == 1 then
        return false
    end
    if PRP_Inventory and PRP_Inventory:IsShown() then
        PRP_Inventory:Hide()
    end
    self.frame:Show()
    self:UpdateVisual()
    PRP:SetMode("QUICK MENU")
    PRP_UI:SetPrompt("D-pad choose   A open   B close")
    PRP_UI:ClearFocus()
    return true
end

function PRP_QuickMenu:Hide()
    if not self.frame then
        return
    end
    self.frame:Hide()
    self.pressed = false
    self.pressWasOpen = false
    self.movedWhilePressed = false
    self.latched = false
    PRP_UI:SetPrompt("")
    if PRP_Focus then
        PRP_Focus:Detect(true)
    else
        PRP:SetMode("WORLD")
    end
end

function PRP_QuickMenu:Toggle()
    if self:IsShown() then
        self:Hide()
    else
        self.latched = true
        self:Show()
    end
end

function PRP_QuickMenu:UpdateVisual()
    local index
    local button
    local entry
    for index = 1, PRP_TableLength(self.buttons) do
        button = self.buttons[index]
        if index == self.selected then
            button.border:SetVertexColor(1, 0.82, 0, 1)
            button:SetAlpha(1)
        else
            button.border:SetVertexColor(0.35, 0.55, 0.85, 0.45)
            button:SetAlpha(0.82)
        end
    end
    entry = self.entries[self.selected]
    if entry and self.title then
        self.title:SetText(entry.label)
    end
end

function PRP_QuickMenu:GetDirectionalCandidate(dx, dy)
    local current = self.buttons[self.selected]
    local currentX
    local currentY
    local candidate
    local candidateX
    local candidateY
    local vx
    local vy
    local forward
    local perpendicular
    local score
    local bestScore
    local bestIndex
    local index

    if not current then
        return nil
    end
    currentX, currentY = PRP_FrameCenter(current)
    if not currentX or not currentY then
        return nil
    end
    for index = 1, PRP_TableLength(self.buttons) do
        if index ~= self.selected then
            candidate = self.buttons[index]
            candidateX, candidateY = PRP_FrameCenter(candidate)
            if candidateX and candidateY then
                vx = candidateX - currentX
                vy = candidateY - currentY
                forward = (vx * dx) + (vy * dy)
                if forward > 1 then
                    perpendicular = math.abs((vx * dy) - (vy * dx))
                    score = forward + (perpendicular * 2.4)
                    if not bestScore or score < bestScore then
                        bestScore = score
                        bestIndex = index
                    end
                end
            end
        end
    end
    return bestIndex
end

function PRP_QuickMenu:Navigate(direction)
    local dx = 0
    local dy = 0
    local candidate
    if direction == "LEFT" then
        dx = -1
    elseif direction == "RIGHT" then
        dx = 1
    elseif direction == "UP" then
        dy = 1
    elseif direction == "DOWN" then
        dy = -1
    else
        return false
    end
    candidate = self:GetDirectionalCandidate(dx, dy)
    if not candidate then
        if direction == "UP" then
            candidate = 1
        elseif direction == "RIGHT" then
            candidate = 3
        elseif direction == "DOWN" then
            candidate = 5
        else
            candidate = 7
        end
    end
    self.selected = candidate
    if self.pressed then
        self.movedWhilePressed = true
    end
    self:UpdateVisual()
    if PlaySound then
        PlaySound("igMainMenuOptionCheckBoxOn")
    end
    return true
end

function PRP_QuickMenu:RunAction(action)
    if action == "CHARACTER" then
        if ToggleCharacter then
            ToggleCharacter("PaperDollFrame")
            return true
        end
    elseif action == "SPELLBOOK" then
        if ToggleSpellBook then
            ToggleSpellBook(BOOKTYPE_SPELL)
            return true
        end
    elseif action == "QUESTS" then
        if ToggleQuestLog then
            ToggleQuestLog()
            return true
        end
    elseif action == "MAP" then
        if ToggleWorldMap then
            ToggleWorldMap()
            return true
        end
    elseif action == "MENU" then
        if ToggleGameMenu then
            ToggleGameMenu()
            return true
        end
    elseif action == "SOCIAL" then
        if ToggleFriendsFrame then
            ToggleFriendsFrame()
            return true
        end
    elseif action == "CHAT" then
        if PRP_Router and PRP_Router.OpenChat then
            PRP_Router:OpenChat(false)
            return true
        end
    elseif action == "BAGS" then
        if PRP_Inventory then
            PRP_Inventory:Show()
            return true
        end
    end
    return false
end

function PRP_QuickMenu:Activate()
    local entry = self.entries[self.selected]
    local action
    if not entry then
        return false
    end
    action = entry.action
    self:Hide()
    return self:RunAction(action)
end

function PRP_QuickMenu:Accept()
    return self:Activate()
end

function PRP_QuickMenu:Alternate()
    return self:Activate()
end

function PRP_QuickMenu:Back()
    self:Hide()
    return true
end

function PRP_QuickMenu:OnKey(state)
    local now = GetTime and GetTime() or 0
    local elapsed
    local threshold

    if state == "down" then
        if not self:IsShown() then
            self.latched = false
            self:Show()
            self.pressWasOpen = false
        else
            self.pressWasOpen = self.latched and true or false
        end
        self.pressed = true
        self.pressStarted = now
        self.movedWhilePressed = false
        return
    end

    if not self.pressed then
        return
    end
    self.pressed = false
    elapsed = now - self.pressStarted
    threshold = PocketRealmPadDB.quickMenu.holdThreshold or 0.20

    if self.pressWasOpen then
        self:Hide()
        return
    end
    if self.movedWhilePressed or elapsed >= threshold then
        self:Activate()
        return
    end

    self.latched = true
    self.subtitle:SetText("Latched: D-pad choose, A open, B close")
    PRP_UI:SetPrompt("D-pad choose   A open   B close")
end

function PRP_QuickMenu:OnUpdate(elapsed)
    local now
    local held
    local threshold
    if not self.pressed or not self:IsShown() then
        return
    end
    now = GetTime and GetTime() or 0
    held = now - self.pressStarted
    threshold = PocketRealmPadDB.quickMenu.holdThreshold or 0.20
    if held >= threshold then
        self.subtitle:SetText("Release to open selected item")
    end
end

function PRP_QuickMenuButton_OnEnter()
    local button = this
    if button and button.prpIndex then
        PRP_QuickMenu.selected = button.prpIndex
        PRP_QuickMenu:UpdateVisual()
    end
end

function PRP_QuickMenuButton_OnClick()
    local button = this
    if button and button.prpIndex then
        PRP_QuickMenu.selected = button.prpIndex
        PRP_QuickMenu:Activate()
    end
end
