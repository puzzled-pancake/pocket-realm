# Pocket Realm Pad 0.1.0-alpha

Pocket Realm Pad is an original World of Warcraft 1.12.1 addon for an Android/Winlator setup in which the compatibility layer owns the physical controller and converts it to ordinary keyboard and mouse events. The addon does **not** read a controller, joystick, or Android input device. It supplies only in-game semantics: action layers, targeting, a controller inventory, directional menu focus, a quick menu, chat entry, and visible mode/status feedback.

## Status

This package is an engineering prototype, not a release-qualified addon.

- Target client: World of Warcraft 1.12.1, build 5875.
- TOC interface: `11200`.
- Language/API discipline: Vanilla-era Lua and FrameXML only.
- Host checks: 13 Lua modules, one TOC, one `Bindings.xml`; 53 mock-runtime assertions.
- Not yet proved: loading and end-to-end use in the actual build-5875 client under the project's Wine/Winlator runtime.

## Ownership boundary

```text
Physical controller
        |
        v
Winlator input profile
  - stick -> W/A/S/D and relative mouse
  - buttons -> keyboard keys
  - pointer/right-click -> world interaction
        |
        v
WoW 1.12 binding system (`Bindings.xml`)
        |
        v
Pocket Realm Pad semantic router
  - WORLD       -> actions and targeting
  - FOCUS       -> panel navigation
  - INVENTORY   -> bag operations
  - QUICK       -> quick menu
  - CHAT        -> input suppression while IME/edit box is active
```

The boundary is deliberate. Winlator is responsible for dead zones, analog curves, camera motion, mouse buttons, key-up reliability, and device hot-plug behavior. The addon is responsible for not allowing a translated key to mean two conflicting things at once.

## Implemented behavior

### Four action layers

Twelve visible semantic action buttons expose 48 ordinary Vanilla action slots:

| Controller modifier state | Addon layer | Action slots |
|---|---:|---:|
| None | Base | 1-12, or the active Vanilla bonus/stance slots |
| Shift | Shift | 13-24 |
| Control | Control | 25-36 |
| Shift + Control | Shift + Control | 37-48 |
| Alt | Self-cast modifier | Applied to the captured slot |

The exact slot and self-cast state are captured on key down and reused on key up. Releasing a shoulder modifier before the face button therefore does not cast from a different page.

### Context routing

The router uses this strict priority:

1. Chat edit box
2. Quick menu
3. Controller inventory
4. Explicit Blizzard-frame focus adapter
5. World/gameplay

In a UI context, the first four semantic action buttons mean:

| Semantic action | UI meaning |
|---:|---|
| 1 | Accept/use/open |
| 2 | Back/close/cancel |
| 3 | Alternate/right-click/pick up |
| 4 | Quick menu |

Actions 5-12 are consumed while a semantic panel is active so they cannot accidentally cast abilities through a menu.

### Targeting

- D-pad up/down: next/previous nearest enemy.
- D-pad left/right: previous/next player, party, raid, and group-pet unit.
- Optional direct bindings: next/previous friend, last hostile, assist target.
- Target card: name, level, classification, reaction color, and health.

Vanilla 1.12 has no modern soft-target/nameplate-interact stack. Precise world interaction remains Winlator mouse/right-click behavior.

### Explicit directional UI focus

Pocket Realm Pad does not scan every visible frame or attempt to recreate modern secure cursor code. It has bounded adapters for known 1.12 frames:

- Static popups
- Quest dialog and rewards
- Gossip
- Loot
- Merchant
- Game menu
- Spellbook
- Character/equipment
- Quest log
- Social/friends/who
- World map

The focus engine builds a list only from adapter-declared controls, removes hidden/disabled entries, preserves the current control across refreshes, and chooses the next control by screen-space geometry. Scroll bars are stepped only when no directional candidate is available.

### Controller inventory

- Enumerates bag 0 and equipped bags 1-4 with `GetContainerNumSlots`.
- Displays occupied and empty slots in a 5 x 4 paged grid.
- Action 1 uses/equips an item or places the cursor item in an empty slot.
- Action 3 picks up/places the selected item.
- At a merchant, selling requires two presses on the same slot within the configured confirmation window.
- Tooltips use the normal 1.12 bag-item tooltip API.

### Quick menu

Eight digital radial entries provide Character, Spellbook, Quest Log, World Map, Game Menu, Social, Chat, and Controller Inventory.

- Tap: latch the menu open.
- Hold + D-pad: select an entry; release to activate.
- While latched: D-pad chooses, Action 1 activates, Action 2 closes.

No analog stick API is used. The radial is a visual arrangement driven by ordinary translated D-pad keys.

### Chat

The chat binding opens the normal 1.12 chat edit box. The Android/Winlator layer may then deliver text through its keyboard/IME path. Pocket Realm Pad releases pending action state before chat opens and consumes semantic action keys while the edit box is visible.

### Safe mode and recovery

`/prp safe on` hides semantic overlays and disables focus, inventory, and quick-menu behavior while retaining action bindings. `/prp disable` releases all captured state. The addon also releases pending actions on world transitions.

## Recommended Winlator-to-WoW binding profile

This is a logical recommendation, not a hard-coded dependency. Bind the generated keyboard keys to the named Pocket Realm Pad commands in WoW's Key Bindings panel.

| Physical control | Winlator event | WoW binding |
|---|---|---|
| Left stick | W/A/S/D | Built-in movement/strafe |
| Right stick | Relative mouse with camera-look state | Winlator/Wine mouse path |
| A / Cross | Dedicated key | Semantic action 1 |
| B / Circle | Dedicated key | Semantic action 2 |
| X / Square | Dedicated key | Semantic action 3 |
| Y / Triangle | Dedicated key | Semantic action 4 |
| R1 | Dedicated key | Semantic action 5 |
| R2 | Dedicated key | Semantic action 6 |
| Additional rear/touch buttons | Dedicated keys | Semantic actions 7-12 |
| L1 | Shift key down/up | Action layer modifier |
| L2 | Control key down/up | Action layer modifier |
| L3 or a paddle | Alt key down/up | Self-cast modifier |
| D-pad | Four dedicated keys | PRP navigation bindings |
| R3 | Dedicated key | Quick menu |
| Select/View | Dedicated key | Controller inventory |
| Start/Menu | Escape or dedicated key | Built-in game menu / PRP quick menu |
| World primary | Left mouse | Pointer interaction |
| World secondary | Right mouse | Interact/context/camera-look |

Do not map one physical button to both a Pocket Realm Pad binding and a conflicting default WoW binding.

## Installation in a normal 1.12 client

1. Stop the client completely.
2. Copy the `PocketRealmPad` folder to `Interface/AddOns/PocketRealmPad` in the app-managed WoW client.
3. Start WoW and enable **Pocket Realm Pad** at the AddOns screen.
4. Open Key Bindings and assign the translated Winlator keys under the **Pocket Realm Pad** header.
5. Place abilities/items/macros in action slots 1-48. Slots 1-12 are the base layer; 13-24 Shift; 25-36 Control; 37-48 Shift+Control.
6. Run `/prp status` and test every key-down/key-up path before combat.

For the Android product, the launcher should install this directory as a manifest-owned addon into the managed client only. It must never modify the user's source client directory.

## Slash commands

```text
/prp status
/prp enable
/prp disable
/prp safe on
/prp safe off
/prp bar show
/prp bar hide
/prp bar lock
/prp bar unlock
/prp scale 0.70-1.50
/prp debug on
/prp debug off
/prp reset
```

## File map

| File | Responsibility |
|---|---|
| `PocketRealmPad.toc` | Interface 11200 manifest and load order |
| `Bindings.xml` | Bindable semantic commands and key-up delivery |
| `Locale.lua` | Binding labels |
| `Profile.lua` | Product-owned defaults and profile identifier |
| `Compat.lua` | Small 1.12 compatibility helpers |
| `Core.lua` | Lifecycle, events, global refresh and release |
| `UI.lua` | Panels, prompts, toast, mode badge, focus ring |
| `ActionBar.lua` | 12-button/4-layer action presentation and use |
| `Targeting.lua` | Enemy/friend/group targeting and target card |
| `Focus.lua` | Directional focus graph and semantic activation |
| `Adapters.lua` | Explicit known-frame adapters |
| `Inventory.lua` | Paged controller bag view and safe merchant behavior |
| `QuickMenu.lua` | Digital radial menu and panel shortcuts |
| `Router.lua` | Context priority and translated-key semantics |
| `Slash.lua` | Recovery/development command surface |
| `tests/static_check.py` | API/syntax/manifest checks |
| `tests/runtime_mock.lua` | Host-side mocked 1.12 behavior assertions |

## Development tests

From the addon directory:

```sh
./tests/run_tests.sh
```

Expected alpha result:

```text
STATIC PASS: 13 Lua files, 1 TOC, 1 Bindings.xml
RUNTIME MOCK PASS: 53 assertions
ALL HOST TESTS PASS
```

These tests detect many accidental modern API and Lua-language regressions. They do not emulate the WoW renderer, protected-action rules, every FrameXML script, or actual Wine input timing.

## Known limitations

- No actual build-5875 client run has been performed in this workspace.
- The adapter list covers common leveling/menu flows, not every Blizzard panel or third-party addon.
- World-object interaction, camera movement, cursor placement, drag trajectories, and analog behavior remain outside the addon.
- The quick menu is digital; Vanilla exposes no controller-stick state.
- The addon does not replace the Blizzard action bars or edit their contents.
- The first alpha does not automatically install key bindings; binding is explicit and reversible in the normal key-binding UI.
- The hard-coded A/B/X wording assumes the recommended physical layout, although all commands remain remappable.
- Locale text is English; frame discovery uses stable global frame names rather than localized labels.

## Provenance and license

This is original clean-room code. ConsolePort was studied for behavior and architecture, but its code, artwork, naming, and packaged assets were not copied. Pocket Realm Pad is licensed under the MIT License; see `LICENSE`.
