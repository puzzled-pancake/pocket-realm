-- Semantic input router. Winlator owns the physical controller and converts it
-- to keyboard/mouse. These bindings decide only what a translated key means in
-- the current Vanilla UI/gameplay context.

PRP_Router = {
    initialized = false,
    captured = {},
}

function PRP_Router:Initialize()
    self.initialized = true
end

function PRP_Router:GetContext()
    if PRP_ChatEditActive() then
        return "CHAT"
    end
    if PRP_QuickMenu and PRP_QuickMenu:IsShown() then
        return "QUICK"
    end
    if PRP_Inventory and PRP_Inventory:IsShown() then
        return "INVENTORY"
    end
    if PRP_Focus and PRP_Focus:IsActive() then
        return "FOCUS"
    end
    return "WORLD"
end

function PRP_Router:IsUIContext(context)
    return context == "CHAT" or context == "QUICK" or context == "INVENTORY" or context == "FOCUS"
end

function PRP_Router:ExecuteSemantic(context, index)
    if context == "QUICK" then
        if index == 1 then
            return PRP_QuickMenu:Accept()
        elseif index == 2 then
            return PRP_QuickMenu:Back()
        elseif index == 3 then
            return PRP_QuickMenu:Alternate()
        elseif index == 4 then
            PRP_QuickMenu:Hide()
            return true
        end
        return true
    elseif context == "INVENTORY" then
        if index == 1 then
            return PRP_Inventory:Accept()
        elseif index == 2 then
            return PRP_Inventory:Back()
        elseif index == 3 then
            return PRP_Inventory:Alternate()
        elseif index == 4 then
            PRP_QuickMenu:Show()
            return true
        end
        return true
    elseif context == "FOCUS" then
        if index == 1 then
            return PRP_Focus:Accept()
        elseif index == 2 then
            return PRP_Focus:Back()
        elseif index == 3 then
            return PRP_Focus:Alternate()
        elseif index == 4 then
            PRP_QuickMenu:Show()
            return true
        end
        return true
    elseif context == "CHAT" then
        return true
    end
    return false
end

function PRP_Router:ActionKey(index, state)
    local context
    local captured

    if not self.initialized or not PRP:IsEnabled() then
        return
    end

    if state == "down" then
        context = self:GetContext()
        if self:IsUIContext(context) then
            self.captured[index] = context
            return
        end
        self.captured[index] = nil
        if PRP_ActionBar then
            PRP_ActionBar:OnKey(index, "down")
        end
        return
    end

    captured = self.captured[index]
    self.captured[index] = nil
    if captured then
        self:ExecuteSemantic(captured, index)
        return
    end
    if PRP_ActionBar then
        PRP_ActionBar:OnKey(index, "up")
    end
end

function PRP_Router:Navigate(direction)
    local context
    if not self.initialized or not PRP:IsEnabled() or PRP_ChatEditActive() then
        return
    end
    context = self:GetContext()
    if context == "QUICK" then
        PRP_QuickMenu:Navigate(direction)
    elseif context == "INVENTORY" then
        PRP_Inventory:Navigate(direction)
    elseif context == "FOCUS" then
        if direction == "UP" then
            PRP_Focus:Move(0, 1)
        elseif direction == "DOWN" then
            PRP_Focus:Move(0, -1)
        elseif direction == "LEFT" then
            PRP_Focus:Move(-1, 0)
        elseif direction == "RIGHT" then
            PRP_Focus:Move(1, 0)
        end
    elseif PRP_Targeting then
        PRP_Targeting:WorldDirection(direction)
    end
end

function PRP_Router:QuickMenuKey(state)
    if not self.initialized or not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 then
        return
    end
    PRP_QuickMenu:OnKey(state)
end

function PRP_Router:InventoryKey()
    if not self.initialized or not PRP:IsEnabled() or PocketRealmPadDB.safeMode == 1 then
        return
    end
    PRP_Inventory:Toggle()
end

function PRP_Router:OpenChat(slash)
    if not ChatFrame_OpenChat then
        return false
    end
    PRP:ReleaseAllInputs()
    if slash then
        ChatFrame_OpenChat("/")
    else
        ChatFrame_OpenChat("")
    end
    PRP:SetMode("CHAT")
    return true
end

function PRP_Router:TargetCommand(command)
    if not self.initialized or not PRP:IsEnabled() then
        return
    end
    if PRP_Targeting then
        PRP_Targeting:Command(command)
    end
end

function PRP_Router:ReleaseAll()
    local index
    for index = 1, 12 do
        self.captured[index] = nil
    end
    if PRP_ActionBar then
        PRP_ActionBar:ReleaseAll()
    end
end

function PRP_ActionKey(index, state)
    if PRP_Router then
        PRP_Router:ActionKey(index, state)
    end
end

function PRP_NavKey(direction)
    if PRP_Router then
        PRP_Router:Navigate(direction)
    end
end

function PRP_QuickMenuKey(state)
    if PRP_Router then
        PRP_Router:QuickMenuKey(state)
    end
end

function PRP_InventoryKey()
    if PRP_Router then
        PRP_Router:InventoryKey()
    end
end

function PRP_ChatKey(slash)
    if PRP_Router then
        PRP_Router:OpenChat(slash)
    end
end

function PRP_TargetCommand(command)
    if PRP_Router then
        PRP_Router:TargetCommand(command)
    end
end
