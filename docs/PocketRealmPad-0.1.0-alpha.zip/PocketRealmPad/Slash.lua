-- Small 1.12-compatible command surface. Normal users should configure the
-- Winlator key map and use the addon bindings; slash commands are recovery and
-- development aids.

PRP_Slash = {
    initialized = false,
}

function PRP_Slash:Initialize()
    if self.initialized then
        return
    end
    SLASH_POCKETREALMPAD1 = "/prp"
    SLASH_POCKETREALMPAD2 = "/pocketpad"
    SlashCmdList["POCKETREALMPAD"] = PRP_SlashCommand
    self.initialized = true
end

function PRP_Slash:Split(message)
    local command
    local rest
    message = message or ""
    message = string.gsub(message, "^%s+", "")
    message = string.gsub(message, "%s+$", "")
    local startPos
    local endPos
    startPos, endPos, command, rest = string.find(message, "^(%S+)%s*(.*)$")
    if not command then
        return "", ""
    end
    return string.lower(command), rest or ""
end

function PRP_Slash:Status()
    local context = PRP_Router and PRP_Router:GetContext() or "unknown"
    local layer = PRP_ActionBar and PRP_ActionBar:GetLayer() or 1
    PRP:Print("version " .. PRP.version
        .. "; enabled=" .. tostring(PocketRealmPadDB.enabled)
        .. "; safeMode=" .. tostring(PocketRealmPadDB.safeMode)
        .. "; context=" .. tostring(context)
        .. "; actionLayer=" .. tostring(layer)
        .. "; profile=" .. tostring(PocketRealmPadDB.mappingProfile))
end

function PRP_Slash:SetEnabled(enabled)
    PocketRealmPadDB.enabled = enabled and 1 or 0
    PRP:ReleaseAllInputs()
    if enabled then
        PRP:SetMode("WORLD")
        PRP:Print("enabled")
    else
        if PRP_QuickMenu then
            PRP_QuickMenu:Hide()
        end
        if PRP_Inventory then
            PRP_Inventory:Hide()
        end
        PRP:SetMode("DISABLED")
        PRP:Print("disabled")
    end
end

function PRP_Slash:SetSafeMode(enabled)
    PocketRealmPadDB.safeMode = enabled and 1 or 0
    PRP:ReleaseAllInputs()
    if enabled then
        if PRP_ActionBar and PRP_ActionBar.frame then
            PRP_ActionBar.frame:Hide()
        end
        if PRP_Targeting and PRP_Targeting.frame then
            PRP_Targeting.frame:Hide()
        end
        if PRP_QuickMenu then
            PRP_QuickMenu:Hide()
        end
        if PRP_Inventory then
            PRP_Inventory:Hide()
        end
        if PRP_Focus then
            PRP_Focus:Clear()
        end
        PRP:Print("safe mode enabled: semantic overlays and UI focus disabled; action bindings remain available")
    else
        if PRP_ActionBar and PocketRealmPadDB.bar.shown == 1 then
            PRP_ActionBar.frame:Show()
        end
        if PRP_Targeting and PocketRealmPadDB.target.shown == 1 then
            PRP_Targeting.frame:Show()
        end
        PRP:RefreshAll()
        PRP:Print("safe mode disabled")
    end
end

function PRP_Slash:SetScale(text)
    local value = tonumber(text)
    if not value then
        PRP:Print("usage: /prp scale 0.70-1.50")
        return
    end
    value = PRP_Clamp(value, 0.70, 1.50)
    PocketRealmPadDB.scale = value
    if PRP_ActionBar and PRP_ActionBar.frame then
        PRP_ActionBar.frame:SetScale(value)
    end
    if PRP_Targeting and PRP_Targeting.frame then
        PRP_Targeting.frame:SetScale(value)
    end
    if PRP_Inventory and PRP_Inventory.frame then
        PRP_Inventory.frame:SetScale(value)
    end
    if PRP_QuickMenu and PRP_QuickMenu.frame then
        PRP_QuickMenu.frame:SetScale(value)
    end
    PRP:Print("scale set to " .. tostring(value))
end

function PRP_Slash:Reset()
    PocketRealmPadDB = PRP_CopyTable(PRP_DEFAULTS)
    PRP:ReleaseAllInputs()
    if PRP_ActionBar then
        PRP_ActionBar:Layout()
    end
    PRP:RefreshAll()
    PRP:Print("settings reset")
end

function PRP_Slash:Help()
    PRP:Print("commands: status, enable, disable, safe on|off, bar show|hide|lock|unlock, scale N, debug on|off, reset")
end

function PRP_Slash:Handle(message)
    local command
    local rest
    local sub
    local value

    command, rest = self:Split(message)
    if command == "" or command == "help" then
        self:Help()
    elseif command == "status" then
        self:Status()
    elseif command == "enable" then
        self:SetEnabled(true)
    elseif command == "disable" then
        self:SetEnabled(false)
    elseif command == "safe" then
        sub = string.lower(rest or "")
        if sub == "on" then
            self:SetSafeMode(true)
        elseif sub == "off" then
            self:SetSafeMode(false)
        else
            PRP:Print("usage: /prp safe on|off")
        end
    elseif command == "bar" then
        sub = string.lower(rest or "")
        if sub == "show" then
            PocketRealmPadDB.bar.shown = 1
            if PRP_ActionBar and PocketRealmPadDB.safeMode ~= 1 then
                PRP_ActionBar.frame:Show()
            end
        elseif sub == "hide" then
            PocketRealmPadDB.bar.shown = 0
            if PRP_ActionBar then
                PRP_ActionBar.frame:Hide()
            end
        elseif sub == "lock" then
            PocketRealmPadDB.bar.locked = 1
            PRP:Print("action bar locked")
        elseif sub == "unlock" then
            PocketRealmPadDB.bar.locked = 0
            PRP:Print("action bar unlocked; drag it with the mouse")
        else
            PRP:Print("usage: /prp bar show|hide|lock|unlock")
        end
    elseif command == "scale" then
        self:SetScale(rest)
    elseif command == "debug" then
        sub = string.lower(rest or "")
        if sub == "on" then
            PocketRealmPadDB.debug = 1
            PRP:Print("debug logging enabled")
        elseif sub == "off" then
            PocketRealmPadDB.debug = 0
            PRP:Print("debug logging disabled")
        else
            PRP:Print("usage: /prp debug on|off")
        end
    elseif command == "reset" then
        self:Reset()
    else
        self:Help()
    end
end

function PRP_SlashCommand(message)
    if PRP_Slash then
        PRP_Slash:Handle(message)
    end
end
