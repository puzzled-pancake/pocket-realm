-- Vanilla targeting semantics. No soft-target CVars, nameplate scanning, or
-- modern gamepad target APIs are used.

PRP_Targeting = {
    initialized = false,
    groupIndex = 0,
    updateElapsed = 0,
}

function PRP_Targeting:Initialize()
    local frame
    local health
    if self.initialized then
        return
    end

    frame = PRP_UI:CreatePanel("PocketRealmPadTargetCard", 330, 58, "HIGH")
    frame:SetScale(PocketRealmPadDB.scale or 1)
    PRP_SetFramePosition(frame, PocketRealmPadDB.target)

    self.nameText = PRP_UI:CreateLabel(frame, "OVERLAY", "GameFontNormal", "No target")
    self.nameText:SetPoint("TOPLEFT", frame, "TOPLEFT", 13, -11)
    self.nameText:SetWidth(302)
    self.nameText:SetJustifyH("LEFT")

    self.detailText = PRP_UI:CreateLabel(frame, "OVERLAY", "GameFontHighlightSmall", "D-pad up/down: enemies; left/right: group")
    self.detailText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 13, 10)
    self.detailText:SetWidth(302)
    self.detailText:SetJustifyH("LEFT")

    health = CreateFrame("StatusBar", "PocketRealmPadTargetHealth", frame)
    health:SetWidth(304)
    health:SetHeight(8)
    health:SetPoint("TOPLEFT", frame, "TOPLEFT", 13, -31)
    health:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    health:SetMinMaxValues(0, 1)
    health:SetValue(0)
    health:SetStatusBarColor(0.2, 0.8, 0.2)
    self.health = health

    self.frame = frame
    self.initialized = true
    if PocketRealmPadDB.target.shown == 1 and PocketRealmPadDB.safeMode ~= 1 then
        frame:Show()
    else
        frame:Hide()
    end
    self:Update(true)
end

function PRP_Targeting:GetGroupUnits()
    local units = {}
    local count = 0
    local index

    count = count + 1
    units[count] = "player"
    if PRP_UnitExists("pet") then
        count = count + 1
        units[count] = "pet"
    end

    if GetNumRaidMembers and GetNumRaidMembers() > 0 then
        for index = 1, 40 do
            if PRP_UnitExists("raid" .. index) then
                count = count + 1
                units[count] = "raid" .. index
            end
        end
    else
        for index = 1, 4 do
            if PRP_UnitExists("party" .. index) then
                count = count + 1
                units[count] = "party" .. index
            end
            if PRP_UnitExists("partypet" .. index) then
                count = count + 1
                units[count] = "partypet" .. index
            end
        end
    end
    return units
end

function PRP_Targeting:FindCurrentGroupIndex(units)
    local index
    local unit
    for index = 1, PRP_TableLength(units) do
        unit = units[index]
        if UnitIsUnit and UnitIsUnit(unit, "target") then
            return index
        end
    end
    return 0
end

function PRP_Targeting:CycleGroup(direction)
    local units = self:GetGroupUnits()
    local count = PRP_TableLength(units)
    local index
    if count == 0 then
        return
    end
    index = self:FindCurrentGroupIndex(units)
    if index == 0 then
        if direction < 0 then
            index = count
        else
            index = 1
        end
    else
        index = index + direction
        if index < 1 then
            index = count
        elseif index > count then
            index = 1
        end
    end
    self.groupIndex = index
    TargetUnit(units[index])
end

function PRP_Targeting:Command(command)
    if command == "NEXT_ENEMY" then
        TargetNearestEnemy()
    elseif command == "PREV_ENEMY" then
        TargetNearestEnemy(1)
    elseif command == "NEXT_FRIEND" then
        TargetNearestFriend()
    elseif command == "PREV_FRIEND" then
        TargetNearestFriend(1)
    elseif command == "GROUP_NEXT" then
        self:CycleGroup(1)
    elseif command == "GROUP_PREV" then
        self:CycleGroup(-1)
    elseif command == "LAST_HOSTILE" then
        TargetLastEnemy()
    elseif command == "ASSIST" then
        AssistUnit("target")
    end
    self:Update(true)
end

function PRP_Targeting:WorldDirection(direction)
    if direction == "UP" then
        self:Command("NEXT_ENEMY")
    elseif direction == "DOWN" then
        self:Command("PREV_ENEMY")
    elseif direction == "LEFT" then
        self:Command("GROUP_PREV")
    elseif direction == "RIGHT" then
        self:Command("GROUP_NEXT")
    end
end

function PRP_Targeting:GetTargetColor()
    local reaction
    local color
    if UnitReaction then
        reaction = UnitReaction("player", "target")
    end
    if reaction and FACTION_BAR_COLORS then
        color = FACTION_BAR_COLORS[reaction]
        if color then
            return color.r or 1, color.g or 1, color.b or 1
        end
    end
    if UnitCanAttack and UnitCanAttack("player", "target") then
        return 1, 0.2, 0.2
    elseif UnitIsFriend and UnitIsFriend("player", "target") then
        return 0.2, 1, 0.2
    end
    return 1, 0.82, 0
end

function PRP_Targeting:Update(force)
    local name
    local level
    local classification
    local health
    local maximum
    local percent
    local r
    local g
    local b
    local status = ""
    if not self.initialized then
        return
    end
    if not PRP_UnitExists("target") then
        self.nameText:SetText("No target")
        self.nameText:SetTextColor(0.75, 0.75, 0.75)
        self.detailText:SetText("D-pad up/down: enemies   left/right: group")
        self.health:SetMinMaxValues(0, 1)
        self.health:SetValue(0)
        return
    end

    name = UnitName("target") or "Target"
    level = UnitLevel("target") or 0
    classification = UnitClassification and UnitClassification("target") or "normal"
    health = UnitHealth("target") or 0
    maximum = UnitHealthMax("target") or 1
    if maximum < 1 then
        maximum = 1
    end
    percent = math.floor((health / maximum) * 100 + 0.5)

    if classification == "worldboss" then
        status = "Boss"
    elseif classification == "rareelite" then
        status = "Rare Elite"
    elseif classification == "elite" then
        status = "Elite"
    elseif classification == "rare" then
        status = "Rare"
    end
    if UnitIsDead and UnitIsDead("target") then
        if status ~= "" then
            status = status .. ", Dead"
        else
            status = "Dead"
        end
    end

    r, g, b = self:GetTargetColor()
    self.nameText:SetText(name .. "  |cffbbbbbbL" .. tostring(level) .. "|r")
    self.nameText:SetTextColor(r, g, b)
    if status ~= "" then
        self.detailText:SetText(status .. "   " .. tostring(percent) .. "% health   World interaction: Winlator right-click")
    else
        self.detailText:SetText(tostring(percent) .. "% health   World interaction: Winlator right-click")
    end
    self.health:SetMinMaxValues(0, maximum)
    self.health:SetValue(health)
    self.health:SetStatusBarColor(r, g, b)
end

function PRP_Targeting:OnEvent(eventName, firstArg)
    if eventName == "UNIT_HEALTH" or eventName == "UNIT_MAXHEALTH" then
        if firstArg ~= "target" then
            return
        end
    end
    if eventName == "PLAYER_TARGET_CHANGED"
        or eventName == "UNIT_HEALTH"
        or eventName == "UNIT_MAXHEALTH"
        or eventName == "PARTY_MEMBERS_CHANGED"
        or eventName == "RAID_ROSTER_UPDATE" then
        self:Update(true)
    end
end

function PRP_Targeting:OnUpdate(elapsed)
    self.updateElapsed = self.updateElapsed + elapsed
    if self.updateElapsed >= 0.25 then
        self.updateElapsed = 0
        self:Update(false)
    end
end
