-- Shared visual primitives. All textures and fonts are Blizzard client assets.

PRP_UI = {
    initialized = false,
    toastUntil = 0,
}

function PRP_UI:CreatePanel(name, width, height, strata)
    local frame = CreateFrame("Frame", name, UIParent)
    frame:SetWidth(width)
    frame:SetHeight(height)
    frame:SetFrameStrata(strata or "DIALOG")
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 24,
        insets = { left = 8, right = 8, top = 8, bottom = 8 },
    })
    frame:SetBackdropColor(0.04, 0.05, 0.08, 0.94)
    return frame
end

function PRP_UI:CreateLabel(parent, layer, template, text)
    local label = parent:CreateFontString(nil, layer or "OVERLAY", template or "GameFontHighlight")
    label:SetText(text or "")
    return label
end

function PRP_UI:Initialize()
    local frame
    local label
    local top
    local bottom
    local left
    local right

    if self.initialized then
        return
    end

    self.root = CreateFrame("Frame", "PocketRealmPadUIRoot", UIParent)
    self.root:SetAllPoints(UIParent)
    self.root:SetFrameStrata("HIGH")
    self.root:EnableMouse(false)

    self.mode = CreateFrame("Frame", "PocketRealmPadModeBadge", UIParent)
    self.mode:SetWidth(170)
    self.mode:SetHeight(24)
    self.mode:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 16, -16)
    self.mode:SetFrameStrata("HIGH")
    self.mode:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    self.mode:SetBackdropColor(0, 0, 0, 0.75)
    self.modeText = self:CreateLabel(self.mode, "OVERLAY", "GameFontNormalSmall", "Pocket Realm Pad")
    self.modeText:SetPoint("CENTER", self.mode, "CENTER", 0, 0)

    self.prompt = CreateFrame("Frame", "PocketRealmPadPrompt", UIParent)
    self.prompt:SetWidth(610)
    self.prompt:SetHeight(30)
    self.prompt:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 46)
    self.prompt:SetFrameStrata("TOOLTIP")
    self.prompt:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    self.prompt:SetBackdropColor(0, 0, 0, 0.88)
    self.promptText = self:CreateLabel(self.prompt, "OVERLAY", "GameFontHighlightSmall", "")
    self.promptText:SetPoint("CENTER", self.prompt, "CENTER", 0, 0)
    self.prompt:Hide()

    self.toast = CreateFrame("Frame", "PocketRealmPadToast", UIParent)
    self.toast:SetWidth(460)
    self.toast:SetHeight(54)
    self.toast:SetPoint("CENTER", UIParent, "CENTER", 0, 128)
    self.toast:SetFrameStrata("TOOLTIP")
    self.toast:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    self.toast:SetBackdropColor(0.03, 0.03, 0.03, 0.95)
    self.toastText = self:CreateLabel(self.toast, "OVERLAY", "GameFontHighlight", "")
    self.toastText:SetWidth(430)
    self.toastText:SetPoint("CENTER", self.toast, "CENTER", 0, 0)
    self.toast:Hide()

    frame = CreateFrame("Frame", "PocketRealmPadFocusRing", UIParent)
    frame:SetFrameStrata("TOOLTIP")
    frame:EnableMouse(false)
    top = frame:CreateTexture(nil, "OVERLAY")
    top:SetTexture("Interface\\Buttons\\WHITE8X8")
    top:SetVertexColor(0.18, 0.78, 1.00, 1.00)
    top:SetHeight(3)
    top:SetPoint("TOPLEFT", frame, "TOPLEFT", -4, 4)
    top:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 4, 4)
    bottom = frame:CreateTexture(nil, "OVERLAY")
    bottom:SetTexture("Interface\\Buttons\\WHITE8X8")
    bottom:SetVertexColor(0.18, 0.78, 1.00, 1.00)
    bottom:SetHeight(3)
    bottom:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", -4, -4)
    bottom:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 4, -4)
    left = frame:CreateTexture(nil, "OVERLAY")
    left:SetTexture("Interface\\Buttons\\WHITE8X8")
    left:SetVertexColor(0.18, 0.78, 1.00, 1.00)
    left:SetWidth(3)
    left:SetPoint("TOPLEFT", frame, "TOPLEFT", -4, 4)
    left:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", -4, -4)
    right = frame:CreateTexture(nil, "OVERLAY")
    right:SetTexture("Interface\\Buttons\\WHITE8X8")
    right:SetVertexColor(0.18, 0.78, 1.00, 1.00)
    right:SetWidth(3)
    right:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 4, 4)
    right:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 4, -4)
    self.focusRing = frame
    self.focusRing:Hide()

    self.initialized = true
end

function PRP_UI:SetMode(mode)
    if not self.initialized then
        return
    end
    self.modeText:SetText("Pocket Realm Pad  |cff79b7ff" .. tostring(mode) .. "|r")
end

function PRP_UI:SetPrompt(text)
    if not self.initialized then
        return
    end
    if not text or text == "" then
        self.prompt:Hide()
        return
    end
    self.promptText:SetText(text)
    self.prompt:Show()
end

function PRP_UI:SetFocus(frame, label)
    if not self.initialized or not frame or not PRP_IsVisible(frame) then
        self:ClearFocus()
        return
    end
    self.focusRing:ClearAllPoints()
    self.focusRing:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    self.focusRing:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    self.focusRing:Show()
    if label and label ~= "" then
        self:SetPrompt("D-pad: move    Action 1: accept    Action 2: back    Action 3: alternate    |cff79b7ff" .. label .. "|r")
    end
end

function PRP_UI:ClearFocus()
    if not self.initialized then
        return
    end
    self.focusRing:Hide()
end

function PRP_UI:ShowToast(text, seconds)
    if not self.initialized then
        return
    end
    self.toastText:SetText(tostring(text or ""))
    self.toastUntil = GetTime() + (seconds or 2.0)
    self.toast:Show()
end

function PRP_UI:OnUpdate(elapsed)
    if self.toast:IsVisible() and self.toastUntil > 0 and GetTime() >= self.toastUntil then
        self.toast:Hide()
        self.toastUntil = 0
    end
end
