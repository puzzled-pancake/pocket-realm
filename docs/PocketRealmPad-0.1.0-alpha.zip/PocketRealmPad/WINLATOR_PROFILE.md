# Winlator input profile contract

## Purpose

The Winlator profile is the only component that knows about the physical controller. Pocket Realm Pad consumes ordinary keyboard and mouse events. This separation makes the addon independent of controller vendor, Android HID quirks, axis numbering, and runtime-specific native gamepad support.

## Required guarantees from Winlator

- Every pressed keyboard-mapped button eventually produces a matching release event.
- Shift, Control, and Alt can be held independently and in combination with action keys.
- The right stick can emit relative mouse motion while a configured camera-look/right-mouse state is active.
- A pointer/cursor mode can emit absolute or relative mouse movement plus left/right clicks for world objects and unsupported panels.
- Opening Android IME/chat does not leave W/A/S/D, modifiers, or mouse buttons logically pressed.
- Focus loss, app switching, overlay restart, and controller disconnect synthesize releases for every held key/button.
- D-pad directions are delivered as separate keys rather than analog state expected by the addon.

## Recommended logical map

Use any reliable keyboard keys, then bind those keys to Pocket Realm Pad commands in WoW. The example below avoids assuming a controller API.

```text
FACE_SOUTH       -> PRP_ACTION1
FACE_EAST        -> PRP_ACTION2
FACE_WEST        -> PRP_ACTION3
FACE_NORTH       -> PRP_ACTION4
RIGHT_SHOULDER   -> PRP_ACTION5
RIGHT_TRIGGER    -> PRP_ACTION6
EXTRA_1..EXTRA_6 -> PRP_ACTION7..PRP_ACTION12
LEFT_SHOULDER    -> Shift
LEFT_TRIGGER     -> Control
LEFT_STICK_CLICK -> Alt (self cast) or a dedicated target command
DPAD             -> PRP_NAV_UP/DOWN/LEFT/RIGHT
RIGHT_STICK_CLICK-> PRP_QUICK_MENU
SELECT            -> PRP_INVENTORY
CHAT_BUTTON       -> PRP_CHAT
```

## Camera and cursor modes

The addon cannot move the pointer. Implement two Winlator states:

1. **Camera mode**: right-stick motion is relative mouse motion while right mouse is held or emulated; face/action bindings continue to emit keys.
2. **Cursor mode**: right-stick or touch moves the pointer; face south emits left click; face east or a dedicated control emits right click.

A visible Winlator overlay or consistent toggle is preferable because the 1.12 addon cannot reliably detect which mouse mode is active.

## First-run validation sequence

1. Hold each movement direction for five seconds, release, and confirm immediate stop.
2. Hold Shift, press/release Action 1, release Shift; verify slot 13 exactly once.
3. Hold Control, press/release Action 1, release Control; verify slot 25 exactly once.
4. Hold Shift+Control, press/release Action 12; verify slot 48 exactly once.
5. Hold Alt, press/release a self-castable action; verify self-cast and no modifier remains stuck.
6. Open inventory during a held face button and verify the release does not cast in the world.
7. Open chat/IME while moving and verify movement stops before text entry.
8. Disconnect/reconnect the controller while holding a modifier and verify all keys are released.
9. Switch Android apps and return while moving/camera-looking; verify no key or mouse button remains held.
10. Repeat after client relaunch and after the Android game surface is recreated.
