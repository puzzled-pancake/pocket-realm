#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tests/static_check.py"
texlua "$ROOT/tests/runtime_mock.lua"
echo "ALL HOST TESTS PASS"
