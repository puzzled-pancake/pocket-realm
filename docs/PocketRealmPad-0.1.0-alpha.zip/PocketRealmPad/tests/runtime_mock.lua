-- Host-side behavioral smoke test. This is a mock of the subset of the 1.12 UI
-- API used by PocketRealmPad; it is not a substitute for an actual build-5875
-- client test.

math.mod = math.fmod
table.getn = function(value) return #value end
unpack = table.unpack

local failures = 0
local assertions = 0

local function check(condition, message)
    assertions = assertions + 1
    if not condition then
        failures = failures + 1
        io.stderr:write("ASSERT FAIL: " .. tostring(message) .. "\n")
    end
end

local registry = {}
local objectMethods = {}
local objectMeta = { __index = objectMethods }

local function newObject(name, parent)
    local obj = setmetatable({
        name = name,
        parent = parent,
        shown = true,
        enabled = true,
        scripts = {},
        x = 0,
        y = 0,
        width = 40,
        height = 40,
        frameLevel = 1,
        text = "",
        value = 0,
        minValue = 0,
        maxValue = 100,
    }, objectMeta)
    if name then
        registry[name] = obj
        _G[name] = obj
    end
    return obj
end

function objectMethods:GetName() return self.name end
function objectMethods:GetParent() return self.parent end
function objectMethods:SetParent(parent) self.parent = parent end
function objectMethods:SetWidth(value) self.width = value end
function objectMethods:SetHeight(value) self.height = value end
function objectMethods:GetWidth() return self.width end
function objectMethods:GetHeight() return self.height end
function objectMethods:SetFrameStrata(value) self.strata = value end
function objectMethods:SetFrameLevel(value) self.frameLevel = value end
function objectMethods:GetFrameLevel() return self.frameLevel end
function objectMethods:SetBackdrop(value) self.backdrop = value end
function objectMethods:SetBackdropColor(...) self.backdropColor = {...} end
function objectMethods:SetScale(value) self.scale = value end
function objectMethods:SetAlpha(value) self.alpha = value end
function objectMethods:EnableMouse(value) self.mouse = value end
function objectMethods:SetMovable(value) self.movable = value end
function objectMethods:RegisterForDrag(...) self.drag = {...} end
function objectMethods:RegisterForClicks(...) self.clicks = {...} end
function objectMethods:RegisterEvent(value) self.events = self.events or {}; self.events[value] = true end
function objectMethods:SetScript(kind, fn) self.scripts[kind] = fn end
function objectMethods:GetScript(kind) return self.scripts[kind] end
function objectMethods:SetPoint(point, relative, relativePoint, x, y)
    self.point = point
    self.relative = relative
    self.relativePoint = relativePoint
    self.x = x or 0
    self.y = y or 0
end
function objectMethods:GetPoint(index) return self.point or "CENTER", self.relative, self.relativePoint or "CENTER", self.x or 0, self.y or 0 end
function objectMethods:ClearAllPoints() end
function objectMethods:SetAllPoints(relative) self.relative = relative or self.parent end
function objectMethods:GetCenter()
    local px = 500
    local py = 400
    if self.relative and self.relative ~= self and self.relative.GetCenter then
        px, py = self.relative:GetCenter()
    end
    return px + (self.x or 0), py + (self.y or 0)
end
function objectMethods:Show() self.shown = true end
function objectMethods:Hide() self.shown = false end
function objectMethods:IsShown() return self.shown end
function objectMethods:IsVisible() return self.shown end
function objectMethods:IsEnabled() return self.enabled end
function objectMethods:SetEnabled(value) self.enabled = value and true or false end
function objectMethods:StartMoving() self.moving = true end
function objectMethods:StopMovingOrSizing() self.moving = false end
function objectMethods:SetNormalTexture(value)
    self.normalTexturePath = value
    if not self.normalTexture then self.normalTexture = newObject(nil, self) end
end
function objectMethods:GetNormalTexture()
    if not self.normalTexture then self.normalTexture = newObject(nil, self) end
    return self.normalTexture
end
function objectMethods:SetPushedTexture(value) self.pushedTexture = value end
function objectMethods:SetHighlightTexture(value, mode) self.highlightTexture = value end
function objectMethods:SetCheckedTexture(value, mode) self.checkedTexture = value end
function objectMethods:SetChecked(value) self.checked = value end
function objectMethods:SetButtonState(value) self.buttonState = value end
function objectMethods:GetButtonState() return self.buttonState or "NORMAL" end
function objectMethods:CreateTexture(name, layer) return newObject(name, self) end
function objectMethods:CreateFontString(name, layer, template) return newObject(name, self) end
function objectMethods:SetTexture(value) self.texture = value end
function objectMethods:SetVertexColor(...) self.vertex = {...} end
function objectMethods:SetBlendMode(value) self.blend = value end
function objectMethods:SetText(value) self.text = tostring(value or "") end
function objectMethods:GetText() return self.text end
function objectMethods:SetTextColor(...) self.textColor = {...} end
function objectMethods:SetJustifyH(value) self.justify = value end
function objectMethods:SetStatusBarTexture(value) self.statusTexture = value end
function objectMethods:SetStatusBarColor(...) self.statusColor = {...} end
function objectMethods:SetMinMaxValues(minimum, maximum) self.minValue = minimum; self.maxValue = maximum end
function objectMethods:GetMinMaxValues() return self.minValue, self.maxValue end
function objectMethods:SetValue(value) self.value = value end
function objectMethods:GetValue() return self.value end
function objectMethods:SetOwner(owner, anchor) self.owner = owner end
function objectMethods:SetAction(slot) self.tooltipAction = slot end
function objectMethods:SetBagItem(bag, slot) self.tooltipBag = bag; self.tooltipSlot = slot end
function objectMethods:IsOwned(owner) return self.owner == owner end
function objectMethods:SetID(id) self.id = id end
function objectMethods:GetID() return self.id or 0 end
function objectMethods:SetDesaturated(value) self.desaturated = value end

function CreateFrame(frameType, name, parent, template)
    local frame = newObject(name, parent)
    frame.frameType = frameType
    frame.template = template
    return frame
end

function getglobal(name) return registry[name] or _G[name] end

UIParent = newObject("UIParent", nil)
UIParent.width = 1000
UIParent.height = 800
DEFAULT_CHAT_FRAME = { AddMessage = function(self, text) self.last = text end }
GameTooltip = newObject("GameTooltip", UIParent)
GameTooltip.shown = false
ChatFrameEditBox = newObject("ChatFrameEditBox", UIParent)
ChatFrameEditBox.shown = false
BonusActionBarFrame = newObject("BonusActionBarFrame", UIParent)
BonusActionBarFrame.shown = false
MerchantFrame = newObject("MerchantFrame", UIParent)
MerchantFrame.shown = false

SlashCmdList = {}
ITEM_QUALITY_COLORS = {
    [0] = {r=0.6,g=0.6,b=0.6}, [1] = {r=1,g=1,b=1}, [2] = {r=0.1,g=1,b=0.1},
    [3] = {r=0.1,g=0.5,b=1}, [4] = {r=0.64,g=0.21,b=0.93},
}
FACTION_BAR_COLORS = { [5] = {r=0.1,g=1,b=0.1}, [2] = {r=1,g=0.1,b=0.1} }
BOOKTYPE_SPELL = "spell"
BOOKTYPE_PET = "pet"

local mockTime = 100
function GetTime() return mockTime end
local function advance(value) mockTime = mockTime + value end

local shiftDown = false
local controlDown = false
local altDown = false
function IsShiftKeyDown() return shiftDown end
function IsControlKeyDown() return controlDown end
function IsAltKeyDown() return altDown end
function GetBonusBarOffset() return 0 end

local usedActions = {}
function GetActionTexture(slot) if slot <= 48 then return "Texture" .. slot end return nil end
function GetActionCount(slot) return slot == 1 and 5 or 0 end
function GetActionCooldown(slot) return 0, 0, 1 end
function IsConsumableAction(slot) return slot == 1 end
function IsUsableAction(slot) return true, false end
function IsCurrentAction(slot) return false end
function IsAutoRepeatAction(slot) return false end
function IsEquippedAction(slot) return false end
function ActionHasRange(slot) return false end
function IsActionInRange(slot) return 1 end
function HasAction(slot) return slot >= 1 and slot <= 48 end
function UseAction(slot, cursor, selfCast) usedActions[#usedActions + 1] = {slot=slot,selfCast=selfCast} end
function CooldownFrame_SetTimer(frame, start, duration, enable) frame.cooldown = {start,duration,enable} end
function GetBindingKey(name) return nil, nil end
function GetBindingText(key, prefix, abbreviate) return key end
function PlaySound(name) end

local container = {
    [0] = {
        [1] = {texture="ItemA", count=2, quality=2, link="|cff1eff00|Hitem:1|h[Item A]|h|r"},
        [2] = {texture="ItemB", count=1, quality=1, link="|cffffffff|Hitem:2|h[Item B]|h|r"},
        [3] = false,
        [4] = false,
    },
    [1] = { [1] = false, [2] = false },
    [2] = {}, [3] = {}, [4] = {},
}
local containerUses = {}
local containerPickups = {}
local cursorHasItem = false
function GetContainerNumSlots(bag)
    if bag == 0 then return 4 end
    if bag == 1 then return 2 end
    return 0
end
function GetContainerItemInfo(bag, slot)
    local item = container[bag] and container[bag][slot]
    if not item then return nil, 0, nil, nil, nil end
    return item.texture, item.count, nil, item.quality, nil
end
function GetContainerItemLink(bag, slot)
    local item = container[bag] and container[bag][slot]
    return item and item.link or nil
end
function UseContainerItem(bag, slot) containerUses[#containerUses + 1] = bag .. ":" .. slot end
function PickupContainerItem(bag, slot) containerPickups[#containerPickups + 1] = bag .. ":" .. slot end
function CursorHasItem() return cursorHasItem end

local units = {
    player = {name="Player", health=100, max=100, reaction=5},
    party1 = {name="Party One", health=80, max=100, reaction=5},
    party2 = {name="Party Two", health=70, max=100, reaction=5},
    target = nil,
}
local targetUnitName = nil
function UnitExists(unit) return units[unit] ~= nil or (unit == "target" and targetUnitName ~= nil) end
function UnitName(unit)
    if unit == "target" then return targetUnitName and units[targetUnitName].name or nil end
    return units[unit] and units[unit].name or nil
end
function UnitHealth(unit)
    if unit == "target" then return targetUnitName and units[targetUnitName].health or 0 end
    return units[unit] and units[unit].health or 0
end
function UnitHealthMax(unit)
    if unit == "target" then return targetUnitName and units[targetUnitName].max or 1 end
    return units[unit] and units[unit].max or 1
end
function UnitLevel(unit) return 10 end
function UnitClassification(unit) return "normal" end
function UnitReaction(a, b) return 5 end
function UnitCanAttack(a, b) return false end
function UnitIsFriend(a, b) return true end
function UnitIsDead(unit) return false end
function UnitIsUnit(a, b)
    if b == "target" then return a == targetUnitName end
    if a == "target" then return b == targetUnitName end
    return a == b
end
function GetNumRaidMembers() return 0 end
function TargetUnit(unit) targetUnitName = unit end
function TargetNearestEnemy(reverse) targetUnitName = "party1" end
function TargetNearestFriend(reverse) targetUnitName = "party2" end
function TargetLastEnemy() targetUnitName = "party1" end
function AssistUnit(unit) end

local toggles = {}
function ToggleCharacter(name) toggles[#toggles + 1] = "character:" .. tostring(name) end
function ToggleSpellBook(name) toggles[#toggles + 1] = "spellbook:" .. tostring(name) end
function ToggleQuestLog() toggles[#toggles + 1] = "quests" end
function ToggleWorldMap() toggles[#toggles + 1] = "map" end
function ToggleGameMenu() toggles[#toggles + 1] = "menu" end
function ToggleFriendsFrame(tab) toggles[#toggles + 1] = "social" end
function ChatFrame_OpenChat(text) toggles[#toggles + 1] = "chat:" .. tostring(text); ChatFrameEditBox.shown = true end

PocketRealmPadDB = {}

local root = "/mnt/data/PocketRealmPad/"
local files = {
    "Locale.lua", "Profile.lua", "Compat.lua", "Core.lua", "UI.lua",
    "ActionBar.lua", "Targeting.lua", "Focus.lua", "Adapters.lua",
    "Inventory.lua", "QuickMenu.lua", "Router.lua", "Slash.lua",
}
for _, name in ipairs(files) do
    local fn, err = loadfile(root .. name)
    check(fn ~= nil, "loadfile " .. name .. ": " .. tostring(err))
    if fn then
        local ok, runtimeErr = pcall(fn)
        check(ok, "execute " .. name .. ": " .. tostring(runtimeErr))
    end
end

local ok, initErr = pcall(function() PRP:Initialize() end)
check(ok, "initialize: " .. tostring(initErr))
check(PRP.initialized, "core initialized")
check(#PRP_ActionBar.buttons == 12, "12 action buttons")
check(#PRP_Inventory.cells == 20, "20 inventory cells")
check(#PRP_QuickMenu.buttons == 8, "8 quick-menu nodes")

check(PRP_ActionBar:GetSlot(1, 1) == 1, "base slot 1")
check(PRP_ActionBar:GetSlot(12, 1) == 12, "base slot 12")
check(PRP_ActionBar:GetSlot(1, 2) == 13, "shift slot 13")
check(PRP_ActionBar:GetSlot(12, 3) == 36, "control slot 36")
check(PRP_ActionBar:GetSlot(12, 4) == 48, "shift-control slot 48")

shiftDown = true
check(PRP_ActionBar:GetLayer() == 2, "shift layer")
shiftDown = false
controlDown = true
check(PRP_ActionBar:GetLayer() == 3, "control layer")
shiftDown = true
check(PRP_ActionBar:GetLayer() == 4, "combined layer")
shiftDown = false
controlDown = false

local beforeActions = #usedActions
PRP_Router:ActionKey(5, "down")
PRP_Router:ActionKey(5, "up")
check(#usedActions == beforeActions + 1 and usedActions[#usedActions].slot == 5, "world action routed to slot 5")

altDown = true
PRP_Router:ActionKey(1, "down")
altDown = false
PRP_Router:ActionKey(1, "up")
check(usedActions[#usedActions].slot == 1 and usedActions[#usedActions].selfCast == 1, "self-cast modifier captured on key down")

PRP_Inventory:Show()
local beforeInventoryAction = #usedActions
local beforeUses = #containerUses
PRP_Router:ActionKey(1, "down")
PRP_Router:ActionKey(1, "up")
check(#usedActions == beforeInventoryAction, "UI action does not cast")
check(#containerUses == beforeUses + 1 and containerUses[#containerUses] == "0:1", "inventory accept uses selected item")

MerchantFrame.shown = true
beforeUses = #containerUses
PRP_Inventory:Accept()
check(#containerUses == beforeUses, "merchant first press arms sale")
advance(0.2)
PRP_Inventory:Accept()
check(#containerUses == beforeUses + 1, "merchant second press sells")
MerchantFrame.shown = false

PRP_Inventory:Hide()
PRP_QuickMenu.selected = 1
PRP_QuickMenu:Show()
PRP_QuickMenu:Accept()
check(toggles[#toggles] == "character:PaperDollFrame", "quick menu activates character panel")

local command, rest = PRP_Slash:Split("  SCALE 1.20 ")
check(command == "scale" and rest == "1.20", "Lua-5.0-compatible slash parser")

PRP_Targeting:CycleGroup(1)
check(targetUnitName == "player", "group cycle begins at player")
PRP_Targeting:CycleGroup(1)
check(targetUnitName == "party1", "group cycle advances")
PRP_Targeting:CycleGroup(-1)
check(targetUnitName == "player", "group cycle reverses")

local f1 = newObject("MockFocus1", UIParent); f1.x = 0; f1.y = 0
local f2 = newObject("MockFocus2", UIParent); f2.x = 100; f2.y = 0
local f3 = newObject("MockFocus3", UIParent); f3.x = 0; f3.y = 100
PRP_Focus.nodes = {{frame=f1},{frame=f2},{frame=f3}}
PRP_Focus.index = 1
check(PRP_Focus:GetDirectionalCandidate(1, 0) == 2, "focus geometry right")
check(PRP_Focus:GetDirectionalCandidate(0, 1) == 3, "focus geometry up")

PRP_Router:ReleaseAll()
check(next(PRP_Router.captured) == nil, "captured inputs released")

if failures > 0 then
    io.stderr:write(string.format("RUNTIME MOCK FAIL: %d/%d assertions failed\n", failures, assertions))
    os.exit(1)
end
print(string.format("RUNTIME MOCK PASS: %d assertions", assertions))
