#!/usr/bin/env python3
"""Static compatibility checks for PocketRealmPad.

This does not claim an in-client proof. It prevents accidental use of post-1.12
APIs/language constructs and verifies the addon's manifest/binding structure.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
TOC = ROOT / "PocketRealmPad.toc"

FORBIDDEN_TOKENS = {
    "modern namespace C_": re.compile(r"\bC_[A-Za-z0-9_]*\b"),
    "Enum namespace": re.compile(r"\bEnum\."),
    "modern state driver": re.compile(r"\bRegisterStateDriver\b"),
    "secure handler template": re.compile(r"\bSecureHandler[A-Za-z0-9_]*\b"),
    "secure action template": re.compile(r"\bSecureActionButtonTemplate\b"),
    "override binding API": re.compile(r"\bSetOverrideBinding(?:Click)?\b"),
    "modern gamepad API": re.compile(r"\b(?:GetGamePad|GamePad)[A-Za-z0-9_]*\b"),
    "hooksecurefunc": re.compile(r"\bhooksecurefunc\b"),
    "combat lockdown API": re.compile(r"\bInCombatLockdown\b"),
    "C_Timer": re.compile(r"\bC_Timer\b"),
    "mixin API": re.compile(r"\b(?:CreateFromMixins|Mixin)\s*\("),
    "BackdropTemplate": re.compile(r"\bBackdropTemplate\b"),
    "RegisterUnitEvent": re.compile(r"\bRegisterUnitEvent\b"),
    "post-Vanilla action key CVar": re.compile(r"\bACTION_BUTTON_USE_KEY_DOWN\b"),
    "Lua 5.1 string.match": re.compile(r"\bstring\.match\b"),
    "Lua 5.1 string.gmatch": re.compile(r"\bstring\.gmatch\b"),
    "Lua goto": re.compile(r"\bgoto\b"),
}


def strip_lua_comments_and_strings(text: str) -> str:
    """Conservative lexer for the checks below.

    It removes quoted strings and comments while preserving line count. Long
    bracket strings are not used by this project and are rejected separately.
    """

    out: list[str] = []
    i = 0
    n = len(text)
    state = "code"
    quote = ""
    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if state == "code":
            if ch == "-" and nxt == "-":
                state = "comment"
                out.extend("  ")
                i += 2
                continue
            if ch in ("'", '"'):
                state = "string"
                quote = ch
                out.append(" ")
                i += 1
                continue
            out.append(ch)
            i += 1
            continue
        if state == "comment":
            if ch == "\n":
                state = "code"
                out.append("\n")
            else:
                out.append(" ")
            i += 1
            continue
        if state == "string":
            if ch == "\\":
                out.append(" ")
                if i + 1 < n:
                    out.append("\n" if text[i + 1] == "\n" else " ")
                i += 2
                continue
            if ch == quote:
                state = "code"
                out.append(" ")
                i += 1
                continue
            out.append("\n" if ch == "\n" else " ")
            i += 1
    return "".join(out)


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def read_toc_files() -> list[str]:
    text = TOC.read_text(encoding="utf-8")
    if not re.search(r"^## Interface:\s*11200\s*$", text, re.MULTILINE):
        fail("TOC must declare Interface 11200")
    if "## SavedVariables: PocketRealmPadDB" not in text:
        fail("TOC SavedVariables declaration missing")

    files: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("##"):
            continue
        files.append(line)
    expected = {
        "Locale.lua",
        "Profile.lua",
        "Compat.lua",
        "Core.lua",
        "UI.lua",
        "ActionBar.lua",
        "Targeting.lua",
        "Focus.lua",
        "Adapters.lua",
        "Inventory.lua",
        "QuickMenu.lua",
        "Router.lua",
        "Slash.lua",
    }
    if set(files) != expected:
        fail(f"TOC file set mismatch: got {files!r}")
    for rel in files:
        if not (ROOT / rel).is_file():
            fail(f"TOC references missing file {rel}")
    return files


def check_bindings() -> None:
    path = ROOT / "Bindings.xml"
    try:
        root = ElementTree.parse(path).getroot()
    except ElementTree.ParseError as exc:
        fail(f"Bindings.xml is not well formed: {exc}")
    bindings = root.findall("Binding")
    names = [node.attrib.get("name") for node in bindings]
    expected_actions = [f"PRP_ACTION{i}" for i in range(1, 13)]
    for name in expected_actions:
        if name not in names:
            fail(f"missing binding {name}")
    for direction in ("UP", "DOWN", "LEFT", "RIGHT"):
        if f"PRP_NAV_{direction}" not in names:
            fail(f"missing navigation binding {direction}")
    if len(names) != len(set(names)):
        fail("duplicate binding name")
    for node in bindings:
        name = node.attrib.get("name", "")
        if name.startswith("PRP_ACTION") or name == "PRP_QUICK_MENU":
            if node.attrib.get("runOnUp") != "true":
                fail(f"{name} must use runOnUp=true to preserve down/up semantics")


def check_lua(files: list[str]) -> None:
    for rel in files:
        path = ROOT / rel
        text = path.read_text(encoding="utf-8")
        code = strip_lua_comments_and_strings(text)
        if "[[" in code or "]]" in code:
            fail(f"{rel}: long bracket syntax is outside this project's compatibility subset")
        if "#" in code:
            fail(f"{rel}: Lua 5.1 length operator '#' found; use table.getn")
        if re.search(r"(?<![<>=~])%(?![=])", code):
            fail(f"{rel}: modulo operator '%' found; use math.mod for Lua 5.0")
        for label, pattern in FORBIDDEN_TOKENS.items():
            match = pattern.search(code)
            if match:
                line = code.count("\n", 0, match.start()) + 1
                fail(f"{rel}:{line}: forbidden {label}: {match.group(0)!r}")

    combined = "\n".join((ROOT / rel).read_text(encoding="utf-8") for rel in files)
    required = (
        "UseAction(",
        "TargetNearestEnemy(",
        "GetContainerItemInfo(",
        "ChatFrame_OpenChat(",
        "GetBindingKey(",
        "CooldownFrame_SetTimer(",
    )
    for token in required:
        if token not in combined:
            fail(f"expected 1.12 API use not found: {token}")


def main() -> None:
    files = read_toc_files()
    check_bindings()
    check_lua(files)
    print(f"STATIC PASS: {len(files)} Lua files, 1 TOC, 1 Bindings.xml")


if __name__ == "__main__":
    main()
